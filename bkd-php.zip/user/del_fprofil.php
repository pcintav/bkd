<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
?>
<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /index");
    exit();
}

require_once("../includes/Dtbase.php");

$db = new DatabaseConnection();
$conn = $db->getConnection();

// Get user information from the session
$user_id = $_SESSION['user_id'];
$nama = $_SESSION['nama'];

// Function to handle image deletion
function deleteImage($imageField, $uploadPath, $nameColumn)
{
    global $conn, $user_id;

    // Validate database connection
    if (!$conn) {
        $_SESSION['message'] = "Database connection error.";
        return;
    }

    // Get image information from the database
    $stmtGetInfo = $conn->prepare("SELECT {$imageField}, {$nameColumn} FROM users_bkd WHERE user_id = ?");
    $stmtGetInfo->execute([$user_id]);
    $imageInfo = $stmtGetInfo->fetch(PDO::FETCH_ASSOC);

    if (!$imageInfo || empty($imageInfo[$imageField])) {
        $_SESSION['message'] = "Image not found for deletion.";
        return;
    }

    // Delete image file from server
    $filePath = $imageInfo[$imageField];
    if (file_exists($filePath)) {
        unlink($filePath);
    }

    // Update database to remove image information
    $stmtUpdate = $conn->prepare("UPDATE users_bkd SET {$imageField} = NULL, {$nameColumn} = NULL, revisi = CURRENT_TIMESTAMP WHERE user_id = ?");
    $stmtUpdate->execute([$user_id]);

    if ($stmtUpdate->rowCount() > 0) {
        $_SESSION['message'] = "Image deleted successfully.";
    } else {
        $_SESSION['message'] = "Failed to delete image from the database.";
    }
}

// Define image fields to delete
$imageFieldsToDelete = ['fotoprofil_url'];

foreach ($imageFieldsToDelete as $imageField) {
    // Define upload path for the image field
    $uploadPath = "uploads/" . date("Y/m/", time()) . $nama . "/";

    // Call the deleteImage function for each image field
    deleteImage($imageField, $uploadPath, 'namafoto_profil'); // Assuming 'namafoto_profil' is the name column for both fields
    //deleteImage($imageField, $uploadPath, 'namafoto_ktp'); // Assuming 'namafoto_profil' is the name column for both fields
}

header("Location: /user/up-image?img=user");
exit();
?>




