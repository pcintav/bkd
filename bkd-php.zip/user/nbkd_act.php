<?php
// Start session
session_start();

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

// Include your database connection class
require_once('./../includes/Dtbase.php');

// Instantiate the DatabaseConnection class
$databaseConnection = new DatabaseConnection();
$conn = $databaseConnection->getConnection();

// Fetch user details from the users_bkd table based on the current user's session
$userId = $_SESSION['user_id']; // You may need to adjust the session variable based on your authentication system
$query = "SELECT u.user_id, u.nidn, u.nama, u.fakultas, u.jurusan, u.jur_satu, u.jur_dua, u.jur_tiga, u.jur_empat, u.jur_lima, t.tahun
          FROM users_bkd u
          JOIN thn_akademik t ON 1 = 1
          WHERE u.user_id = :user_id";
$stmt = $conn->prepare($query);
$stmt->bindParam(':user_id', $userId);
$stmt->execute();
$userDetails = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if user details are found
if ($userDetails) {
    // Extract user details
    $nidn = $userDetails['nidn'];
    $nama = $userDetails['nama'];
    $fakultas = $userDetails['fakultas'];
    $jurusan = $userDetails['jurusan'];
    $jur_satu = $userDetails['jur_satu'];
    $jur_dua = $userDetails['jur_dua'];
    $jur_tiga = $userDetails['jur_tiga'];
    $jur_empat = $userDetails['jur_empat'];
    $jur_lima = $userDetails['jur_lima'];
    $tahun = $userDetails['tahun'];

// Check if the form is submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve the value of 'semester' from the HTML form
        $tahun = $_POST['tahun'];
        $semester = $_POST['semester'];
        $status_rb = $_POST['status_rb'];
        
        // Function to sanitize input
        function sanitizeInput($input) {
            return filter_var($input, FILTER_SANITIZE_STRING);
        }
        
        // Function to validate input
        function validateInput($input) {
            // Define allowed characters using regex
            $allowed_chars_regex = '/^[\w\s\/,.:?=&\\\\-]+$/';
        
            // Validate against allowed characters if input is not empty
            if (!empty($input)) {
                return preg_match($allowed_chars_regex, $input);
            }
        
            // Return true if input is empty
            return true;
        }
        
        // Array of input field names
        $input_fields = array(
            'anpdbkd1', 'anpdbkd2', 'anpdbkd3', 'anpdbkd4', 'anpdbkd5', 'anpdbkd6', 'anpdbkd7', 'anpdbkd8',
            'anplbkd1', 'anplbkd2', 'anplbkd3', 'anplbkd4',
            'anpgbkd1', 'anpgbkd2', 'anpgbkd3', 'anpgbkd4',
            'anpjbkd1', 'anpjbkd2', 'anpjbkd3', 'anpjbkd4',
            'appdbkd1', 'appdbkd2', 'appdbkd3', 'appdbkd4', 'appdbkd5', 'appdbkd6', 'appdbkd7', 'appdbkd8',
            'applbkd1', 'applbkd2', 'applbkd3', 'applbkd4',
            'appgbkd1', 'appgbkd2', 'appgbkd3', 'appgbkd4',
            'appjbkd1', 'appjbkd2', 'appjbkd3', 'appjbkd4',
            'docpdbkd1a', 'docpdbkd2a', 'docpdbkd3a', 'docpdbkd4a', 'docpdbkd5a', 'docpdbkd6a', 'docpdbkd7a', 'docpdbkd8a',
            'docplbkd1a', 'docplbkd2a', 'docplbkd3a', 'docplbkd4a',
            'docpgbkd1a', 'docpgbkd2a', 'docpgbkd3a', 'docpgbkd4a',
            'docpjbkd1a', 'docpjbkd2a', 'docpjbkd3a', 'docpjbkd4a',
            'docpdbkd1b', 'docpdbkd2b', 'docpdbkd3b', 'docpdbkd4b', 'docpdbkd5b', 'docpdbkd6b', 'docpdbkd7b', 'docpdbkd8b',
            'docplbkd1b', 'docplbkd2b', 'docplbkd3b', 'docplbkd4b',
            'docpgbkd1b', 'docpgbkd2b', 'docpgbkd3b', 'docpgbkd4b',
            'docpjbkd1b', 'docpjbkd2b', 'docpjbkd3b', 'docpjbkd4b',
            'docpdbkd1c', 'docpdbkd2c', 'docpdbkd3c', 'docpdbkd4c', 'docpdbkd5c', 'docpdbkd6c', 'docpdbkd7c', 'docpdbkd8c',
            'docplbkd1c', 'docplbkd2c', 'docplbkd3c', 'docplbkd4c',
            'docpgbkd1c', 'docpgbkd2c', 'docpgbkd3c', 'docpgbkd4c',
            'docpjbkd1c', 'docpjbkd2c', 'docpjbkd3c', 'docpjbkd4c'
        );
        
        $validation_errors = [];
        
        // Iterate through input fields
        foreach ($input_fields as $field) {
            // Get input value
            $input_value = filter_input(INPUT_POST, $field, FILTER_SANITIZE_STRING);
        
            // Sanitize input
            $sanitized_input = sanitizeInput($input_value);
        
            // Validate input if not empty
            if (!validateInput($sanitized_input) && !empty($sanitized_input)) {
                $validation_errors[] = "Invalid value for $field";
            }
        }
        
        // Check for any validation errors
        if (!empty($validation_errors)) {
            $_SESSION['message'] = implode("<br>", $validation_errors);
            header("Location: /user/nbkd?nbkd=$nidn");
            exit();
        }
        
        // Prepare and execute the INSERT query for bkd_reports
        $insertQuery = "INSERT INTO bkd_reports 
                        (user_id, nidn, nama, fakultas, jurusan, jur_satu, jur_dua, jur_tiga, jur_empat, jur_lima, tahun, semester, status_rb,
                         anpdbkd1, appdbkd1, skspdbkd1, smtpdbkd1, docpdbkd1a, docpdbkd1b, docpdbkd1c,
                         anpdbkd2, appdbkd2, skspdbkd2, smtpdbkd2, docpdbkd2a, docpdbkd2b, docpdbkd2c,
                         anpdbkd3, appdbkd3, skspdbkd3, smtpdbkd3, docpdbkd3a, docpdbkd3b, docpdbkd3c,
                         anpdbkd4, appdbkd4, skspdbkd4, smtpdbkd4, docpdbkd4a, docpdbkd4b, docpdbkd4c,
                         anpdbkd5, appdbkd5, skspdbkd5, smtpdbkd5, docpdbkd5a, docpdbkd5b, docpdbkd5c,
                         anpdbkd6, appdbkd6, skspdbkd6, smtpdbkd6, docpdbkd6a, docpdbkd6b, docpdbkd6c,
                         anpdbkd7, appdbkd7, skspdbkd7, smtpdbkd7, docpdbkd7a, docpdbkd7b, docpdbkd7c,
                         anpdbkd8, appdbkd8, skspdbkd8, smtpdbkd8, docpdbkd8a, docpdbkd8b, docpdbkd8c,
                         anplbkd1, applbkd1, sksplbkd1, smtplbkd1, docplbkd1a, docplbkd1b, docplbkd1c,
                         anplbkd2, applbkd2, sksplbkd2, smtplbkd2, docplbkd2a, docplbkd2b, docplbkd2c,
                         anplbkd3, applbkd3, sksplbkd3, smtplbkd3, docplbkd3a, docplbkd3b, docplbkd3c,
                         anplbkd4, applbkd4, sksplbkd4, smtplbkd4, docplbkd4a, docplbkd4b, docplbkd4c,
                         anpgbkd1, appgbkd1, skspgbkd1, smtpgbkd1, docpgbkd1a, docpgbkd1b, docpgbkd1c,
                         anpgbkd2, appgbkd2, skspgbkd2, smtpgbkd2, docpgbkd2a, docpgbkd2b, docpgbkd2c,
                         anpgbkd3, appgbkd3, skspgbkd3, smtpgbkd3, docpgbkd3a, docpgbkd3b, docpgbkd3c,
                         anpgbkd4, appgbkd4, skspgbkd4, smtpgbkd4, docpgbkd4a, docpgbkd4b, docpgbkd4c,
                         anpjbkd1, appjbkd1, skspjbkd1, smtpjbkd1, docpjbkd1a, docpjbkd1b, docpjbkd1c,
                         anpjbkd2, appjbkd2, skspjbkd2, smtpjbkd2, docpjbkd2a, docpjbkd2b, docpjbkd2c,
                         anpjbkd3, appjbkd3, skspjbkd3, smtpjbkd3, docpjbkd3a, docpjbkd3b, docpjbkd3c,
                         anpjbkd4, appjbkd4, skspjbkd4, smtpjbkd4, docpjbkd4a, docpjbkd4b, docpjbkd4c)
                        VALUES 
                        (:user_id, :nidn, :nama, :fakultas, :jurusan, :jur_satu, :jur_dua, :jur_tiga, :jur_empat, :jur_lima, :tahun, :semester, :status_rb,
                         :anpdbkd1, :appdbkd1, :skspdbkd1, :smtpdbkd1, :docpdbkd1a, :docpdbkd1b, :docpdbkd1c,
                         :anpdbkd2, :appdbkd2, :skspdbkd2, :smtpdbkd2, :docpdbkd2a, :docpdbkd2b, :docpdbkd2c,
                         :anpdbkd3, :appdbkd3, :skspdbkd3, :smtpdbkd3, :docpdbkd3a, :docpdbkd3b, :docpdbkd3c,
                         :anpdbkd4, :appdbkd4, :skspdbkd4, :smtpdbkd4, :docpdbkd4a, :docpdbkd4b, :docpdbkd4c,
                         :anpdbkd5, :appdbkd5, :skspdbkd5, :smtpdbkd5, :docpdbkd5a, :docpdbkd5b, :docpdbkd5c,
                         :anpdbkd6, :appdbkd6, :skspdbkd6, :smtpdbkd6, :docpdbkd6a, :docpdbkd6b, :docpdbkd6c,
                         :anpdbkd7, :appdbkd7, :skspdbkd7, :smtpdbkd7, :docpdbkd7a, :docpdbkd7b, :docpdbkd7c,
                         :anpdbkd8, :appdbkd8, :skspdbkd8, :smtpdbkd8, :docpdbkd8a, :docpdbkd8b, :docpdbkd8c,
                         :anplbkd1, :applbkd1, :sksplbkd1, :smtplbkd1, :docplbkd1a, :docplbkd1b, :docplbkd1c,
                         :anplbkd2, :applbkd2, :sksplbkd2, :smtplbkd2, :docplbkd2a, :docplbkd2b, :docplbkd2c,
                         :anplbkd3, :applbkd3, :sksplbkd3, :smtplbkd3, :docplbkd3a, :docplbkd3b, :docplbkd3c,
                         :anplbkd4, :applbkd4, :sksplbkd4, :smtplbkd4, :docplbkd4a, :docplbkd4b, :docplbkd4c,
                         :anpgbkd1, :appgbkd1, :skspgbkd1, :smtpgbkd1, :docpgbkd1a, :docpgbkd1b, :docpgbkd1c,
                         :anpgbkd2, :appgbkd2, :skspgbkd2, :smtpgbkd2, :docpgbkd2a, :docpgbkd2b, :docpgbkd2c,
                         :anpgbkd3, :appgbkd3, :skspgbkd3, :smtpgbkd3, :docpgbkd3a, :docpgbkd3b, :docpgbkd3c,
                         :anpgbkd4, :appgbkd4, :skspgbkd4, :smtpgbkd4, :docpgbkd4a, :docpgbkd4b, :docpgbkd4c,
                         :anpjbkd1, :appjbkd1, :skspjbkd1, :smtpjbkd1, :docpjbkd1a, :docpjbkd1b, :docpjbkd1c,
                         :anpjbkd2, :appjbkd2, :skspjbkd2, :smtpjbkd2, :docpjbkd2a, :docpjbkd2b, :docpjbkd2c,
                         :anpjbkd3, :appjbkd3, :skspjbkd3, :smtpjbkd3, :docpjbkd3a, :docpjbkd3b, :docpjbkd3c,
                         :anpjbkd4, :appjbkd4, :skspjbkd4, :smtpjbkd4, :docpjbkd4a, :docpjbkd4b, :docpjbkd4c)";

        $stmt = $conn->prepare($insertQuery);

        // Bind parameters
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':nidn', $nidn);
        $stmt->bindParam(':nama', $nama);
        $stmt->bindParam(':fakultas', $fakultas);
        $stmt->bindParam(':jurusan', $jurusan);
        $stmt->bindParam(':jur_satu', $jur_satu);
        $stmt->bindParam(':jur_dua', $jur_dua);
        $stmt->bindParam(':jur_tiga', $jur_tiga);
        $stmt->bindParam(':jur_empat', $jur_empat);
        $stmt->bindParam(':jur_lima', $jur_lima);
        $stmt->bindParam(':tahun', $tahun);
        $stmt->bindParam(':semester', $semester);
        $stmt->bindParam(':status_rb', $status_rb);

        // Bind other form input fields (adjust these based on your HTML form)
        $stmt->bindParam(':anpdbkd1', $_POST['anpdbkd1']);
        $stmt->bindParam(':appdbkd1', $_POST['appdbkd1']);
        $stmt->bindParam(':skspdbkd1', $_POST['skspdbkd1']);
        $stmt->bindParam(':smtpdbkd1', $_POST['smtpdbkd1']);
        $stmt->bindParam(':docpdbkd1a', $_POST['docpdbkd1a']);
        $stmt->bindParam(':docpdbkd1b', $_POST['docpdbkd1b']);
        $stmt->bindParam(':docpdbkd1c', $_POST['docpdbkd1c']);
        
        $stmt->bindParam(':anpdbkd2', $_POST['anpdbkd2']);
        $stmt->bindParam(':appdbkd2', $_POST['appdbkd2']);
        $stmt->bindParam(':skspdbkd2', $_POST['skspdbkd2']);
        $stmt->bindParam(':smtpdbkd2', $_POST['smtpdbkd2']);
        $stmt->bindParam(':docpdbkd2a', $_POST['docpdbkd2a']);
        $stmt->bindParam(':docpdbkd2b', $_POST['docpdbkd2b']);
        $stmt->bindParam(':docpdbkd2c', $_POST['docpdbkd2c']);
        
        $stmt->bindParam(':anpdbkd3', $_POST['anpdbkd3']);
        $stmt->bindParam(':appdbkd3', $_POST['appdbkd3']);
        $stmt->bindParam(':skspdbkd3', $_POST['skspdbkd3']);
        $stmt->bindParam(':smtpdbkd3', $_POST['smtpdbkd3']);
        $stmt->bindParam(':docpdbkd3a', $_POST['docpdbkd3a']);
        $stmt->bindParam(':docpdbkd3b', $_POST['docpdbkd3b']);
        $stmt->bindParam(':docpdbkd3c', $_POST['docpdbkd3c']);
        
        $stmt->bindParam(':anpdbkd4', $_POST['anpdbkd4']);
        $stmt->bindParam(':appdbkd4', $_POST['appdbkd4']);
        $stmt->bindParam(':skspdbkd4', $_POST['skspdbkd4']);
        $stmt->bindParam(':smtpdbkd4', $_POST['smtpdbkd4']);
        $stmt->bindParam(':docpdbkd4a', $_POST['docpdbkd4a']);
        $stmt->bindParam(':docpdbkd4b', $_POST['docpdbkd4b']);
        $stmt->bindParam(':docpdbkd4c', $_POST['docpdbkd4c']);
        
        $stmt->bindParam(':anpdbkd5', $_POST['anpdbkd5']);
        $stmt->bindParam(':appdbkd5', $_POST['appdbkd5']);
        $stmt->bindParam(':skspdbkd5', $_POST['skspdbkd5']);
        $stmt->bindParam(':smtpdbkd5', $_POST['smtpdbkd5']);
        $stmt->bindParam(':docpdbkd5a', $_POST['docpdbkd5a']);
        $stmt->bindParam(':docpdbkd5b', $_POST['docpdbkd5b']);
        $stmt->bindParam(':docpdbkd5c', $_POST['docpdbkd5c']);
        
        $stmt->bindParam(':anpdbkd6', $_POST['anpdbkd6']);
        $stmt->bindParam(':appdbkd6', $_POST['appdbkd6']);
        $stmt->bindParam(':skspdbkd6', $_POST['skspdbkd6']);
        $stmt->bindParam(':smtpdbkd6', $_POST['smtpdbkd6']);
        $stmt->bindParam(':docpdbkd6a', $_POST['docpdbkd6a']);
        $stmt->bindParam(':docpdbkd6b', $_POST['docpdbkd6b']);
        $stmt->bindParam(':docpdbkd6c', $_POST['docpdbkd6c']);
        
        $stmt->bindParam(':anpdbkd7', $_POST['anpdbkd7']);
        $stmt->bindParam(':appdbkd7', $_POST['appdbkd7']);
        $stmt->bindParam(':skspdbkd7', $_POST['skspdbkd7']);
        $stmt->bindParam(':smtpdbkd7', $_POST['smtpdbkd7']);
        $stmt->bindParam(':docpdbkd7a', $_POST['docpdbkd7a']);
        $stmt->bindParam(':docpdbkd7b', $_POST['docpdbkd7b']);
        $stmt->bindParam(':docpdbkd7c', $_POST['docpdbkd7c']);
        
        $stmt->bindParam(':anpdbkd8', $_POST['anpdbkd8']);
        $stmt->bindParam(':appdbkd8', $_POST['appdbkd8']);
        $stmt->bindParam(':skspdbkd8', $_POST['skspdbkd8']);
        $stmt->bindParam(':smtpdbkd8', $_POST['smtpdbkd8']);
        $stmt->bindParam(':docpdbkd8a', $_POST['docpdbkd8a']);
        $stmt->bindParam(':docpdbkd8b', $_POST['docpdbkd8b']);
        $stmt->bindParam(':docpdbkd8c', $_POST['docpdbkd8c']);
        
        $stmt->bindParam(':anplbkd1', $_POST['anplbkd1']);
        $stmt->bindParam(':applbkd1', $_POST['applbkd1']);
        $stmt->bindParam(':sksplbkd1', $_POST['sksplbkd1']);
        $stmt->bindParam(':smtplbkd1', $_POST['smtplbkd1']);
        $stmt->bindParam(':docplbkd1a', $_POST['docplbkd1a']);
        $stmt->bindParam(':docplbkd1b', $_POST['docplbkd1b']);
        $stmt->bindParam(':docplbkd1c', $_POST['docplbkd1c']);
        
        $stmt->bindParam(':anplbkd2', $_POST['anplbkd2']);
        $stmt->bindParam(':applbkd2', $_POST['applbkd2']);
        $stmt->bindParam(':sksplbkd2', $_POST['sksplbkd2']);
        $stmt->bindParam(':smtplbkd2', $_POST['smtplbkd2']);
        $stmt->bindParam(':docplbkd2a', $_POST['docplbkd2a']);
        $stmt->bindParam(':docplbkd2b', $_POST['docplbkd2b']);
        $stmt->bindParam(':docplbkd2c', $_POST['docplbkd2c']);
        
        $stmt->bindParam(':anplbkd3', $_POST['anplbkd3']);
        $stmt->bindParam(':applbkd3', $_POST['applbkd3']);
        $stmt->bindParam(':sksplbkd3', $_POST['sksplbkd3']);
        $stmt->bindParam(':smtplbkd3', $_POST['smtplbkd3']);
        $stmt->bindParam(':docplbkd3a', $_POST['docplbkd3a']);
        $stmt->bindParam(':docplbkd3b', $_POST['docplbkd3b']);
        $stmt->bindParam(':docplbkd3c', $_POST['docplbkd3c']);
        
        $stmt->bindParam(':anplbkd4', $_POST['anplbkd4']);
        $stmt->bindParam(':applbkd4', $_POST['applbkd4']);
        $stmt->bindParam(':sksplbkd4', $_POST['sksplbkd4']);
        $stmt->bindParam(':smtplbkd4', $_POST['smtplbkd4']);
        $stmt->bindParam(':docplbkd4a', $_POST['docplbkd4a']);
        $stmt->bindParam(':docplbkd4b', $_POST['docplbkd4b']);
        $stmt->bindParam(':docplbkd4c', $_POST['docplbkd4c']);
        
        $stmt->bindParam(':anpgbkd1', $_POST['anpgbkd1']);
        $stmt->bindParam(':appgbkd1', $_POST['appgbkd1']);
        $stmt->bindParam(':skspgbkd1', $_POST['skspgbkd1']);
        $stmt->bindParam(':smtpgbkd1', $_POST['smtpgbkd1']);
        $stmt->bindParam(':docpgbkd1a', $_POST['docpgbkd1a']);
        $stmt->bindParam(':docpgbkd1b', $_POST['docpgbkd1b']);
        $stmt->bindParam(':docpgbkd1c', $_POST['docpgbkd1c']);
        
        $stmt->bindParam(':anpgbkd2', $_POST['anpgbkd2']);
        $stmt->bindParam(':appgbkd2', $_POST['appgbkd2']);
        $stmt->bindParam(':skspgbkd2', $_POST['skspgbkd2']);
        $stmt->bindParam(':smtpgbkd2', $_POST['smtpgbkd2']);
        $stmt->bindParam(':docpgbkd2a', $_POST['docpgbkd2a']);
        $stmt->bindParam(':docpgbkd2b', $_POST['docpgbkd2b']);
        $stmt->bindParam(':docpgbkd2c', $_POST['docpgbkd2c']);
        
        $stmt->bindParam(':anpgbkd3', $_POST['anpgbkd3']);
        $stmt->bindParam(':appgbkd3', $_POST['appgbkd3']);
        $stmt->bindParam(':skspgbkd3', $_POST['skspgbkd3']);
        $stmt->bindParam(':smtpgbkd3', $_POST['smtpgbkd3']);
        $stmt->bindParam(':docpgbkd3a', $_POST['docpgbkd3a']);
        $stmt->bindParam(':docpgbkd3b', $_POST['docpgbkd3b']);
        $stmt->bindParam(':docpgbkd3c', $_POST['docpgbkd3c']);
        
        $stmt->bindParam(':anpgbkd4', $_POST['anpgbkd4']);
        $stmt->bindParam(':appgbkd4', $_POST['appgbkd4']);
        $stmt->bindParam(':skspgbkd4', $_POST['skspgbkd4']);
        $stmt->bindParam(':smtpgbkd4', $_POST['smtpgbkd4']);
        $stmt->bindParam(':docpgbkd4a', $_POST['docpgbkd4a']);
        $stmt->bindParam(':docpgbkd4b', $_POST['docpgbkd4b']);
        $stmt->bindParam(':docpgbkd4c', $_POST['docpgbkd4c']);
        
        $stmt->bindParam(':anpjbkd1', $_POST['anpjbkd1']);
        $stmt->bindParam(':appjbkd1', $_POST['appjbkd1']);
        $stmt->bindParam(':skspjbkd1', $_POST['skspjbkd1']);
        $stmt->bindParam(':smtpjbkd1', $_POST['smtpjbkd1']);
        $stmt->bindParam(':docpjbkd1a', $_POST['docpjbkd1a']);
        $stmt->bindParam(':docpjbkd1b', $_POST['docpjbkd1b']);
        $stmt->bindParam(':docpjbkd1c', $_POST['docpjbkd1c']);
        
        $stmt->bindParam(':anpjbkd2', $_POST['anpjbkd2']);
        $stmt->bindParam(':appjbkd2', $_POST['appjbkd2']);
        $stmt->bindParam(':skspjbkd2', $_POST['skspjbkd2']);
        $stmt->bindParam(':smtpjbkd2', $_POST['smtpjbkd2']);
        $stmt->bindParam(':docpjbkd2a', $_POST['docpjbkd2a']);
        $stmt->bindParam(':docpjbkd2b', $_POST['docpjbkd2b']);
        $stmt->bindParam(':docpjbkd2c', $_POST['docpjbkd2c']);
        
        $stmt->bindParam(':anpjbkd3', $_POST['anpjbkd3']);
        $stmt->bindParam(':appjbkd3', $_POST['appjbkd3']);
        $stmt->bindParam(':skspjbkd3', $_POST['skspjbkd3']);
        $stmt->bindParam(':smtpjbkd3', $_POST['smtpjbkd3']);
        $stmt->bindParam(':docpjbkd3a', $_POST['docpjbkd3a']);
        $stmt->bindParam(':docpjbkd3b', $_POST['docpjbkd3b']);
        $stmt->bindParam(':docpjbkd3c', $_POST['docpjbkd3c']);
        
        $stmt->bindParam(':anpjbkd4', $_POST['anpjbkd4']);
        $stmt->bindParam(':appjbkd4', $_POST['appjbkd4']);
        $stmt->bindParam(':skspjbkd4', $_POST['skspjbkd4']);
        $stmt->bindParam(':smtpjbkd4', $_POST['smtpjbkd4']);
        $stmt->bindParam(':docpjbkd4a', $_POST['docpjbkd4a']);
        $stmt->bindParam(':docpjbkd4b', $_POST['docpjbkd4b']);
        $stmt->bindParam(':docpjbkd4c', $_POST['docpjbkd4c']);

        // Execute the query
        if ($stmt->execute()) {
            $_SESSION['message'] = "Data rencana BKD baru sukses dibuat!";
            header("Location: /user/rbkd-report?bkdr=$nidn"); // Redirect to success page
            exit();
        } else {
            $_SESSION['xmessage'] = "Gagal input data rencana BKD baru. Error: " . implode(", ", $stmt->errorInfo());
            header("Location: /user/nbkd?nbkd=$nidn"); // Redirect to the same page with an error message
            exit();
        }
    } else {
        $_SESSION['xmessage'] = "Detail pengguna tidak ditemukan.";
        header("Location: /user/nbkd?nbkd=$nidn"); // Redirect to the same page with an error message
        exit();
    }
}
?>