<?php require_once ("../includes/header.php"); ?>
<?php require_once ("../includes/sidebar.php"); ?>
<?php require_once ("../includes/topbar.php"); ?>


    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col">
                
                <div class="card">
                    <div class="row px-4 mt-4 mb-0">
                        <div class="col">
                            <span class="badge bg-primary me-2"><i class="ti ti-star me-1"></i>LIST ENTRI RBKD</span> <span class="badge bg-success me-1"><i class="ti ti-calendar me-2"></i>TA: 2023/2024</span><span class="badge bg-warning me-1"><i class="ti ti-calendar me-1"></i>GANJIL</span>
                        </div>
                        <div class="col"><a href="/user/nbkd?nbkd=<?php echo $nidn; ?>" class="badge bg-label-danger float-end"><i class="ti ti-folder me-2"></i>BUAT BARU RENCANA BKD</a></div>
                    </div> 
                          
                    <div class="card-body">
                        <?php if(isset($_SESSION['xmessage'])) : ?>
                        <h5 class="alert alert-danger"><?= $_SESSION['xmessage']; ?></h5>
                        <?php 
                            unset($_SESSION['xmessage']);
                            endif; 
                        ?>
                        <?php if(isset($_SESSION['message'])) : ?>
                        <h5 class="alert alert-success"><?= $_SESSION['message']; ?></h5>
                        <?php 
                            unset($_SESSION['message']);
                            endif; 
                        ?>
                        <div class="table-responsive">
                        <table class="display" id="bkdTable" style="font-size:14px;">
                            <thead class="table-light">
                               <tr class="text-center align-middle">
                                    <th class="thnbkdwd">No.</th>
                                    <th class="thnbkd">Nama</th>
                                    <th class="thnbkd">Fakultas</th>
                                    <th class="thnbkd">Jurusan</th>
                                    <th class="thnbkd">Tahun & Semester</th>
                                    <th class="thnbkdwd">Status</th>
                                    <th class="thnbkdwd">Unduh</th>
                                    <th class="thnbkd"><i class="ti ti-settings"></i></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM bkd_reports WHERE user_id = :user_id";
                                $statement = $conn->prepare($query);
                                
                                // Retrieve user ID from session
                                $user_id = $_SESSION['user_id']; // Assuming user_id is stored in the session
                                
                                // Bind user ID to the query
                                $statement->bindParam(':user_id', $user_id);
                                
                                $statement->execute();
                                
                                $statement->setFetchMode(PDO::FETCH_OBJ);
                                $result = $statement->fetchAll();
                                if($result) {
                                    foreach($result as $row) {
                                ?>
                                    <tr>
                                        <td><span class="fs-tiny fw-bold"><?= $row->rep_id; ?></span></td>
                                        <td><span class="fs-tiny fw-bold text-uppercase"><?= $row->nama; ?></span></td>
                                        <td><span class="fs-tiny text-uppercase"><?= $row->fakultas; ?></span></td>
                                        <td><span class="fs-tiny text-uppercase"><?= $row->jurusan; ?></span></td>
                                        <td><span class="fs-tiny text-uppercase"><?= $row->tahun; ?> | <?= $row->semester; ?></span></td>
                                        <td><span class="badge bg-primary fs-tiny text-uppercase"><?= $row->status_rb; ?></span></td>
                                        <td><button type="button" class="btn btn-sm text-primary px-1"><i class="ti ti-printer"></i></button></td>
                                        <td>
                                            <form action="del_nbkd.php" method="POST">
                                            <a href="edit-nbkd.php?edn=<?= $row->rep_id; ?>" style="font-size:14px;" class="btn btn-sm p-1 text-primary"><i class="ti ti-ballpen"></i></a> <button type="submit" class="btn btn-sm p-1 text-danger" name="del_data" value="<?=$row->rep_id ;?>" id="dlt" style="font-size:12px;" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-custom-class="custom-tooltip" data-bs-title="Hati-hati entri dihapus, tidak dapat dipulihkan."><i class="ti ti-trash"></i></button> 
                                            </form>
                                        </td>
                                    </tr>
                                <?php
                                    }
                                } else {
                                ?>
                                    <tr>
                                        <td colspan="8"><span class="fs-5 text-danger">BELUM ADA DATA RBKD YANG DAPAT DITAMPILKAN.</span></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                </tbody>
                        </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    
    <!-- / Content -->

    <!-- Include jQuery -->    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Include DataTables JavaScript -->
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
 
    <script>
    var $j = jQuery.noConflict(); // Gunakan $j sebagai pengganti $
    $j(document).ready(function() {
        $j('#bkdTable').DataTable({
            lengthMenu: [ [25, 50, 100, -1], [25, 50, 100, "Semua"] ], // Customize the dropdown options            
            language: {
                url: "../assets/json/Indonesian.json"
            }
        });
    });
    </script>
    
<?php require_once ("../includes/footer.php"); ?>