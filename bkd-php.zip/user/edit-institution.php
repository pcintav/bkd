<?php require_once ("../includes/header.php"); ?>
<?php require_once ("../includes/sidebar.php"); ?>
<?php require_once ("../includes/topbar.php"); ?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

?>  

            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
        		<div class="row">
        			<!-- main col -->
        				<div class="col pb-5">
        				<div class="card mb-4">
                            <div class="card-header d-flex justify-content-between align-items-center">
                              <h5 class="mb-0 text-primary fw-bold">Edit NIDN, NIP, Sertifikat, & Jabatan</h5><br>
                            </div>
                            <div class="card-body">
                            <?php if(isset($_SESSION['message'])) : ?>
                                <h5 class="alert alert-success"><?= $_SESSION['message']; ?></h5>
                            <?php 
                                unset($_SESSION['message']);
                                endif; 
                            ?>
                            <?php if(isset($_SESSION['xmessage'])) : ?>
                                <h5 class="alert alert-danger"><?= $_SESSION['xmessage']; ?></h5>
                            <?php 
                                unset($_SESSION['xmessage']);
                                endif; 
                            ?>
                              <form action="upd_institusi.php" method="POST">
                                <div class="mb-3">
                                  <label class="form-label" for="Nidn">NIDN</label>
                                  <div class="input-group input-group-merge">
                                    <span id="Nidn1" class="input-group-text"><i class="ti ti-id"></i></span>
                                    <input type="number" name="nidn" id="Nidn" class="form-control" placeholder="Masukkan nomor NIDN" aria-label="Masukkan nomor NIDN" aria-describedby="Nidn1" value ="<?php echo $nidn; ?>"/>
                                  </div>
                                </div>
                                <div class="mb-3">
                                  <label class="form-label" for="Nip">NIP/Kepeg</label>
                                  <div class="input-group input-group-merge">
                                    <span id="Nip1" class="input-group-text"><i class="ti ti-id-badge-2"></i></span>
                                    <input type="number" name="nip" id="Nip" class="form-control" placeholder="Masukkan nomor NIP" aria-label="Masukkan nomor NIP" aria-describedby="Nip1" value ="<?php echo $nip; ?>"/>
                                  </div>
                                </div>
                                <div class="mb-3">
                                  <label class="form-label" for="Sertifikat">No. Sertifikat</label>
                                  <div class="input-group input-group-merge">
                                    <span id="Sertifikat1" class="input-group-text"><i class="ti ti-certificate"></i></span>
                                    <input type="text" name="no_sert" id="Sertifikat" class="form-control" placeholder="Masukkan nomor sertifikat" aria-label="Masukkan nomor sertifikat" aria-describedby="Sertifikat1" value ="<?php echo $no_sert; ?>"/>
                                  </div>
                                </div>
                                <div class="mb-3">
                                  <label class="form-label" for="jenis">Jenis:</label>
                                  <div class="input-group input-group-merge">
                                    <span id="jenis1" class="input-group-text"><i class="ti ti-badges"></i></span>
                                    <select id="jenis" name ="jenis_ds" class="select2 form-select form-control" data-allow-clear="true">
                                        <?php foreach ($jenis_options as $option) : ?>
                                            <option value="<?php echo $option; ?>" <?php echo ($option == $jenis_ds) ? 'selected' : ''; ?>>
                                                <?php echo $option; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>                                    
                                  </div>
                                </div>                                
                                <div class="mb-3">
                                  <label class="form-label" for="jabatan">Jabatan / Fungsional:</label>
                                  <div class="input-group input-group-merge">
                                    <span id="jabatan1" class="input-group-text"><i class="ti ti-badges"></i></span>
                                    <select id="jabatan" name ="jbtn_fung" class="select2 form-select form-control" data-allow-clear="true">
                                        <?php foreach ($jbtn_fung_options as $option) : ?>
                                            <option value="<?php echo $option; ?>" <?php echo ($option == $jbtn_fung) ? 'selected' : ''; ?>>
                                                <?php echo $option; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>                                    
                                  </div>
                                </div>
                                <div class="mb-3">
                                  <label class="form-label" for="golongan">Golongan / Pangkat:</label>
                                  <div class="input-group input-group-merge">
                                    <span id="golongan1" class="input-group-text"><i class="ti ti-badges"></i></span>
                                    <select id="golongan" name ="gol_pang" class="select2 form-select form-control" data-allow-clear="true">
                                        <?php foreach ($gol_pang_options as $option) : ?>
                                            <option value="<?php echo $option; ?>" <?php echo ($option == $gol_pang) ? 'selected' : ''; ?>>
                                                <?php echo $option; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>                                    
                                  </div>
                                </div>
                                <hr class="my-4 mx-n4" />
                              <h5 class="mb-0">Edit Kantor dan Home Base</h5>
                              <p class="text-danger fs-tiny fw-bold mb-3"><i class="ti ti-eye"></i> PASTIKAN MEMILIH KEMBALI JURUSAN JIKA MERUBAH DATA DI HALAMAN INI!</p>

                                <div class="mb-3">
                                  <label class="form-label" for="fakultas">FAKULTAS</label>
                                  <div class="input-group input-group-merge">
                                    <span id="fakultas1" class="input-group-text"><i class="ti ti-building"></i></span>
                                    <select id="fakultas" name ="fakultas" class="select2 form-select form-control" data-allow-clear="true">
                                        <?php foreach ($fakultas_options as $option) : ?>
                                            <option value="<?php echo $option; ?>" <?php echo ($option == $fakultas) ? 'selected' : ''; ?>>
                                                <?php echo $option; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>                                    
                                  </div>
                                </div>
                                <div class="row">
                                    <div class="col-6 mb-3" id="d">
                                        <label class="form-label fw-bold" for="">JURUSAN DIPILIH</label><br>
                                        <?php
                                        // Check if $fotoprofil_url is empty or null
                                        if (!empty($jurusan)) {
                                            // If $fotoprofil_url contains a valid image URL, display the user's image
                                        ?>
                    					  <p class="badge bg-success fs-6"><i class="ti ti-building"></i> <?php echo $jurusan; ?></p>
                    					  <?php
                                            } else {
                                                // If $fotoprofil_url is empty or null, display a default image
                                                ?>
                                                <p class="badge bg-danger fs-6"><i class="ti ti-building"></i> BELUM MEMILIH JURUSAN</p>
                                                <?php
                                            }
                                            ?>
                                        
                                    </div>
                                    <div class="col-6 mb-3" id="jurSatu" style="display:none;">
                                      <label class="form-label" for="jurSatu">JURUSAN</label>
                                      <div class="input-group input-group-merge">
                                        <span id="jurSatu1" class="input-group-text"><i class="ti ti-building"></i></span>
                                        <select id="jurSatu" name ="jur_satu" class="select2 form-select form-control" data-allow-clear="true">
                                            <?php foreach ($jurusan_satu_options as $option) : ?>
                                                <option value="<?php echo $option; ?>" <?php echo ($option == $jur_satu) ? 'selected' : ''; ?>>
                                                    <?php echo $option; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>                                    
                                      </div>
                                    </div>
                                    <div class="col-6 mb-3" id="jurDua" style="display:none;">
                                      <label class="form-label" for="jurDua">JURUSAN</label>
                                      <div class="input-group input-group-merge">
                                        <span id="jurDua1" class="input-group-text"><i class="ti ti-building"></i></span>
                                        <select id="jurDua" name ="jur_dua" class="select2 form-select form-control" data-allow-clear="true">
                                            <?php foreach ($jurusan_dua_options as $option) : ?>
                                                <option value="<?php echo $option; ?>" <?php echo ($option == $jur_dua) ? 'selected' : ''; ?>>
                                                    <?php echo $option; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>                                    
                                      </div>
                                    </div>
                                    <div class="col-6 mb-3" id="jurTiga" style="display:none;">
                                      <label class="form-label" for="jurTiga">JURUSAN</label>
                                      <div class="input-group input-group-merge">
                                        <span id="jurTiga1" class="input-group-text"><i class="ti ti-building"></i></span>
                                        <select id="jurTiga" name ="jur_tiga" class="select2 form-select form-control" data-allow-clear="true">
                                            <?php foreach ($jurusan_tiga_options as $option) : ?>
                                                <option value="<?php echo $option; ?>" <?php echo ($option == $jur_tiga) ? 'selected' : ''; ?>>
                                                    <?php echo $option; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>                                    
                                      </div>
                                    </div>
                                    <div class="col-6 mb-3" id="jurEmpat" style="display:none;">
                                      <label class="form-label" for="jurEmpat">JURUSAN</label>
                                      <div class="input-group input-group-merge">
                                        <span id="jurEmpat1" class="input-group-text"><i class="ti ti-building"></i></span>
                                        <select id="jurEmpat" name ="jur_empat" class="select2 form-select form-control" data-allow-clear="true">
                                            <?php foreach ($jurusan_empat_options as $option) : ?>
                                                <option value="<?php echo $option; ?>" <?php echo ($option == $jur_empat) ? 'selected' : ''; ?>>
                                                    <?php echo $option; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>                                    
                                      </div>
                                    </div>
                                    <div class="col-6 mb-3" id="jurLima" style="display:none;">
                                      <label class="form-label" for="jurLima">JURUSAN</label>
                                      <div class="input-group input-group-merge">
                                        <span id="jurLima1" class="input-group-text"><i class="ti ti-building"></i></span>
                                        <select id="jurLima" name ="jur_lima" class="select2 form-select form-control" data-allow-clear="true">
                                            <?php foreach ($jurusan_lima_options as $option) : ?>
                                                <option value="<?php echo $option; ?>" <?php echo ($option == $jur_lima) ? 'selected' : ''; ?>>
                                                    <?php echo $option; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>                                    
                                      </div>
                                    </div>
                                    <!--<div class="col-6 mb-5" id="btnDel">
                                        <label class="form-label" for="delJur">MAU GANTI HOME BASE?</label></br>
                                        <button type="button" id="delJur" class="btn btn-lg btn-sm btn-danger position-absolute bottom p-2" onclick="deleteData(<?php //echo isset($row->user_id) ? $row->user_id : '0'; ?>)"><i class="ti ti-trash"></i> HAPUS JURUSAN DULU</button>
                                    </div>-->
                                </div>
                                <div class="mb-3">
                                  <label class="form-label" for="alamatKantor">Alamat Kantor</label>
                                  <div class="input-group input-group-merge">
                                    <span id="alamatKantor1" class="input-group-text"><i class="ti ti-building"></i></span>
                                    <input type="text" name="almt_kntr" id="alamatKantor" class="form-control" placeholder="Alamat lengkap kantor" aria-label="Alamat lengkap kantor" aria-describedby="alamatKantor1" value ="<?php echo $almt_kntr; ?>"/>
                                  </div>
                                </div>
                                <button type="submit" class="btn btn-primary">SIMPAN</button> <small class="text-danger float-end">Jangan lupa disimpan</small>
                              </form>
                            </div>
                          </div>
        				</div>
                </div>
            </div>

            <!-- / Content -->

<!-- Tampilan kolom jurusan dinamis -->
<script>
  const selectElement = document.getElementById("fakultas");

  selectElement.addEventListener("change", updateInputFields);

  // Check the initial value on page load
  document.addEventListener("DOMContentLoaded", () => {
    updateInputFields();
  });

  function updateInputFields() {
    const selectedOptionValue = selectElement.value;

    // Hide all input fields initially
    hideAllInputFields();

    // Show the relevant input field based on the selected option
    if (selectedOptionValue === "SYARIAH") {
      showInputField("jurSatu");
    } else if (selectedOptionValue === "TARBIYAH DAN ILMU KEGURUAN") {
      showInputField("jurDua");
    } else if (selectedOptionValue === "USHULUDDIN ADAB DAN DAKWAH") {
      showInputField("jurTiga");
    } else if (selectedOptionValue === "EKONOMI DAN BISNIS ISLAM") {
      showInputField("jurEmpat");
    } else if (selectedOptionValue === "PASCASARJANA") {
      showInputField("jurLima");
    }
  }

  function hideAllInputFields() {
    const inputFields = ["jurSatu", "jurDua", "jurTiga", "jurEmpat", "jurLima"];
    inputFields.forEach((field) => {
      document.getElementById(field).style.display = "none";
    });
  }

  function showInputField(fieldId) {
    document.getElementById(fieldId).style.display = "block";
  }
</script>

<!-- Hapus Jurusan -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
function deleteData(userId) {
    console.log("Menghapus jurusan untuk user:", userId);

    if (confirm("Anda yakin mau menghapus jurusan?")) {
        $.ajax({
            type: "POST",
            url: "del_jur.php",
            data: { del_data: userId },
            success: function(response) {
                console.log("Response from del_jur.php:", response);
                alert(response);
                // Reload the page after successful deletion
                location.reload(true);
            },
            error: function(xhr, textStatus, errorThrown) {
                console.error("Error:", textStatus, errorThrown);
                alert("Error: Internal Server Error");
            }
        });
    }
}
</script>

<?php require_once ("../includes/footer.php"); ?>