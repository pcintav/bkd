<?php require_once ("../includes/header.php"); ?>
<?php require_once ("../includes/sidebar.php"); ?>
<?php require_once ("../includes/topbar.php"); ?>
<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
?>

    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y small">
     <div class="row">    
      <div class="col">
          
         <div class="card mb-3">
          <div class="card-body">
              <span class="text-primary fs-6 muted">Hai <?php echo " " . htmlspecialchars($_SESSION['nama']) . "!"; ?></span><br>
              <span class="mb-5">Silahkan buat sekali saja template rencana BKD baru Anda untuk periode aktif, dan pastikan disimpan,<br> sedangkan untuk mengedit ulang atau memperbarui data rencana BKD tersebut, lihat di list RBKD di halaman Rencana BKD.</span>
              <?php if(isset($_SESSION['xmessage'])) : ?>
                <h6 class="alert alert-danger"><?= $_SESSION['xmessage']; ?></h6>
                <?php 
                    unset($_SESSION['xmessage']);
                    endif; 
                ?>
                <?php if(isset($_SESSION['message'])) : ?>
                <h6 class="alert alert-success"><?= $_SESSION['message']; ?></h6>
                <?php 
                    unset($_SESSION['message']);
                    endif; 
                ?>
                <?php
                            
                // Query to fetch data from thn_akademik table
                $query = "SELECT tahun FROM thn_akademik";
                
                try {
                    // Prepare and execute the query
                    $statement = $conn->prepare($query);
                    $statement->execute();
                
                    // Fetch all tahun records
                    $tahun_records = $statement->fetchAll(PDO::FETCH_ASSOC);
                } catch (PDOException $e) {
                    die("Error fetching tahun records: " . $e->getMessage());
                }
                ?>
                <?php
                
                // Query to fetch data from thn_akademik table
                $query = "SELECT strb_op FROM status_rbkd";
                
                try {
                    // Prepare and execute the query
                    $statement = $conn->prepare($query);
                    $statement->execute();
                
                    // Fetch all tahun records
                    $strbkd_records = $statement->fetchAll(PDO::FETCH_ASSOC);
                } catch (PDOException $e) {
                    die("Error fetching status rbkd records: " . $e->getMessage());
                }
                ?>
                            
            <form class="needs-validation mt-5" action="nbkd_act.php" method="POST">
                <table class="table table-sm table-responsive table-bordered mt-1" style="font-size:12px;">
                    <thead>
                        <tr class="border border-0">
                            <span class="badge bg-white me-1 p-0">
                                  <select name="tahun" id="tahun" class="select2 form-select form-select-sm" data-allow-clear="true">
                                        <?php foreach ($tahun_records as $tahun_record): ?>
                                            <option value="<?php echo htmlspecialchars($tahun_record['tahun']); ?>"><?php echo htmlspecialchars($tahun_record['tahun']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                            </span>
                            <span class="badge bg-white me-1 p-0">
                                  <select name="semester" id="select2Basic" class="select2 form-select form-select-sm">
                                  <option value="" selected>Pilih Semester</option>
                                  <option value="Ganjil">Ganjil</option>
                                  <option value="Genap">Genap</option>
                                  </select>
                            </span>
                            <span class="badge bg-white me-1 p-0">
                                <select name="status_rb" id="statusRbkd" class="select2 form-select form-select-sm" data-allow-clear="true">
                                    <?php foreach ($strbkd_records as $index => $strbkd_record): ?>
                                        <?php if ($index === 0) : ?>
                                            <option value="<?php echo htmlspecialchars($strbkd_record['strb_op']); ?>" selected><?php echo htmlspecialchars($strbkd_record['strb_op']); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo htmlspecialchars($strbkd_record['strb_op']); ?>" style="display:none;"><?php echo htmlspecialchars($strbkd_record['strb_op']); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </select>
                            </span>
                            <a href="#" class="text-danger pt-2 h5 float-end"><i class="ti ti-help-hexagon-filled me-2"></i></a>
                        </tr>
                        <tr class="border border-top-1">
                            <td></td>
                            <td colspan="2" class="fs-6 fw-bold text-center align-middle">BIDANG KEGIATAN</td>
                            <td colspan="2" class="thnbkd border border-1 fs-6 fw-bold text-center align-middle">BEBAN KERJA</td>
                            <td class="text-center lh-sm align-middle"><span class="fs-tiny fw-bold">MASA TUGAS</span></td>
                            <td class="text-center lh-sm align-middle"><span class="fs-tiny lh-1 fw-bold ">BUKTI</span></td>
                        </tr>
                        <tr class="text-center align-middle border border-2">
                            <th class="thnbkdwd">No.</th>
                            <th colspan="2" class="thnbkd">Nama Kegiatan</th>
                            <th class="thnbkd">Bukti Penugasan</th>
                            <th class="thnbkdwd">SKS</th>
                            <th class="thnbkdwd">Jml Smtr</th>
                            <th class="thnbkdwd">File</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <tr>
                            <td class="text-center">01</td>
                            <th rowspan="8" class="thnbkdr"><span class="rotated fs-6 text-danger">PENDIDIKAN</span></th>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd1" id="anpdBKD1" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd1" id="appdBKD1" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd1" id="skspdBKD1" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd1" id="smtpdBKD1" min="0" max="12" step=".5" ></td>                                
                            <td> <!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd1"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd1" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 1</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD1a">File 1</label>
                                                <input type="text" id="docpdBKD1a" name="docpdbkd1a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD1b">File 2</label>
                                                <input type="text" id="docpdBKD1b" name="docpdbkd1b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD1c">File 3</label>
                                                <input type="text" id="docpdBKD1c" name="docpdbkd1c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                            </td>
                        </tr>  
                        <tr class="tr1" id="tr2">
                            <td class="text-center">02</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd2" id="anpdBKD2" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd2" id="appdBKD2" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd2" id="skspdBKD2" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd2" id="smtpdBKD2" min="0" max="12" step=".5" ></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd2"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd2" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 2</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD2a">File 1</label>
                                                <input type="text" id="docpdBKD2a" name="docpdbkd2a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD2b">File 2</label>
                                                <input type="text" id="docpdBKD2b" name="docpdbkd2b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD2c">File 3</label>
                                                <input type="text" id="docpdBKD2c" name="docpdbkd2c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">03</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd3" id="anpdBKD3" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd3" id="appdBKD3" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd3" id="skspdBKD3" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd3" id="smtpdBKD3" min="0" max="12" step=".5" ></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd3"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd3" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 3</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD3a">File 1</label>
                                                <input type="text" id="docpdBKD3a" name="docpdbkd3a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD3b">File 2</label>
                                                <input type="text" id="docpdBKD3b" name="docpdbkd3b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD3c">File 3</label>
                                                <input type="text" id="docpdBKD3c" name="docpdbkd3c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">04</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd4" id="anpdBKD4" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd4" id="appdBKD4" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd4" id="skspdBKD4" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd4" id="smtpdBKD4" min="0" max="12" step=".5" ></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd4"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd4" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 4</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD4a">File 1</label>
                                                <input type="text" id="docpdBKD4a" name="docpdbkd4a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD4b">File 2</label>
                                                <input type="text" id="docpdBKD4b" name="docpdbkd4b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD4c">File 3</label>
                                                <input type="text" id="docpdBKD4c" name="docpdbkd4c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">05</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd5" id="anpdBKD5" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd5" id="appdBKD5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd5" id="skspdBKD5" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd5" id="smtpdBKD5" min="0" max="12" step=".5" ></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd5"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd5" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 5</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD5a">File 1</label>
                                                <input type="text" id="docpdBKD5a" name="docpdbkd5a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD5b">File 2</label>
                                                <input type="text" id="docpdBKD5b" name="docpdbkd5b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD5c">File 3</label>
                                                <input type="text" id="docpdBKD5c" name="docpdbkd5c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">06</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd6" id="anpdBKD6" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd6" id="appdBKD6" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd6" id="skspdBKD6" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd6" id="smtpdBKD6" min="0" max="12" step=".5" ></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd6"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd6" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 6</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD6a">File 1</label>
                                                <input type="text" id="docpdBKD6a" name="docpdbkd6a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD6b">File 2</label>
                                                <input type="text" id="docpdBKD6b" name="docpdbkd6b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD6c">File 3</label>
                                                <input type="text" id="docpdBKD6c" name="docpdbkd6c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">07</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd7" id="anpdBKD7" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd7" id="appdBKD7" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd7" id="skspdBKD7" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd7" id="smtpdBKD7" min="0" max="12" step=".5" ></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd7"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd7" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 7</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD7a">File 1</label>
                                                <input type="text" id="docpdBKD7a" name="docpdbkd7a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD6b">File 2</label>
                                                <input type="text" id="docpdBKD7b" name="docpdbkd7b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD7c">File 3</label>
                                                <input type="text" id="docpdBKD7c" name="docpdbkd7c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">08</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd8" id="anpdBKD8" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd8" id="appdBKD8" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd8" id="skspdBKD8" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd8" id="smtpdBKD8" min="0" max="12" step=".5" ></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd8"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd8" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 8</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD8a">File 1</label>
                                                <input type="text" id="docpdBKD8a" name="docpdbkd8a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD8b">File 2</label>
                                                <input type="text" id="docpdBKD8b" name="docpdbkd8b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD8c">File 3</label>
                                                <input type="text" id="docpdBKD8c" name="docpdbkd8c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr class="border border-0">
                            <td colspan="6" class="border border-0"></td>
                        </tr>                            
                        <tr class="text-center border border-2">
                            <th class="thnbkdwd py-2">No.</th>
                            <th colspan="2" class="thnbkd">Nama Kegiatan</th>
                            <th class="thnbkd">Bukti Penugasan</th>
                            <th class="thnbkdwd">SKS</th>
                            <th class="thnbkdwd">Jml Smtr</th>
                            <th class="thnbkdwd">File</th>
                        </tr>
                        <tr>
                            <td class="text-center">01</td>
                            <th rowspan="4" class="thnbkdr"><span class="rotated fs-6 text-danger">PENELITIAN</span></th>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anplbkd1" id="anplBKD1" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="applbkd1" id="applBKD1" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="sksplbkd1" id="sksplBKD1" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtplbkd1" id="smtplBKD1" min="0" max="12" step=".5" ></td>                                
                            <td> <!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docplbkd1"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docplbkd1" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penelitian RBKD 1</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD1a">File 1</label>
                                                <input type="text" id="docplBKD1a" name="docplbkd1a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD1b">File 2</label>
                                                <input type="text" id="docplBKD1b" name="docplbkd1b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD1c">File 3</label>
                                                <input type="text" id="docplBKD1c" name="docplbkd1c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">02</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anplbkd2" id="anplBKD2" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="applbkd2" id="applBKD2" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="sksplbkd2" id="sksplBKD2" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtplbkd2" id="smtplBKD2" min="0" max="12" step=".5" ></td>                                
                            <td> <!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docplbkd2"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docplbkd2" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penelitian RBKD 2</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD2a">File 1</label>
                                                <input type="text" id="docplBKD2a" name="docplbkd2a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD2b">File 2</label>
                                                <input type="text" id="docplBKD2b" name="docplbkd2b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD2c">File 3</label>
                                                <input type="text" id="docplBKD2c" name="docplbkd2c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">03</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anplbkd3" id="anplBKD3" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="applbkd3" id="applBKD3" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="sksplbkd3" id="sksplBKD3" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtplbkd3" id="smtplBKD3" min="0" max="12" step=".5" ></td>                                
                            <td> <!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docplbkd3"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docplbkd3" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penelitian RBKD 3</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD3a">File 1</label>
                                                <input type="text" id="docplBKD3a" name="docplbkd3a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD3b">File 2</label>
                                                <input type="text" id="docplBKD3b" name="docplbkd3b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD3c">File 3</label>
                                                <input type="text" id="docplBKD3c" name="docplbkd3c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">04</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anplbkd4" id="anplBKD4" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="applbkd4" id="applBKD4" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="sksplbkd4" id="sksplBKD4" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtplbkd4" id="smtplBKD4" min="0" max="12" step=".5" ></td>                                
                            <td> <!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docplbkd4"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docplbkd4" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penelitian RBKD 4</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD4a">File 1</label>
                                                <input type="text" id="docplBKD4a" name="docplbkd4a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD4b">File 2</label>
                                                <input type="text" id="docplBKD4b" name="docplbkd4b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD4c">File 3</label>
                                                <input type="text" id="docplBKD4c" name="docplbkd4c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr class="border border-0">
                            <td colspan="6" class="border border-0"></td>
                        </tr>                            
                        <tr class="text-center border border-2">
                            <th class="thnbkdwd py-2">No.</th>
                            <th colspan="2" class="thnbkdr">Nama Kegiatan</th>
                            <th class="thnbkd">Bukti Penugasan</th>
                            <th class="thnbkdwd">SKS</th>
                            <th class="thnbkdwd">Jml Smtr</th>
                            <th class="thnbkdwd">File</th>
                        </tr>
                        <tr>
                            <td class="text-center">01</td>
                            <th rowspan="4" class="thnbkdr"><span class="rotated fs-6 text-danger">PENGABDIAN</span></th>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpgbkd1" id="anpgBKD1" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appgbkd1" id="appgBKD1" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspgbkd1" id="skspgBKD1" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpgbkd1" id="smtpgBKD1" min="0" max="12" step=".5" ></td>                                
                            <td> <!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpgbkd1"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpgbkd1" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pengabdian RBKD 1</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD1a">File 1</label>
                                                <input type="text" id="docpgBKD1a" name="docpgbkd1a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD1b">File 2</label>
                                                <input type="text" id="docpgBKD1b" name="docpgbkd1b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD1c">File 3</label>
                                                <input type="text" id="docpgBKD1c" name="docpgbkd1c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">02</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpgbkd2" id="anpgBKD2" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appgbkd2" id="appgBKD2" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspgbkd2" id="skspgBKD2" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpgbkd2" id="smtpgBKD2" min="0" max="12" step=".5" ></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpgbkd2"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpgbkd2" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pengabdian RBKD 2</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD2a">File 1</label>
                                                <input type="text" id="docpgBKD2a" name="docpgbkd2a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD2b">File 2</label>
                                                <input type="text" id="docpgBKD2b" name="docpgbkd2b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD2c">File 3</label>
                                                <input type="text" id="docpgBKD2c" name="docpgbkd2c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">03</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpgbkd3" id="anpgBKD3" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appgbkd3" id="appgBKD3" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspgbkd3" id="skspgBKD3" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpgbkd3" id="smtpgBKD3" min="0" max="12" step=".5" ></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpgbkd3"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpgbkd3" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pengabdian RBKD 3</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD3a">File 1</label>
                                                <input type="text" id="docpgBKD3a" name="docpgbkd3a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD3b">File 2</label>
                                                <input type="text" id="docpgBKD3b" name="docpgbkd3b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD3c">File 3</label>
                                                <input type="text" id="docpgBKD3c" name="docpgbkd3c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document --></td>
                        </tr>
                        <tr>
                            <td class="text-center">04</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpgbkd4" id="anpgBKD4" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appgbkd4" id="appgBKD4" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspgbkd4" id="skspgBKD4" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpgbkd4" id="smtpgBKD4" min="0" max="12" step=".5" ></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpgbkd4"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpgbkd4" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pengabdian RBKD 4</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD4a">File 1</label>
                                                <input type="text" id="docpgBKD4a" name="docpgbkd4a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD4b">File 2</label>
                                                <input type="text" id="docpgBKD4b" name="docpgbkd4b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD4c">File 3</label>
                                                <input type="text" id="docpgBKD4c" name="docpgbkd4c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr class="border border-0">
                            <td colspan="6" class="border border-0"></td>
                        </tr>                            
                        <tr class="text-center border border-2">
                            <th class="thnbkdwd py-2">No.</th>
                            <th colspan="2" class="thnbkdr">Nama Kegiatan</th>
                            <th class="thnbkd">Bukti Penugasan</th>
                            <th class="thnbkdwd">SKS</th>
                            <th class="thnbkdwd">Jml Smtr</th>
                            <th class="thnbkdwd">File</th>
                        </tr>
                        <tr>
                            <td class="text-center">01</td>
                            <th rowspan="4" class="thnbkdr"><span class="rotated fs-6 text-danger">PENUNJANG</span></th>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpjbkd1" id="anpjBKD1" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appjbkd1" id="appjBKD1" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspjbkd1" id="skspjBKD1" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpjbkd1" id="smtpjBKD1" min="0" max="12" step=".5" ></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpjbkd1"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpjbkd1" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penunjang RBKD 1</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD1a">File 1</label>
                                                <input type="text" id="docpjBKD1a" name="docpjbkd1a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD1b">File 2</label>
                                                <input type="text" id="docpjBKD1b" name="docpjbkd1b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD1c">File 3</label>
                                                <input type="text" id="docpjBKD1c" name="docpjbkd1c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">02</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpjbkd2" id="anpjBKD2" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appjbkd2" id="appjBKD2" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspjbkd2" id="skspjBKD2" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpjbkd2" id="smtpjBKD2" min="0" max="12" step=".5" ></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpjbkd2"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpjbkd2" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penunjang RBKD 2</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD2a">File 1</label>
                                                <input type="text" id="docpjBKD2a" name="docpjbkd2a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD2b">File 2</label>
                                                <input type="text" id="docpjBKD2b" name="docpjbkd2b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD2c">File 3</label>
                                                <input type="text" id="docpjBKD2c" name="docpjbkd2c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">03</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpjbkd3" id="anpjBKD3" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appjbkd3" id="appjBKD3" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspjbkd3" id="skspjBKD3" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpjbkd3" id="smtpjBKD3" min="0" max="12" step=".5" ></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpjbkd3"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpjbkd3" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penunjang RBKD 3</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD3a">File 1</label>
                                                <input type="text" id="docpjBKD3a" name="docpjbkd3a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD3b">File 2</label>
                                                <input type="text" id="docpjBKD3b" name="docpjbkd3b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD3c">File 3</label>
                                                <input type="text" id="docpjBKD3c" name="docpjbkd3c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">04</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpjbkd4" id="anpjBKD4" ></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appjbkd4" id="appjBKD4" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspjbkd4" id="skspjBKD4" min="0" max="12" step=".5" ></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpjbkd4" id="smtpjBKD4" min="0" max="12" step=".5" ></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpjbkd4"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpjbkd4" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penunjang RBKD 4</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD4a">File 1</label>
                                                <input type="text" id="docpjBKD4a" name="docpjbkd4a" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD4b">File 2</label>
                                                <input type="text" id="docpjBKD4b" name="docpjbkd4b" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD4c">File 3</label>
                                                <input type="text" id="docpjBKD4c" name="docpjbkd4c" class="form-control form-control-sm" placeholder="Sematkan URL/Link dokumen di sini" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>                            
                    </tbody>
                </table>
                <button type="submit" class="btn btn-danger float-end mt-3" name="submit_bkd" id="Submit">SIMPAN RBKD BARU</button>
            </form>
           </div>
          </div>
         
         </div>
     </div>           
    </div>
    <!-- / Content -->



<script>
         // adjust width on initial load
         window.onload = adjustWidth;
         
         // Select the input field
         var inputField = document.querySelector("#myInput");
         
         // Add an event listener to the input field
         inputField.addEventListener("input", adjustWidth);
         
         // Function to adjust the width of the input field
         function adjustWidth() {
            var value = inputField.value;
            var width = value.length * 30 + 100; // 8px per character
            inputField.style.width = width + "px";
         }
      
</script>

<?php require_once ("../includes/footer.php"); ?>