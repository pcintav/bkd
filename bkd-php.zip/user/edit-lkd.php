<?php require_once ("../includes/header.php"); ?>
<?php require_once ("../includes/sidebar.php"); ?>
<?php require_once ("../includes/topbar.php"); ?>


    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
      <h4 class="py-3 mb-1">NEW LKD</h4>
      <p>
        Sample page.<br />For more layout options use
        <a href="" target="_blank" class="fw-medium">HTML starter template generator</a> and refer
        <a
          href="https://demos.pixinvent.com/vuexy-html-admin-template/documentation//layouts.html"
          target="_blank"
          class="fw-medium"
          >Layout docs</a
        >.
      </p>
    </div>
    <!-- / Content -->



<?php require_once ("../includes/footer.php"); ?>