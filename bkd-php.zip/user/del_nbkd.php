<?php
session_start();
include('./../includes/Dtbase.php'); // Include your database connection file

// Instantiate the DatabaseConnection class
$databaseConnection = new DatabaseConnection();
$conn = $databaseConnection->getConnection();

if (isset($_SESSION['user_id']) && isset($_POST['del_data'])) {
    $user_id = $_SESSION['user_id'];
    $rep_id = $_POST['del_data'];

    try {
        // Make sure to validate user_id and rep_id to prevent SQL injection

        // Prepare the DELETE query
        $query = "DELETE FROM bkd_reports WHERE user_id = :user_id AND rep_id = :rep_id";

        $statement = $conn->prepare($query);

        if (!$statement) {
            die("Persiapan eksekusi gagal: " . $conn->errorInfo()[2]);
        }

        // Bind parameters and execute the statement
        $data = [
            ':user_id' => $user_id,
            ':rep_id' => $rep_id
        ];

        $query_execute = $statement->execute($data);

        if ($query_execute) {
            $_SESSION['message'] = "Data berhasil dihapus.";
        } else {
            $_SESSION['xmessage'] = "Data gagal dihapus.";
        }
    } catch (PDOException $e) {
        // Log the detailed error message
        error_log("PDOException: " . $e->getMessage());

        // Display a user-friendly error message on the page
        echo "Terjadi error yang tidak diharapkan. Silahkan coba lagi.";
        exit; // Exit the script after displaying error message
    }
}

// Get the nidn from the session
$nidn = $_SESSION['nidn'] ?? '';

// Redirect to the specified URL
header("Location: /user/rbkd-report?bkdr=$nidn");
exit(); // Ensure script execution stops after redirection
?>
