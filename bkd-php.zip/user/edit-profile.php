<?php require_once ("../includes/header.php"); ?>
<?php require_once ("../includes/sidebar.php"); ?>
<?php require_once ("../includes/topbar.php"); ?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>     
     <!-- Content -->


    <div class="container-xxl flex-grow-1 container-p-y small">
			
		<div class="row">
			<!-- main col -->
				<div class="col pb-5">
				<div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Edit Informasi Anda</h5>
                    </div>
                    <div class="card-body">
                    <?php if(isset($_SESSION['message'])) : ?>
                        <h5 class="alert alert-success"><?= $_SESSION['message']; ?></h5>
                    <?php 
                        unset($_SESSION['message']);
                        endif; 
                    ?>
                    <?php if(isset($_SESSION['xmessage'])) : ?>
                        <h5 class="alert alert-danger"><?= $_SESSION['xmessage']; ?></h5>
                    <?php 
                        unset($_SESSION['xmessage']);
                        endif; 
                    ?>
                      <form action="upd_profile.php" method="POST">
                        <div class="row"></div>
                        <div class="mt-4 mb-3">
                          <label class="form-label" for="Nama">Nama Lengkap</label>
                          <div class="input-group input-group-merge">
                            <span id="Nama1" class="input-group-text"><i class="ti ti-user"></i></span>
                            <input type="text" name="nama" class="form-control" id="Nama" placeholder="Tulis nama lengkap tanpa gelar" aria-label="Nama Anda" aria-describedby="Nama1" value ="<?php echo $nama; ?>"/>
                          </div>
                        </div>
                        <div class="mt-4 mb-3">
                          <label class="form-label" for="gelarDepan">Gelar Depan</label>
                          <div class="input-group input-group-merge">
                            <span id="gelarDepan1" class="input-group-text"><i class="ti ti-ballpen"></i></span>
                            <input type="text" name="glr_depan" class="form-control" id="gelarDepan" placeholder="Tulis tanpa gelar depan saja" aria-label="Gelar Depan" aria-describedby="gelarDepan1" value ="<?php echo $glr_depan; ?>"/>
                          </div>
                        </div>
                        <div class="mt-4 mb-3">
                          <label class="form-label" for="gelarBelakang">Gelar Belakang</label>
                          <div class="input-group input-group-merge">
                            <span id="gelarBelakang1" class="input-group-text"><i class="ti ti-ballpen"></i></span>
                            <input type="text" name="glr_belakang" class="form-control" id="gelarBelakang" placeholder="Tulis gelar belakang saja" aria-label="Gelar Belakang" aria-describedby="gelarBelakang1" value ="<?php echo $glr_belakang; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="tglLahir">Tanggal Lahir</label>
                          <div class="input-group input-group-merge">
                            <span id="tglLahir1" class="input-group-text"><i class="ti ti-calendar"></i></span>
                            <input type="date" name="tgl_lhr" class="form-control" id="tglLahir" placeholder="Pilih tanggal lahir" aria-label="Tanggal Lahir" aria-describedby="tglLahir1" pattern="\d{4}-\d{2}-\d{2}" value ="<?php echo $tgl_lhr; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="tmpLahir">Tempat Lahir</label>
                          <div class="input-group input-group-merge">
                            <span id="tmpLahir1" class="input-group-text"><i class="ti ti-location"></i></span>
                            <input type="text" name="tmpt_lhr" class="form-control" id="tmpLahir" placeholder="Tulis tempat lahir" aria-label="Tempat Lahir" aria-describedby="tmpLahir1" value ="<?php echo $tmpt_lhr; ?>"/>
                          </div>
                        </div>                        
                        <div class="mb-3">
                          <label class="form-label" for="Alamat">Alamat</label>
                          <div class="input-group input-group-merge">
                            <span id="Alamat1" class="input-group-text"><i class="ti ti-map-pin"></i></span>
                            <input type="text" name="almt_rmh" id="Alamat" class="form-control" placeholder="Tulis alamat lengkap tempat tinggal" aria-label="Alamat Lengkap" aria-describedby="Alamat1" value="<?php echo $almt_rmh; ?>"/>
                          </div>
                        </div>
                        <hr class="my-4 mx-n4" />
                        <div class="mb-3">
                          <label class="form-label" for="noTelp">No. Telephone</label>
                          <div class="input-group input-group-merge">
                            <span id="noTelp1" class="input-group-text"><i class="ti ti-phone"></i></span>
                            <input type="number" name="no_telp" id="noTelp" class="form-control phone-mask" placeholder="082122223333" aria-label="082122223333" aria-describedby="noTelp1" value="<?php echo $no_telp; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="noWa">No. Whatsapp</label>
                          <div class="input-group input-group-merge">
                            <span id="noWa1" class="input-group-text"><i class="ti ti-brand-whatsapp"></i></span>
                            <input type="number" name="no_wa" id="noWa" class="form-control phone-mask" placeholder="082133334444" aria-label="082133334444" aria-describedby="noWa1" value="<?php echo $no_wa; ?>"/>
                          </div>
                        </div>                        
                        <hr class="my-4 mx-n4" />                        
                        <div class="mb-3">
                          <label class="form-label" for="pendSatu">Pendidikan S1</label>
                          <div class="input-group input-group-merge">
                            <span id="pendSatu1" class="input-group-text"><i class="ti ti-school"></i></span>
                            <input type="text" name="pend_s1" id="pendSatu" class="form-control" placeholder="Nama perguruan tinggi S1" aria-label="Nama PT 1" aria-describedby="pendSatu1" value="<?php echo $pend_s1; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="pendDua">Pendidikan S2</label>
                          <div class="input-group input-group-merge">
                            <span id="pendDua1" class="input-group-text"><i class="ti ti-school"></i></span>
                            <input type="text" name="pend_s2" id="pendDua" class="form-control" placeholder="Nama perguruan tinggi S2" aria-label="Nama PT 2" aria-describedby="pendDua1" value="<?php echo $pend_s2; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="pendTiga">Pendidikan S3</label>
                          <div class="input-group input-group-merge">
                            <span id="pendTiga1" class="input-group-text"><i class="ti ti-school"></i></span>
                            <input type="text" name="pend_s3" id="pendTiga" class="form-control" placeholder="Nama perguruan tinggi S3" aria-label="Nama PT 3" aria-describedby="pendTiga1" value="<?php echo $pend_s3; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="bidIlmu">Bidang Keilmuan</label>
                          <div class="input-group input-group-merge">
                            <span id="bidIlmu1" class="input-group-text"><i class="ti ti-microscope"></i></span>
                            <input type="text" name="keilmuan" id="bidIlmu" class="form-control" placeholder="Bidang keahlian" aria-label="Keilmuan" aria-describedby="bidIlmu1" value="<?php echo $keilmuan; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="">TANGGAL DAFTAR: <?php echo $tgl_daftar; ?></label>
                        </div>  
                        <button type="submit" class="btn btn-primary">SIMPAN</button>
                        <small class="text-danger float-end">JANGAN LUPA DISIMPAN</small>
                      </form>
                    </div>
                  </div>
				</div>
        </div>	
	</div>                   


<?php require_once ("../includes/footer.php"); ?>