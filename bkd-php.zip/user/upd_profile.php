<?php
session_start();

// Include your database connection class
include('../includes/Dtbase.php');

// Instantiate the DatabaseConnection class
$databaseConnection = new DatabaseConnection();
$conn = $databaseConnection->getConnection();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the current logged-in user ID from the session
    $user_id = $_SESSION['user_id'];

    // Sanitize and validate form data
    $nama = filter_input(INPUT_POST, 'nama', FILTER_SANITIZE_STRING);
    $glr_depan = filter_input(INPUT_POST, 'glr_depan', FILTER_SANITIZE_STRING);
    $glr_belakang = filter_input(INPUT_POST, 'glr_belakang', FILTER_SANITIZE_STRING);
    $tgl_lhr = filter_input(INPUT_POST, 'tgl_lhr', FILTER_SANITIZE_STRING);
    $tmpt_lhr = filter_input(INPUT_POST, 'tmpt_lhr', FILTER_SANITIZE_STRING);
    $almt_rmh = filter_input(INPUT_POST, 'almt_rmh', FILTER_SANITIZE_STRING);
    $no_telp = filter_input(INPUT_POST, 'no_telp', FILTER_SANITIZE_NUMBER_INT);
    $no_wa = filter_input(INPUT_POST, 'no_wa', FILTER_SANITIZE_NUMBER_INT);
    $pend_s1 = filter_input(INPUT_POST, 'pend_s1', FILTER_SANITIZE_STRING);
    $pend_s2 = filter_input(INPUT_POST, 'pend_s2', FILTER_SANITIZE_STRING);
    $pend_s3 = filter_input(INPUT_POST, 'pend_s3', FILTER_SANITIZE_STRING);
    $keilmuan = filter_input(INPUT_POST, 'keilmuan', FILTER_SANITIZE_STRING);

    $validation_errors = [];

    // Validate input fields
    if (!preg_match("/^[a-zA-Z ]+$/", $nama)) {
        $validation_errors[] = "Invalid value for nama. Only letters and spaces are allowed.";
    }

    if (!preg_match("/^[a-zA-Z ,.]*+$/", $glr_depan)) {
        $validation_errors[] = "Invalid value for glr_depan. Only letters, spaces, commas, and periods are allowed.";
    }

    if (!preg_match("/^[a-zA-Z ,.]+$/", $glr_belakang)) {
        $validation_errors[] = "Invalid value for glr_belakang. Only letters, spaces, commas, and periods are allowed.";
    }

    if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $tgl_lhr)) {
        $validation_errors[] = "Invalid value for tgl_lhr. Must be in the format YYYY-MM-DD.";
    }

    if (!preg_match("/^[a-zA-Z ,.]+$/", $tmpt_lhr)) {
        $validation_errors[] = "Invalid value for tmpt_lhr. Only letters, spaces, commas, and periods are allowed.";
    }

    if (!preg_match('/^[\p{L}0-9\s\/.,\-]+$/u', $almt_rmh)) {
        $validation_errors[] = "Invalid value for almt_rmh. Only letters, numbers, spaces, slashes, commas, periods, and hyphens are allowed.";
    }

    if (!preg_match("/^\d+$/", $no_telp)) {
        $validation_errors[] = "Invalid value for no_telp. Must be a number.";
    }

    if (!preg_match("/^\d+$/", $no_wa)) {
        $validation_errors[] = "Invalid value for no_wa. Must be a number.";
    }

    if (!preg_match("/^[a-zA-Z0-9 ]+$/", $pend_s1)) {
        $validation_errors[] = "Invalid value for pend_s1. Only letters, numbers, and spaces are allowed.";
    }

    if (!preg_match("/^[a-zA-Z0-9 ]+$/", $pend_s2)) {
        $validation_errors[] = "Invalid value for pend_s2. Only letters, numbers, and spaces are allowed.";
    }

    if (!preg_match("/^[a-zA-Z0-9 ]*+$/", $pend_s3)) {
        $validation_errors[] = "Invalid value for pend_s3. Only letters, numbers, and spaces are allowed.";
    }

    if (!preg_match("/^[a-zA-Z ]+$/", $keilmuan)) {
        $validation_errors[] = "Invalid value for keilmuan. Only letters and spaces are allowed.";
    }

    // Check for any validation errors
    if (!empty($validation_errors)) {
        $_SESSION['xmessage'] = implode("<br>", $validation_errors);
        header("Location: /user/edit-profile?epro=");
        exit();
    }

    // Prepare and execute the SQL update statement
    $stmt = $conn->prepare("UPDATE users_bkd SET 
                            nama = :nama,
                            glr_depan = :glr_depan,
                            glr_belakang = :glr_belakang,
                            tgl_lhr = :tgl_lhr,
                            tmpt_lhr = :tmpt_lhr,
                            almt_rmh = :almt_rmh,
                            no_telp = :no_telp,
                            no_wa = :no_wa,
                            pend_s1 = :pend_s1,
                            pend_s2 = :pend_s2,
                            pend_s3 = :pend_s3,
                            keilmuan = :keilmuan
                            WHERE user_id = :user_id");

    $stmt->bindParam(':user_id', $user_id);
    $stmt->bindParam(':nama', $nama);
    $stmt->bindParam(':glr_depan', $glr_depan);
    $stmt->bindParam(':glr_belakang', $glr_belakang);
    $stmt->bindParam(':tgl_lhr', $tgl_lhr);
    $stmt->bindParam(':tmpt_lhr', $tmpt_lhr);
    $stmt->bindParam(':almt_rmh', $almt_rmh);
    $stmt->bindParam(':no_telp', $no_telp);
    $stmt->bindParam(':no_wa', $no_wa);
    $stmt->bindParam(':pend_s1', $pend_s1);
    $stmt->bindParam(':pend_s2', $pend_s2);
    $stmt->bindParam(':pend_s3', $pend_s3);
    $stmt->bindParam(':keilmuan', $keilmuan);

    if ($stmt->execute()) {
        // Update successful
        $_SESSION['message'] = "Profil sukses diperbarui.";
    } else {
        // Update failed
        $_SESSION['xmessage'] = "Profil gagal diperbarui.";
    }

    // Redirect to the profile page or any other appropriate page
    header("Location: /user/edit-profile?epro=");
    exit();
}

// If the form is not submitted, retrieve the user data for pre-filling the form
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users_bkd WHERE user_id = :user_id");
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // Other code for displaying the form with pre-filled data
    // HTML and Bootstrap code for the update form goes here
}
?>
