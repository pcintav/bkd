<?php require_once ("../includes/header.php"); ?>
<?php require_once ("../includes/sidebar.php"); ?>
<?php require_once ("../includes/topbar.php"); ?>
<?php
// Fetch preview image URLs from the database
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

// Default image URLs
$foto_profil_url = 'https://bkd.hostku.xyz/assets/img/avatars/profile-placeholder.jpg';
$foto_ktp_url = 'https://bkd.hostku.xyz/assets/img/avatars/ktp-placeholder.jpg';

if ($user_id) {
    $stmt = $conn->prepare("SELECT fotoprofil_url, fotoktp_url FROM users_bkd WHERE user_id = :user_id");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if the result is not empty before assigning values
    if ($result) {
        $foto_profil_url = $result['fotoprofil_url'] ?: $foto_profil_url;
        $foto_ktp_url = $result['fotoktp_url'] ?: $foto_ktp_url;
    }
}
?>

<div class="container-xxl flex-grow-1 container-p-y small">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <div class="row p-3 gap-0">
                    <?php
                    if (isset($_SESSION['message'])) {
                        echo '<h5 class="alert alert-success">' . htmlspecialchars($_SESSION['message']) . '</h5>';
                        unset($_SESSION['message']);
                    }
                    ?>
                    <?php
                    if (isset($_SESSION['xfmessage'])) {
                        echo '<h5 class="alert alert-danger">' . htmlspecialchars($_SESSION['xfmessage']) . '</h5>';
                        unset($_SESSION['xfmessage']);
                    }
                    ?>
                        <!-- Fotoprofil -->
                        <div class="col-6 px-0">
                            <h5 class="fs-5 fw-bold text-primary" id="">FOTO PROFIL</h5>
                            <div class="form-group d-flex align-items-center">
                                <div class="me-0" style="width: 150px; height: 150px; overflow: hidden; position: relative;  border-radius: 10px;">
                                    <label for="fotoprofil_url" style="cursor: pointer;">
                                        <img id="previewImageFotoprofil_url" src="<?php echo $foto_profil_url; ?>" alt="Preview" class="img-thumbnail" style="width: 150px; height: 150px; object-fit: cover;" onmousedown="selectImage('fotoprofil_url')">
                                    </label>
                                    <input type="file" id="fotoprofil_url" name="fotoprofil_url" accept="image/*" hidden onchange="previewSelectedImage('fotoprofil_url')">
                                </div>
                            </div>
                                    <form action="del_fprofil.php" method="post" class="mt-2">
                                        <button type="button" class="btn btn-primary btn-sm px-1" title="Upload Image Profile" onclick="uploadImage('fotoprofil_url')"><i class="ti ti-upload"></i></button>
                                        <!-- Modal -->
                                        <button type="button" class="btn btn-primary btn-sm px-1" data-bs-toggle="modal" data-bs-target="#ModalProfil"><i class="ti ti-zoom-in"></i></button>
                                          <div class="modal fade" id="ModalProfil" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                              <div class="modal-content">
                                                <div class="modal-header mb-1">
                                                  <h5 class="modal-title" id="exampleModalLabel1">Foto Profil</h5>
                                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body text-center">
                                                  <img id="" src="https://bkd.hostku.xyz/user/<?php echo $fotoprofil_url; ?>" alt="BELUM UPLOAD FOTO PROFIL" class="" style="width: 300px; height: 100%; object-fit: cover;">
                                                </div>
                                                <div class="modal-footer">
                                                  <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Tutup</button>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                          <!-- Modal -->
                                        <button type="submit" name="delete_fotoprofil" class="btn btn-danger btn-sm px-1" onclick="return confirm('Anda yakin mau menghapus foto profil ini?');"><i class="ti ti-trash"></i></button>
                                    </form>                            
                        </div>
                        <!-- Fotoktp -->
                        <div class="col-6 px-0">
                            <h5 class="fs-5 fw-bold text-primary" id="">FOTO KTP</h5>
                            <div class="form-group d-flex align-items-center">
                                <div class="me-0" style="width: 250px; height: 150px; overflow: hidden; position: relative;  border-radius: 15px;">
                                    <label for="fotoktp_url" style="cursor: pointer;">
                                        <img id="previewImageFotoktp_url" src="<?php echo $foto_ktp_url; ?>" alt="Preview" class="img-thumbnail" style="width: 250px; height: 150px; object-fit: cover;" onmousedown="selectImage('fotoktp_url')">
                                    </label>
                                    <input type="file" id="fotoktp_url" name="fotoktp_url" accept="image/*" hidden onchange="previewSelectedImage('fotoktp_url')">
                                </div>
                            </div>
                                    <form action="del_fktp.php" method="post" class="mt-2">
                                        <button type="button" class="btn btn-primary btn-sm px-1" title="Upload Image KTP" onclick="uploadImage('fotoktp_url')"><i class="ti ti-upload"></i></button>
                                        <!-- Modal -->
                                        <button type="button" class="btn btn-primary btn-sm px-1" data-bs-toggle="modal" data-bs-target="#ModalKtp"><i class="ti ti-zoom-in"></i></button>
                                          <div class="modal fade" id="ModalKtp" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                              <div class="modal-content">
                                                <div class="modal-header mb-1">
                                                  <h5 class="modal-title" id="exampleModalLabel2">Foto KTP</h5>
                                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body text-center">
                                                  <img id="" src="https://bkd.hostku.xyz/user/<?php echo $fotoktp_url; ?>" alt="BELUM UPLOAD FOTO KTP" class="" style="width: 400px; height: 100%; object-fit: cover;">
                                                </div>
                                                <div class="modal-footer">
                                                  <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Tutup</button>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                          <!-- Modal -->
                                        <button type="submit" name="delete_fotoktp" class="btn btn-danger btn-sm px-1" onclick="return confirm('Anda yakin mau menghapus foto KTP ini?');"><i class="ti ti-trash"></i></button>
                                    </form>                            
                        </div>
                        <hr class="my-4 mx-0" />
                            <div class="row">
                                <h5 class="fs-5 fw-bold text-primary" id="">DOKUMEN PENTING</h5>
                                <?php
                                // PHP function to get icon class based on file extension
                                function get_icon_class($extension) {
                                  $icon_class = '';
                                  switch(strtolower($extension)) {
                                    case 'pdf':
                                      $icon_class = 'bi bi-filetype-pdf';
                                      break;
                                    case 'jpg':
                                    case 'jpeg':
                                    case 'png':
                                      $icon_class = 'bi bi-filetype-jpg';
                                      break;
                                    default:
                                      $icon_class = 'bi bi-file-earmark-x';
                                  }
                                  return $icon_class;
                                  
                                }
                                ?>  
                                <div class="container">
                                  <div class="row row-cols-2 row-cols-md-4 row-cols-lg-6 g-1">
                                    <!-- Column for $buktipns_name -->
                                    <div class="col">
                                      <div class="card">
                                        <?php
                                        // Check if $buktipns_url is empty or null
                                        if (!empty($buktipns_url)) {
                                            // If $buktipns_url contains a valid image URL, display the document
                                        ?>
                					    <div class="card-body text-center p-2">
                                          <h6 class="card-title fs-tiny fw-bold mb-0">BUKTI PEGAWAI</h6>
                                          <?php 
                                            $file_extension = pathinfo($buktipns_name, PATHINFO_EXTENSION);
                                            $icon_class = get_icon_class($file_extension);
                                          ?>
                                          <a href="<?php echo $buktipns_url; ?>" target="_blank"><span class="icondok text-success <?php echo $icon_class; ?>"></span></a>
                                          <p class="fs-tiny lh-1"><?php echo $buktipns_name; ?></p>
                                        </div>
                					    <?php
                                        } else {
                                            // If $buktipns_url is empty or null, display a default image
                                            ?>
                                            <div class="card-body text-center p-2">
                                              <h6 class="card-title fs-tiny fw-bold mb-0">BUKTI PEGAWAI</h6>
                                              <span class="icondok text-danger"><i class="bi bi-file-earmark-x"></i></span>
                                              <p class="fs-tiny text-danger lh-1">BELUM UNGGAH DOKUMEN</p>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                      </div>
                                    </div>
                                
                                    <!-- Column for $buktisert_name -->
                                    <div class="col">
                                      <div class="card">
                                        <?php
                                        // Check if $buktisert_url is empty or null
                                        if (!empty($buktisert_url)) {
                                            // If $buktisert_url contains a valid image URL, display the document
                                        ?>
                					    <div class="card-body text-center p-2">
                                          <h6 class="card-title fs-tiny fw-bold mb-0">BUKTI SERTIFIKASI</h6>
                                          <?php 
                                            $file_extension = pathinfo($buktisert_name, PATHINFO_EXTENSION);
                                            $icon_class = get_icon_class($file_extension);
                                          ?>
                                          <a href="<?php echo $buktisert_url; ?>" target="_blank"><span class="icondok text-success <?php echo $icon_class; ?>"></span></a>
                                          <p class="fs-tiny lh-1"><?php echo $buktisert_name; ?></p>
                                        </div>
                					    <?php
                                        } else {
                                            // If $buktisert_url is empty or null, display a default image
                                            ?>
                                            <div class="card-body text-center p-2">
                                              <h6 class="card-title fs-tiny fw-bold mb-0">BUKTI SERTIFIKASI</h6>
                                              <span class="icondok text-danger"><i class="bi bi-file-earmark-x"></i></span>
                                              <p class="fs-tiny text-danger lh-1">BELUM UNGGAH DOKUMEN</p>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                      </div>
                                    </div>
                                
                                    <!-- Column for $buktis1_name -->
                                    <div class="col">
                                      <div class="card">
                                        <?php
                                        // Check if $buktis1_url is empty or null
                                        if (!empty($buktis1_url)) {
                                            // If $buktis1_url contains a valid image URL, display the document
                                        ?>
                					    <div class="card-body text-center p-2">
                                          <h6 class="card-title fs-tiny fw-bold mb-0">BUKTI JENJANG S1</h6>
                                          <?php 
                                            $file_extension = pathinfo($buktis1_name, PATHINFO_EXTENSION);
                                            $icon_class = get_icon_class($file_extension);
                                          ?>
                                          <a href="<?php echo $buktis1_url; ?>" target="_blank"><span class="icondok text-success <?php echo $icon_class; ?>"></span></a>
                                          <p class="fs-tiny lh-1"><?php echo $buktis1_name; ?></p>
                                        </div>
                					    <?php
                                        } else {
                                            // If $buktis1_url is empty or null, display a default image
                                            ?>
                                            <div class="card-body text-center p-2">
                                              <h6 class="card-title fs-tiny fw-bold mb-0">BUKTI JENJANG S1</h6>
                                              <span class="icondok text-danger"><i class="bi bi-file-earmark-x"></i></span>
                                              <p class="fs-tiny text-danger lh-1">BELUM UNGGAH DOKUMEN</p>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                      </div>
                                    </div>
                                
                                    <!-- Column for $buktis2_name -->
                                    <div class="col">
                                      <div class="card">
                                        <?php
                                        // Check if $buktis2_url is empty or null
                                        if (!empty($buktis2_url)) {
                                            // If $buktis2_url contains a valid image URL, display the document
                                        ?>
                					    <div class="card-body text-center p-2">
                                          <h6 class="card-title fs-tiny fw-bold mb-0">BUKTI JENJANG S2</h6>
                                          <?php 
                                            $file_extension = pathinfo($buktis2_name, PATHINFO_EXTENSION);
                                            $icon_class = get_icon_class($file_extension);
                                          ?>
                                          <a href="<?php echo $buktis2_url; ?>" target="_blank"><span class="icondok text-success <?php echo $icon_class; ?>"></span></a>
                                          <p class="fs-tiny lh-1"><?php echo $buktis2_name; ?></p>
                                        </div>
                					    <?php
                                        } else {
                                            // If $buktis2_url is empty or null, display a default image
                                            ?>
                                            <div class="card-body text-center p-2">
                                              <h6 class="card-title fs-tiny fw-bold mb-0">BUKTI JENJANG S2</h6>
                                              <span class="icondok text-danger"><i class="bi bi-file-earmark-x"></i></span>
                                              <p class="fs-tiny text-danger lh-1">BELUM UNGGAH DOKUMEN</p>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                      </div>
                                    </div>
                                
                                    <!-- Column for $buktis3_name -->
                                    <div class="col">
                                      <div class="card">
                                        <?php
                                        // Check if $buktis3_url is empty or null
                                        if (!empty($buktis3_url)) {
                                            // If $buktis3_url contains a valid image URL, display the document
                                        ?>
                					    <div class="card-body text-center p-2">
                                          <h6 class="card-title fs-tiny fw-bold mb-0">BUKTI JENJANG S3</h6>
                                          <?php 
                                            $file_extension = pathinfo($buktis3_name, PATHINFO_EXTENSION);
                                            $icon_class = get_icon_class($file_extension);
                                          ?>
                                          <a href="<?php echo $buktis3_url; ?>" target="_blank"><span class="icondok text-success <?php echo $icon_class; ?>"></span></a>
                                          <p class="fs-tiny lh-1"><?php echo $buktis3_name; ?></p>
                                        </div>
                					    <?php
                                        } else {
                                            // If $buktis3_url is empty or null, display a default image
                                            ?>
                                            <div class="card-body text-center p-2">
                                              <h6 class="card-title fs-tiny fw-bold mb-0">BUKTI JENJANG S3</h6>
                                              <span class="icondok text-danger"><i class="bi bi-file-earmark-x"></i></span>
                                              <p class="fs-tiny text-danger lh-1">BELUM UNGGAH DOKUMEN</p>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                      </div>
                                    </div>
                                
                                    <!-- Column for $buktiprof_name -->
                                    <div class="col">
                                      <div class="card">
                                        <?php
                                        // Check if $buktiprof_url is empty or null
                                        if (!empty($buktiprof_url)) {
                                            // If $buktiprof_url contains a valid image URL, display the user's image
                                        ?>
                					    <div class="card-body text-center p-2">
                                          <h6 class="card-title fs-tiny fw-bold mb-0">BUKTI PROFESOR</h6>
                                          <?php 
                                            $file_extension = pathinfo($buktiprof_name, PATHINFO_EXTENSION);
                                            $icon_class = get_icon_class($file_extension);
                                          ?>
                                          <a href="<?php echo $buktiprof_url; ?>" target="_blank"><span class="icondok text-success <?php echo $icon_class; ?>"></span></a>
                                          <p class="fs-tiny lh-1"><?php echo $buktiprof_name; ?></p>
                                        </div>
                					    <?php
                                        } else {
                                            // If $buktis3_url is empty or null, display a default image
                                            ?>
                                            <div class="card-body text-center p-2">
                                              <h6 class="card-title fs-tiny fw-bold mb-0">BUKTI PROFESOR</h6>
                                              <span class="icondok text-danger"><i class="bi bi-file-earmark-x"></i></span>
                                              <p class="fs-tiny text-danger lh-1">BELUM UNGGAH DOKUMEN</p>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                
                                <div class="container mt-1">
                                        <!-- Six delete buttons, each for a specific file -->
                                        <form action="del_dokumen.php" method="post">
                                            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-6 g-4">
                                                <!-- Delete button for buktipns_url -->
                                                <div class="col"><button type="submit" class="btn btn-sm btn-danger fs-tiny w-100" name="delete" value="buktipns_url">Hapus Bukti Pegawai</button></div>
                                                <!-- Delete button for buktisert_url -->
                                                <div class="col"><button type="submit" class="btn btn-sm btn-danger fs-tiny w-100" name="delete" value="buktisert_url">Hapus Bukti Sertifikasi</button></div>
                                                <!-- Delete button for buktis1_url -->
                                                <div class="col"><button type="submit" class="btn btn-sm btn-danger fs-tiny w-100" name="delete" value="buktis1_url">Hapus Bukti S1</button></div>
                                                <!-- Delete button for buktis2_url -->
                                                <div class="col"><button type="submit" class="btn btn-sm btn-danger fs-tiny w-100" name="delete" value="buktis2_url">Hapus Bukti S2</button></div>
                                                <!-- Delete button for buktis3_url -->
                                                <div class="col"><button type="submit" class="btn btn-sm btn-danger fs-tiny w-100" name="delete" value="buktis3_url">Hapus Bukti S3</button></div>
                                                <!-- Delete button for buktiprof_url -->
                                                <div class="col"><button type="submit" class="btn btn-sm btn-danger fs-tiny w-100" name="delete" value="buktiprof_url">Hapus Bukti Profesor</button></div>
                                            </div>
                                        </form>
                                    </div>
                                
                                <div class="col mt-5">
                                    <p class="fs-5 fw-bold text-primary">FORMULIR UNGGAH DOKUMEN</p>
                                    <form action="upd_dokumen.php" method="POST" enctype="multipart/form-data">
                                        <div class="mb-3">
                                            <label for="buktiPns" class="form-label">UNGGAH BUKTI PENGANGKATAN PEGAWAI</label>
                                            <div class="input-group">
                                                <input type="file" name="buktipns_url" class="form-control form-control-sm" id="buktiPns" accept=".pdf, .jpg">
                                                <button type="submit" class="btn btn-sm btn-primary">Upload</button>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="buktiSert" class="form-label">UNGGAH BUKTI SERTIFIKASI</label>
                                            <div class="input-group">
                                                <input type="file" name="buktisert_url" class="form-control form-control-sm" id="buktiSert" accept=".pdf, .jpg">
                                                <button type="submit" class="btn btn-sm btn-primary">Upload</button>
                                            </div>
                                        </div>
                                    
                                        <div class="mb-3">
                                            <label for="buktiS1" class="form-label">UNGGAH BUKTI LULUS JENJANG S1</label>
                                            <div class="input-group">
                                                <input type="file" name="buktis1_url" class="form-control form-control-sm" id="buktiS1" accept=".pdf, .jpg">
                                                <button type="submit" class="btn btn-sm btn-primary">Upload</button>
                                            </div>
                                        </div>
                                    
                                        <div class="mb-3">
                                            <label for="buktiS2" class="form-label">UNGGAH BUKTI LULUS JENJANG S2</label>
                                            <div class="input-group">
                                                <input type="file" name="buktis2_url" class="form-control form-control-sm" id="buktiS2" accept=".pdf, .jpg">
                                                <button type="submit" class="btn btn-sm btn-primary">Upload</button>
                                            </div>
                                        </div>
                                    
                                        <div class="mb-3">
                                            <label for="buktiS3" class="form-label">UNGGAH BUKTI LULUS JENJANG S3</label>
                                            <div class="input-group">
                                                <input type="file" name="buktis3_url" class="form-control form-control-sm" id="buktiS3" accept=".pdf, .jpg">
                                                <button type="submit" class="btn btn-sm btn-primary">Upload</button>
                                            </div>
                                        </div>
                                    
                                        <div class="mb-3">
                                            <label for="buktiProf" class="form-label">UNGGAH BUKTI PENGANGKATAN PROFESOR</label>
                                            <div class="input-group">
                                                <input type="file" name="buktiprof_url" class="form-control form-control-sm" id="buktiProf" accept=".pdf, .jpg">
                                                <button type="submit" class="btn btn-sm btn-primary">Upload</button>
                                            </div>
                                        </div>
                                    
                                        <button type="submit" class="btn btn-sm btn-primary">Unggah Sekaligus</button>
                                    </form>
                                </div>
                            </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function uploadImage(inputId) {
        var input = document.getElementById(inputId);
        var file = input.files[0];

        // Check if a file is selected
        if (!file) {
            alert('Please select an image before uploading.');
            return; // Exit the function if no file is selected
        }

        var formData = new FormData();
        formData.append(inputId, file);

        var xhr = new XMLHttpRequest();
        xhr.open("POST", "upd_image.php", true);

        xhr.onload = function () {
            if (xhr.status === 200) {
                var response = xhr.responseText.trim();
                // Check if the response includes 'Sukses'
                if (response.includes('Sukses')) {
                    // Redirect to up-image.php on success
                    window.location.href = '/user/up-image?img=<?php echo $nidn; ?>';
                } else {
                    // Redirect to up-image.php on failure
                    window.location.href = '/user/up-image?img=<?php echo $nidn; ?>';
                }
            } else {
                // Redirect to up-image.php on failure
                window.location.href = '/user/up-image?img=<?php echo $nidn; ?>';
            }
        };

        // Handle network errors
        xhr.onerror = function () {
            // Redirect to up-image.php on network error
            window.location.href = '/user/up-image?img=<?php echo $nidn; ?>';
        };

        xhr.send(formData);
    }
</script>

<script>
    function selectImage(imageId) {
    var input = document.getElementById(imageId);
    input.dispatchEvent(new MouseEvent('click'));
    }

    function previewSelectedImage(imageId) {
        var input = document.getElementById(imageId);
        var previewImage = document.getElementById('previewImage' + imageId.charAt(0).toUpperCase() + imageId.slice(1));

        var file = input.files[0];

        if (file) {
            var reader = new FileReader();

            reader.onload = function (e) {
                // Update the preview image directly
                previewImage.src = e.target.result;
            };

            reader.readAsDataURL(file);
        }
    }

    function deleteImage(imageId) {
        var previewImage = document.getElementById('previewImage' + imageId.charAt(0).toUpperCase() + imageId.slice(1));
        var input = document.getElementById(imageId);

        // Reset the preview to the default image
        previewImage.src = 'https://bkd.hostku.xyz/assets/img/backgrounds/1.jpg';

        // Clear the file input
        input.value = null;
    }

    function updateImagePreview(imageId, imageUrl) {
        // Update the image preview with the new URL
        var previewImage = document.getElementById('previewImage' + imageId.charAt(0).toUpperCase() + imageId.slice(1));

        // Check if the previewImage element exists
        if (previewImage) {
            previewImage.src = imageUrl;
        } else {
            console.error('Preview image element not found for ' + imageId);
        }
    }
</script>

<?php require_once ("../includes/footer.php"); ?>

