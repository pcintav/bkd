<?php require_once ("../includes/header.php"); ?>
<?php require_once ("../includes/sidebar.php"); ?>
<?php require_once ("../includes/topbar.php"); ?>
<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
?>

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y small">
        <div class="row">
          <div class="col">     
             <!-- Hour chart  -->
              <div class="card my-4 p-3 border-0">
                <div class="card-body row p-0 pb-0">
                  <div class="col-12 col-md-8 card-separator">
                    <?php if(isset($_SESSION['message'])) : ?>
                        <h5 class="alert alert-success"><?= $_SESSION['message']; ?></h5>
                    <?php 
                        unset($_SESSION['message']);
                        endif; 
                    ?>  
                    <h4>Selamat Datang, <?php
                        //session_start(); // Start the session
                        if (isset($_SESSION['isLoggedIn']) && $_SESSION['isLoggedIn'] == true) {
                            // User is logged in, display their name
                            echo " " . htmlspecialchars($_SESSION['nama']) . "!";
                        } 
                        ?> 👋🏻</h4>
                    <div class="col-12 col-lg-7">
                      <p class="fs-6">Progres Anda di semester lalu Luar Biasa. Ayo pertahankan dan dapatkan reward lebih banyak lagi!</p>
                    </div>
                    <div class="d-flex justify-content-between flex-wrap gap-3 me-5 mt-5">
                      <div class="d-flex align-items-center gap-2 me-4 me-sm-0">
                        <span class="bg-label-primary p-2 rounded">
                          <i class="ti ti-device-laptop ti-xl"></i>
                        </span>
                        <div class="content-right">
                          <p class="mb-0">RKBD Selesai</p>
                          <h4 class="text-primary mb-0">5 Entri</h4>
                        </div>
                      </div>
                      <div class="d-flex align-items-center gap-3">
                        <span class="bg-label-info p-2 rounded">
                          <i class="ti ti-bulb ti-xl"></i>
                        </span>
                        <div class="content-right">
                          <p class="mb-0">LKD Selesai</p>
                          <h4 class="text-info mb-0">4 Laporan</h4>
                        </div>
                      </div>
                      <div class="d-flex align-items-center gap-3">
                        <span class="bg-label-warning p-2 rounded">
                          <i class="ti ti-discount-check ti-xl"></i>
                        </span>
                        <div class="content-right">
                          <p class="mb-0">Kesimpulan Selesai</p>
                          <h4 class="text-warning mb-0">5 Kesimpulan</h4>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12 col-md-4 ps-md-2 ps-lg-3 pt-2 pt-md-0">
                    <h5 class="card-title mb-0">Statistik</h5>
                    <small class="text-muted">Laporan BKD dan LKD</small>
                      <div class="">
                        <canvas id="lineChart" class="chartjs" data-height="200"></canvas>
                      </div>
                  </div>
               </div>
              <!-- Hour chart End  -->
              </div>
         </div>
        
         <div class="row ps-3">    
          <div class="col-xl-5 col-lg-4 col-md-4 order-1 order-md-0">
           <!-- User Card -->
              <div class="card mb-4">
                <div class="card-body">
                  <div class="user-avatar-section">
                    <div class="d-flex align-items-center flex-column">
                        <div class="mb-3 pt-1 mt-4" style="width: 150px; height: 150px; overflow: hidden; position: relative;  border-radius: 15px;">
                            <?php
                            // Check if $fotoprofil_url is empty or null
                            if (!empty($fotoprofil_url)) {
                                // If $fotoprofil_url contains a valid image URL, display the user's image
                            ?>
                            <img src="https://bkd.sistm.app/user/<?php echo $fotoprofil_url; ?>" class="img-thumbnail" style="width: 150px; height: 150px; object-fit: cover; border-radius: 15px;">
                            <?php
                            } else {
                                // If $fotoprofil_url is empty or null, display a default image
                                ?>
                                <img src="https://bkd.sistm.app/assets/img/avatars/profile-placeholder.jpg" class="img-thumbnail" style="width: 150px; height: 150px; object-fit: cover; border-radius: 15px;">
                                <?php
                            }
                            ?>
                        </div>
                      
                      <div class="user-info text-center">
                        <h5 class="mb-2"><?php echo $glr_depan; ?><?php
                        //session_start();
                        if (isset($_SESSION['isLoggedIn']) && $_SESSION['isLoggedIn'] == true) {
                            // User is logged in, display their name
                            echo " " . htmlspecialchars($_SESSION['nama']) . ",";
                        } 
                        ?> <?php echo $glr_belakang; ?></h5>
                        <span class="badge bg-label-secondary mt-1 fs-5">Dosen</span>
                      </div>
                    </div>
                  </div>
                  <div class="d-flex justify-content-around flex-wrap mt-1 pt-1 pb-4 border-bottom">
                    <div class="d-flex align-items-start me-4 mt-3 gap-2">
                      <span class="badge bg-label-primary p-2 rounded"><i class="ti ti-briefcase ti-sm"></i></span>
                      <div>
                        <p class="mb-0 fw-medium"><?php echo $nidn; ?></p>
                        <small>NIDN</small>
                      </div>
                    </div>
                    <div class="d-flex align-items-start mt-3 gap-1">
                      <span class="badge bg-label-primary p-2 rounded"><i class="ti ti-briefcase ti-sm"></i></span>
                      <div>
                        <p class="mb-0 fw-medium"><?php echo $nip; ?></p>
                        <small>NIP/No.Kepeg</small>
                      </div>
                    </div>
                  </div>
                  <p class="mt-4 small text-uppercase text-muted">Sertifikasi & Jabatan</p>
                  <div class="info-container">
                    <ul class="list-unstyled mb-4 mt-3">
                        <li class="d-flex align-items-center mb-2">
                            <i class="ti ti-file-description text-heading"></i><span class="fw-medium mx-2 text-heading">No. Sertifikat:</span> <span><?php echo $no_sert; ?></span>
                        </li>                            
                        <li class="d-flex align-items-center mb-2">
                            <i class="ti ti-badge text-heading"></i><span class="fw-medium mx-2 text-heading">Jabatan Fungsional:</span> <span><?php echo $jenis_ds; ?></span>
                        </li>
                        <li class="d-flex align-items-center mb-2">
                            <i class="ti ti-badge text-heading"></i><span class="fw-medium mx-2 text-heading">Jabatan Fungsional:</span> <span><?php echo $jbtn_fung; ?></span>
                        </li>
                        <li class="d-flex align-items-center mb-2">
                            <i class="ti ti-badge text-heading"></i><span class="fw-medium mx-2 text-heading">Golongan/Pangkat:</span> <span><?php echo $gol_pang; ?></span>
                        </li>
                    </ul>
                  <p class="mt-4 small text-uppercase text-muted">DATA PRIBADI</p>
                  <div class="info-container">
                    <ul class="list-unstyled mb-4 mt-3">
                        <li class="d-flex align-items-center mb-2">
                          <i class="ti ti-user text-heading"></i><span class="fw-medium mx-2 text-heading">Nama Lengkap:</span> <span><?php echo $nama; ?></span>
                        </li>
                        <li class="d-flex align-items-center mb-2">
                          <i class="ti ti-calendar text-heading"></i><span class="fw-medium mx-2 text-heading">Tanggal Lahir:</span> <span><?php echo $tgl_lhr; ?></span>
                        </li>
                        <li class="d-flex align-items-center mb-2">
                          <i class="ti ti-location text-heading"></i><span class="fw-medium mx-2 text-heading">Tempat Lahir:</span> <span><?php echo $tmpt_lhr; ?></span>
                        </li>
                        <li class="d-flex align-items-center mb-2">
                          <i class="ti ti-map-pin text-heading"></i><span class="fw-medium mx-2 text-heading">Alamat Rumah:</span> <span><?php echo $almt_rmh; ?></span>
                        </li>
                    </ul>
                  <small class="card-text text-uppercase text-muted">Kontak</small>
                  <ul class="list-unstyled mb-4 mt-3">
                    <li class="d-flex align-items-center mb-2">
                      <i class="ti ti-phone-call"></i><span class="fw-medium mx-2 text-heading">No. Telephone:</span> <span>0<?php echo $no_telp; ?></span>
                    </li>
                    <li class="d-flex align-items-center mb-2">
                      <i class="ti ti-brand-whatsapp"></i><span class="fw-medium mx-2 text-heading">No. Whatsapp:</span> <span><a href="https://wa.me/62<?php echo $no_wa; ?>" target="_blank">KLIK DISINI</a></span>
                    </li>
                    <li class="d-flex align-items-center mb-3">
                      <i class="ti ti-mail"></i><span class="fw-medium mx-2 text-heading">Email:</span> <span><?php echo $email; ?></span>
                    </li>
                  </ul>
                  <small class="card-text text-uppercase text-muted">PENDIDIKAN</small>
                  <ul class="list-unstyled mb-4 mt-3">
                    <li class="d-flex align-items-center mb-2">
                      <i class="ti ti-school text-danger me-2"></i>
                      <div class="d-flex flex-wrap">
                        <span class="fw-medium me-2 text-heading">Pendidikan S1:</span><span><?php echo $pend_s1; ?></span>
                      </div>
                    </li>
                    <li class="d-flex align-items-center mb-2">
                      <i class="ti ti-school text-danger me-2"></i>
                      <div class="d-flex flex-wrap">
                        <span class="fw-medium me-2 text-heading">Pendidikan S2:</span><span><?php echo $pend_s2; ?></span>
                      </div>
                    </li>
                    <li class="d-flex align-items-center mb-2">
                      <i class="ti ti-school text-danger me-2"></i>
                      <div class="d-flex flex-wrap">
                        <span class="fw-medium me-2 text-heading">Pendidikan S3:</span><span><?php echo $pend_s3; ?></span>
                      </div>
                    </li>
                    <li class="d-flex align-items-center mb-2">
                      <i class="ti ti-microscope text-danger me-2"></i>
                      <div class="d-flex flex-wrap">
                        <span class="fw-medium me-2 text-heading">Bidang Keilmuan:</span><span><?php echo $keilmuan; ?></span>
                      </div>
                    </li>                        
                  </ul>
                  <small class="card-text text-uppercase text-muted">KANTOR & HOME BASE</small>
                  <ul class="list-unstyled mb-0 mt-3">
                    <li class="d-flex align-items-center mb-2">
                      <i class="ti ti-building-bank text-info me-2"></i>
                      <div class="d-flex flex-wrap">
                        <span class="fw-medium me-2 text-heading">Jurusan/Prodi:</span><span><?php echo $jurusan; ?><?php echo $jur_satu; ?><?php echo $jur_dua; ?><?php echo $jur_tiga; ?><?php echo $jur_empat; ?><?php echo $jur_lima; ?></span>
                      </div>
                    </li>
                    <li class="d-flex align-items-center mb-2">
                      <i class="ti ti-building-bank text-info me-2"></i>
                      <div class="d-flex flex-wrap">
                        <span class="fw-medium me-2 text-heading">Nama Kajur:</span><span></span>
                      </div>
                    </li>
                    <li class="d-flex align-items-center mb-2">
                      <i class="ti ti-building-bank text-info me-2"></i>
                      <div class="d-flex flex-wrap">
                        <span class="fw-medium me-2 text-heading">Fakultas:</span><span><?php echo $fakultas; ?></span>
                      </div>
                    </li>
                    <li class="d-flex align-items-center mb-2">
                      <i class="ti ti-building-bank text-info me-2"></i>
                      <div class="d-flex flex-wrap">
                        <span class="fw-medium me-2 text-heading">Alamat Kantor:</span><span><?php echo $almt_kntr; ?></span>
                      </div>
                    </li>                        
                    </ul>
                    <div class="d-flex justify-content-center mt-5">
                      <a href="/user/edit-profile?epro=<?php echo $nidn; ?>" class="btn btn-primary me-3">Edit Profil</a>
                      <a href="/user/edit-institution?eins=<?php echo $nidn; ?>" class="btn btn-label-danger suspend-user">Edit Home Base</a>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /User Card -->
           </div>
          </div>
          
         <div class="col-xl-7 col-lg-8 col-md-8 order-1 order-md-0 ps-3">
            <div class="row">    
            <!-- Announcements -->                    
                <div class="card">
                  <h5 class="card-header">Pengumuman</h5>
                  <div class="table-responsive text-nowrap">
                    <table class="table table-borderless">
                      <thead>
                        <tr>
                          <th>Date</th>
                          <th>Title</th>
                          <th>Content</th>
                          <th><i class="ti ti-settings"></i></th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td> <span class="fw-medium">Angular Project</span></td>
                          <td>Albert Cook</td>
                          <td><span class="badge bg-label-primary me-1">Active</span></td>
                          <td>
                            <div class="dropdown">
                              <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td> <span class="fw-medium">React Project</span></td>
                          <td>Barry Hunter</td>
                          <td><span class="badge bg-label-success me-1">Completed</span></td>
                          <td>
                            <div class="dropdown">
                              <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td> <span class="fw-medium">VueJs Project</span></td>
                          <td>Trevor Baker</td>
                          <td><span class="badge bg-label-info me-1">Scheduled</span></td>
                          <td>
                            <div class="dropdown">
                              <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td> <span class="fw-medium">Bootstrap Project</span></td>
                          <td>Jerry Milton</td>
                          <td><span class="badge bg-label-warning me-1">Pending</span></td>
                          <td>
                            <div class="dropdown">
                              <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                              </div>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                <!--/ Announcements -->                     
            </div>
            

            <div class="row pt-3">
              <!-- RBKD Entries -->
              <div class="card mb-4">
                <h5 class="card-header">RBKD Entries</h5>
                      <div class="table-responsive text-nowrap">
                        <table class="table">
                          <thead class="table-light">
                            <tr>
                              <th>Project</th>
                              <th>Client</th>
                              <th>Users</th>
                              <th><i class="ti ti-settings"></i></th>
                            </tr>
                          </thead>
                          <tbody class="table-border-bottom-0">
                            <tr>
                              <td> <span class="fw-medium">Angular Project</span></td>
                              <td>Albert Cook</td>
                              <td><span class="badge bg-label-primary me-1">Active</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td> <span class="fw-medium">React Project</span></td>
                              <td>Barry Hunter</td>
                              <td><span class="badge bg-label-success me-1">Completed</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td> <span class="fw-medium">VueJs Project</span></td>
                              <td>Trevor Baker</td>
                              <td><span class="badge bg-label-info me-1">Scheduled</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td> <span class="fw-medium">Bootstrap Project</span></td>
                              <td>Jerry Milton</td>
                              <td><span class="badge bg-label-warning me-1">Pending</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                  
                  
                  <hr>
                    <!-- LKD Entries -->                      
                    <h5 class="card-header">LKD Entries</h5>
                      <div class="table-responsive text-nowrap">
                        <table class="table">
                          <thead class="table-light">
                            <tr class="border rounded">
                              <th>Project</th>
                              <th>Client</th>
                              <th>Users</th>
                              <th><i class="ti ti-settings"></i></th>
                            </tr>
                          </thead>
                          <tbody class="table-border-bottom-0">
                            <tr>
                              <td> <span class="fw-medium">Angular Project</span></td>
                              <td>Albert Cook</td>
                              <td><span class="badge bg-label-primary me-1">Active</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td> <span class="fw-medium">React Project</span></td>
                              <td>Barry Hunter</td>
                              <td><span class="badge bg-label-success me-1">Completed</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td> <span class="fw-medium">VueJs Project</span></td>
                              <td>Trevor Baker</td>
                              <td><span class="badge bg-label-info me-1">Scheduled</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td> <span class="fw-medium">Bootstrap Project</span></td>
                              <td>Jerry Milton</td>
                              <td><span class="badge bg-label-warning me-1">Pending</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                </div>  
            </div>  
              <!--/ Entries -->
            </div>                
         </div>
        </div>
    </div>
    <!-- / Content -->


<?php require_once ("../includes/footer.php"); ?>
