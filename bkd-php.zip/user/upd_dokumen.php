<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /index");
    exit();
}

require_once("../includes/Dtbase.php");

$db = new DatabaseConnection();
$conn = $db->getConnection();

// Get user information from the session
$user_id = $_SESSION['user_id'];
$nama = $_SESSION['nama'];
$nidn = $_SESSION['nidn'];

// Function to handle file upload
function handleFileUpload($fileField, $allowedTypes, $maxSize, $uploadPath, $urlColumn, $nameColumn)
{
    global $conn, $user_id;

    // Validate database connection
    if (!$conn) {
        $_SESSION['xfmessage'] = "Database connection error.";
        return false;
    }

    // Validate if the file is selected
    if (!isset($_FILES[$fileField]['name']) || empty($_FILES[$fileField]['name'])) {
        return true; // No file selected, continue processing other fields
    }

    $fileType = $_FILES[$fileField]['type'];

    // Validate file type
    if (!in_array($fileType, $allowedTypes)) {
        $_SESSION['xfmessage'] = "File harus berupa PDF atau JPG untuk " . $fileField;
        return false;
    }

    // Validate file size
    $fileSize = $_FILES[$fileField]['size'];
    if ($fileSize > $maxSize) {
        $_SESSION['xfmessage'] = "File lebih dari 1MB untuk " . $fileField;
        return false;
    }

    // Check if the file with the same name already exists in the database
    $stmtCheckName = $conn->prepare("SELECT {$nameColumn} FROM users_bkd WHERE {$nameColumn} = ?");
    $stmtCheckName->execute([$_FILES[$fileField]['name']]);
    $existingName = $stmtCheckName->fetchColumn();

    if ($existingName) {
        $_SESSION['xfmessage'] = "File dengan nama yang sama sudah ada untuk " . $fileField;
        return false;
    }

    // Create upload directory if not exists
    if (!file_exists($uploadPath)) {
        mkdir($uploadPath, 0777, true);
    }

    // Move uploaded file to destination folder
    $uploadedFile = $uploadPath . basename($_FILES[$fileField]['name']);

    if (move_uploaded_file($_FILES[$fileField]['tmp_name'], $uploadedFile)) {
        // Update database with file information
        $stmtUpdate = $conn->prepare("UPDATE users_bkd SET {$urlColumn} = ?, {$nameColumn} = ?, revisi = CURRENT_TIMESTAMP WHERE user_id = ?");
        $stmtUpdate->execute([$uploadedFile, $_FILES[$fileField]['name'], $user_id]);

        if ($stmtUpdate->rowCount() > 0) {
            $_SESSION['message'] = "Sukses Diupload untuk " . $fileField;
        } else {
            $_SESSION['xfmessage'] = "Gagal menyimpan informasi file di database untuk " . $fileField;
        }
    } else {
        $_SESSION['xfmessage'] = "Gagal Diupload untuk " . $fileField;
    }

    return true;
}

// Define upload path and columns for each file field
$uploadPaths = [
    'buktipns_url' => "uploads/" . date("Y/m/", time()) . $nama . "/",
    'buktisert_url' => "uploads/" . date("Y/m/", time()) . $nama . "/",
    'buktis1_url' => "uploads/" . date("Y/m/", time()) . $nama . "/",
    'buktis2_url' => "uploads/" . date("Y/m/", time()) . $nama . "/",
    'buktis3_url' => "uploads/" . date("Y/m/", time()) . $nama . "/",
    'buktiprof_url' => "uploads/" . date("Y/m/", time()) . $nama . "/",
];

$columns = [
    'buktipns_url' => 'buktipns_name',
    'buktisert_url' => 'buktisert_name',
    'buktis1_url' => 'buktis1_name',
    'buktis2_url' => 'buktis2_name',
    'buktis3_url' => 'buktis3_name',
    'buktiprof_url' => 'buktiprof_name',
];

// Handle file upload for each file field
foreach ($uploadPaths as $urlColumn => $uploadPath) {
    handleFileUpload($urlColumn, ['application/pdf', 'image/jpeg', 'image/jpg'], 1024 * 1024, $uploadPath, $urlColumn, $columns[$urlColumn]);
}

// Redirect back to the HTML form page
$_SESSION['message'] = "Files uploaded successfully.";
header("Location: /user/up-image?img=$nidn");
exit();
?>
