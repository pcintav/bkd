<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /index");
    exit();
}

require_once("../includes/Dtbase.php");

$db = new DatabaseConnection();
$conn = $db->getConnection();

// Get user information from the session
$user_id = $_SESSION['user_id'];
$nama = $_SESSION['nama'];
$nidn = $_SESSION['nidn'];

// Define columns array (mapping between upload paths and corresponding database columns)
$columns = [
    'buktipns_url' => 'buktipns_name',
    'buktisert_url' => 'buktisert_name',
    'buktis1_url' => 'buktis1_name',
    'buktis2_url' => 'buktis2_name',
    'buktis3_url' => 'buktis3_name',
    'buktiprof_url' => 'buktiprof_name',
];

// Function to delete file and corresponding data from database
function deleteFileAndData($urlColumn, $nameColumn, $user_id, $conn)
{
    // Fetch file path and name from database
    $stmtSelect = $conn->prepare("SELECT {$urlColumn}, {$nameColumn} FROM users_bkd WHERE user_id = ?");
    $stmtSelect->execute([$user_id]);
    $fileData = $stmtSelect->fetch(PDO::FETCH_ASSOC);

    // Delete file from server
    if (!empty($fileData[$urlColumn]) && file_exists($fileData[$urlColumn])) {
        unlink($fileData[$urlColumn]);
    }

    // Update database to remove file information
    $stmtUpdate = $conn->prepare("UPDATE users_bkd SET {$urlColumn} = NULL, {$nameColumn} = NULL, revisi = CURRENT_TIMESTAMP WHERE user_id = ?");
    $stmtUpdate->execute([$user_id]);
}

// Check if delete button is clicked for a specific file
if (isset($_POST['delete'])) {
    $columnToDelete = $_POST['delete'];

    // Check if the requested column exists and delete the corresponding file and data
    if (array_key_exists($columnToDelete, $columns)) {
        deleteFileAndData($columnToDelete, $columns[$columnToDelete], $user_id, $conn);
    }

    // Redirect back to the HTML form page
    $_SESSION['message'] = "File and data deleted successfully.";
    header("Location: /user/up-image?img=$nidn");
    exit();
}
?>
