<?php
session_start();
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
// Include your database connection class
include('../includes/Dtbase.php');

// Instantiate the DatabaseConnection class
$databaseConnection = new DatabaseConnection();
$conn = $databaseConnection->getConnection();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the current logged-in user ID from the session
    $user_id = $_SESSION['user_id'];

    // Sanitize and validate form data
    $nidn = filter_input(INPUT_POST, 'nidn', FILTER_SANITIZE_NUMBER_INT);
    $nip = filter_input(INPUT_POST, 'nip', FILTER_SANITIZE_NUMBER_INT);
    $no_sert = filter_input(INPUT_POST, 'no_sert', FILTER_SANITIZE_STRING);
    $jbtn_fung = filter_input(INPUT_POST, 'jbtn_fung', FILTER_SANITIZE_STRING);
    $gol_pang = filter_input(INPUT_POST, 'gol_pang', FILTER_SANITIZE_STRING);
    $jenis_ds = filter_input(INPUT_POST, 'jenis_ds', FILTER_SANITIZE_STRING);
    $jur_satu = filter_input(INPUT_POST, 'jur_satu', FILTER_SANITIZE_STRING);
    $jur_dua = filter_input(INPUT_POST, 'jur_dua', FILTER_SANITIZE_STRING);
    $jur_tiga = filter_input(INPUT_POST, 'jur_tiga', FILTER_SANITIZE_STRING);
    $jur_empat = filter_input(INPUT_POST, 'jur_empat', FILTER_SANITIZE_STRING);
    $jur_lima = filter_input(INPUT_POST, 'jur_lima', FILTER_SANITIZE_STRING);
    $fakultas = filter_input(INPUT_POST, 'fakultas', FILTER_SANITIZE_STRING);
    $almt_kntr = filter_input(INPUT_POST, 'almt_kntr', FILTER_SANITIZE_STRING);
    
    $validation_errors = [];

    // Validate input fields
    if (!preg_match("/^\d+$/", $nidn)) {
        $validation_errors[] = "Invalid value for NIDN. Must be a number.";
    }    
    
    if (!preg_match("/^\d+$/", $nip)) {
        $validation_errors[] = "Invalid value for NIP. Must be a number.";
    }
    
    if (!preg_match('/^[\p{L}0-9\s\/.,\-]*+$/u', $no_sert)) {
        $validation_errors[] = "Invalid value for no_sert. Only letters, numbers, spaces, slashes, commas, periods, and hyphens are allowed.";
    }    
    
    if (!preg_match("/^[a-zA-Z ]*+$/", $jbtn_fung)) {
        $validation_errors[] = "Invalid value for jabatan. Only letters and spaces are allowed.";
    }

    if (!preg_match("/^[a-zA-Z ]*+$/", $gol_pang)) {
        $validation_errors[] = "Invalid value for golongan. Only letters and spaces are allowed.";
    }
    
    if (!preg_match("/^[a-zA-Z ]*+$/", $jenis_ds)) {
        $validation_errors[] = "Invalid value for golongan. Only letters and spaces are allowed.";
    }
    
    if (!preg_match("/^[a-zA-Z ]*+$/", $jur_satu)) {
        $validation_errors[] = "Invalid value for jurusan. Only letters and spaces are allowed.";
    }
    
    if (!preg_match("/^[a-zA-Z ]*+$/", $jur_dua)) {
        $validation_errors[] = "Invalid value for jurusan. Only letters and spaces are allowed.";
    }
    
    if (!preg_match("/^[a-zA-Z ]*+$/", $jur_tiga)) {
        $validation_errors[] = "Invalid value for jurusan. Only letters and spaces are allowed.";
    }
    
    if (!preg_match("/^[a-zA-Z ]*+$/", $jur_empat)) {
        $validation_errors[] = "Invalid value for jurusan. Only letters and spaces are allowed.";
    }
    
    if (!preg_match("/^[a-zA-Z ]*+$/", $jur_lima)) {
        $validation_errors[] = "Invalid value for jurusan. Only letters and spaces are allowed.";
    }

    if (!preg_match("/^[a-zA-Z ]*+$/", $fakultas)) {
        $validation_errors[] = "Invalid value for fakultas. Only letters and spaces are allowed.";
    }    
    
    if (!preg_match('/^[\p{L}0-9\s\/.,\-]*+$/u', $almt_kntr)) {
        $validation_errors[] = "Invalid value for almt_kntr. Only letters, numbers, spaces, slashes, commas, periods, and hyphens are allowed.";
    }    
    
    // Check for any validation errors
    if (!empty($validation_errors)) {
        $_SESSION['xmessage'] = implode("<br>", $validation_errors);
        header("Location: /user/edit-institution?eins=$nidn");
        exit();
    }

// Trim and filter the values of jur_satu, jur_dua, jur_tiga, jur_empat, and jur_lima
$jurusan_values = array_map('trim', [$jur_satu, $jur_dua, $jur_tiga, $jur_empat, $jur_lima]);
$jurusan_values = array_filter($jurusan_values);
$jurusan = implode(';', $jurusan_values);


    // Prepare and execute the SQL update statement
    $stmt = $conn->prepare("UPDATE users_bkd SET 
                            nidn = :nidn,
                            nip = :nip,
                            no_sert = :no_sert,
                            jbtn_fung = :jbtn_fung,
                            gol_pang = :gol_pang,
                            jenis_ds = :jenis_ds,
                            jurusan = :jurusan,
                            fakultas = :fakultas,
                            almt_kntr = :almt_kntr
                            WHERE user_id = :user_id");

    $stmt->bindParam(':user_id', $user_id);
    $stmt->bindParam(':nidn', $nidn);
    $stmt->bindParam(':nip', $nip);
    $stmt->bindParam(':no_sert', $no_sert);
    $stmt->bindParam(':jbtn_fung', $jbtn_fung);
    $stmt->bindParam(':gol_pang', $gol_pang);
    $stmt->bindParam(':jenis_ds', $jenis_ds);
    $stmt->bindParam(':jurusan', $jurusan); // Bind the concatenated value
    $stmt->bindParam(':fakultas', $fakultas);
    $stmt->bindParam(':almt_kntr', $almt_kntr);

    // Execute the statement and check for errors
    if (!$stmt->execute()) {
        print_r($stmt->errorInfo());
        exit(); // Stop execution to investigate the issue
    }

    // Check if the update was successful
    if ($stmt->rowCount() > 0) {
        $_SESSION['message'] = "Institusi berhasil diperbarui.";
    } else {
        $_SESSION['xmessage'] = "Institusi gagal diperbarui.";
    }

    // Redirect to the profile page or any other appropriate page
    header("Location: /user/edit-institution?eins=$nidn");
    exit();
}

// If the form is not submitted, retrieve the user data for pre-filling the form
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users_bkd WHERE user_id = :user_id");
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // Other code for displaying the form with pre-filled data
    // HTML and Bootstrap code for the update form goes here
}
?>
