<?php
session_start();

header("Location: /user/dasbor?dash=", true, 301);
exit() or die();
?>