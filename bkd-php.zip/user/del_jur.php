<?php
session_start();
include('./../includes/Dtbase.php'); // Include your database connection file

// Instantiate the DatabaseConnection class
$databaseConnection = new DatabaseConnection();
$conn = $databaseConnection->getConnection();

if (isset($_SESSION['user_id']) && isset($_POST['del_data'])) {
    $user_id = $_SESSION['user_id'];
    $data_id = $_POST['del_data'];

    try {
        // Make sure to validate user_id and data_id to prevent SQL injection

        // Test a simplified query
        $query = "UPDATE users_bkd 
          SET jur_satu = NULL,
              jur_dua = NULL,
              jur_tiga = NULL,
              jur_empat = NULL,
              jur_lima = NULL
          WHERE user_id = :user_id";

        $statement = $conn->prepare($query);

        if (!$statement) {
            die("Persiapan eksekusi gagal: " . $conn->errorInfo()[2]);
        }

        $data = [
            ':user_id' => $user_id,
        ];

        $query_execute = $statement->execute($data);

        if ($query_execute) {
            $_SESSION['message'] = "Jurusan berhasil dihapus.";
            echo "Jurusan berhasil dihapus.";
        } else {
            $_SESSION['message'] = "Jurusan gagal dihapus.";
            echo "Jurusan gagal dihapus.";
        }

    } catch (PDOException $e) {
        // Log the detailed error message
        error_log("PDOException: " . $e->getMessage());

        // Display a user-friendly error message on the page
        echo "Terjadi error yang tidak diharapkan. Silahkan coba lagi.";
    }
} else {
    echo "Error: tidak ada user_id atau data_id yang diperlukan.";
}
?>
