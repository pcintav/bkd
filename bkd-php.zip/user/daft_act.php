<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
?>
<?php  
session_start();
require_once ("../includes/Dtbase.php"); 

$dbConnection = new DatabaseConnection();
$conn = $dbConnection->getConnection();

if(isset($_POST['daftar']))

{ 
      
    // Menyimpan respons Google Recaptcha di variable $recaptcha  
    $recaptcha = $_POST['g-recaptcha-response']; 
  
    // Masukkan kunci rahasia di sini, yang kami dapatkan dari konsol Google 
    $secret_key = '6Lfpp1UpAAAAAGnB0hTZdj2vz7EQCHtmeNS2gl2n'; 
  
    // Mengirim permintaan ke URL, Google akan merespons dengan skenario sukses atau kesalahan
    $url = 'https://www.google.com/recaptcha/api/siteverify?secret='
          . $secret_key . '&response=' . $recaptcha; 
  
    // Membuat permintaan untuk memverifikasi captcha
    $response = file_get_contents($url); 
  
    // Respon yang dikembalikan oleh Google dalam format JSON, jadi kita harus mengurai json tersebut
    $response = json_decode($response); 
  
    // Memeriksa, apakah responsnya benar atau tidak
    if ($response->success == false) { 
        $_SESSION['xmessage'] = "Recaptcha belum diinput";
        header('Location: /user/daft');
        exit(0);
    } 

    else
    {
        if (isset($_POST['daftar'])) {
            // Sanitize and validate input fields
            $nama = filter_var($_POST['nama'], FILTER_SANITIZE_STRING);
        
            // Validate name (alphabet and spaces only)
            if (!preg_match('/^[a-zA-Z ]+$/', $nama)) {
                $_SESSION['xmessage'] = "Name can only contain letters and spaces.";
                header('Location: /user/daft');
                exit(0);
            }
        
           $nidn = filter_var($_POST['nidn'], FILTER_VALIDATE_INT);

           // Validate nidn (only 10 numbers allowed)
           if ($nidn === false || strlen($nidn) != 10) {
               $_SESSION['xmessage'] = "Username must be exactly 10 numbers.";
               header('Location: /user/daft');
               exit(0);
           }
        
            $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
            $password = $_POST['passwd'];
        
            // Validate password strength (your existing logic)
            if (strlen($password) < 8 || !preg_match('/[a-z]/', $password) || !preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
                $_SESSION['xmessage'] = "Password must be at least 8 characters long and contain a mix of letters, numbers, and symbols.";
                header('Location: /user/daft');
                exit(0);
            }
        
            // Check for empty fields (your existing logic)
            if (empty($nama) || empty($nidn) || empty($email) || empty($password)) {
                $_SESSION['xmessage'] = "Please fill in all fields.";
                header('Location: /user/daft');
                exit(0);
            }
            
            // Check for unique nidn and email
            $query = "SELECT COUNT(*) FROM users_bkd WHERE nidn = :nidn OR email = :email";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':nidn', $nidn);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
        
            if ($stmt->fetchColumn() > 0) {
                $_SESSION['xmessage'] = "Username or email already exists. Please choose a different one.";
                header('Location: /user/daft');
                exit(0);
            }
        
            // Hash password securely (your existing logic)
            $hash = password_hash($password, PASSWORD_BCRYPT, array("cost" => 12));
        
            // Prepare and execute query with parameterized statements (your existing logic)
            $query = "INSERT INTO users_bkd (nidn, nama, email, passwd) VALUES (:nidn, :nama, :email, :passwd)";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':nidn', $nidn);
            $stmt->bindParam(':nama', $nama);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':passwd', $hash);
        
            if ($stmt->execute()) {
                $_SESSION['message'] = "Sukses mendaftar BKD";
                header('Location: /login');
                exit(0);
            } else {
                $_SESSION['xmessage'] = "Gagal mendaftar BKD";
                header('Location: /user/daft');
                exit(0);
            }
        }

    }

}
