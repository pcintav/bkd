
        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          <nav
            class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
            id="layout-navbar">
            <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
              <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                <i class="ti ti-menu-2 ti-sm"></i>
              </a>
            </div>

            <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                
            <?php 
            if(isset($_GET['dash'])){
            echo "DASBOR AKUN";
            } 
            if(isset($_GET['epro'])){
            echo "EDIT PROFIL";
            }
            if(isset($_GET['eins'])){
            echo "EDIT INSTITUSI";
            }
            if(isset($_GET['sett'])){
            echo "PENGATURAN";
            }
            if(isset($_GET['nbkd'])){
            echo "BUAT BARU RENCANA BKD";
            } 
            if(isset($_GET['nlkd'])){
            echo "EDIT LAPORAN KINERJA";
            }
            if(isset($_GET['bkdr'])){
            echo "RENCANA BKD";
            }
            if(isset($_GET['lkdr'])){
            echo "LAPORAN KINERJA";
            }
            if(isset($_GET['gd'])){
            echo "PEDOMAN";
            }
            if(isset($_GET['ttr'])){
            echo "TUTORIAL";
            }
            if(isset($_GET['img'])){
            echo "UPLOAD";
            }
            if(isset($_GET['ctc'])){
            echo "KONTAK";
            }
            if(isset($_GET['edn'])){
            echo "EDIT ULANG RBKD";
            }
            ?>
            <?php //echo " | " . htmlspecialchars($_SESSION['nama']) . "!"; ?>
   
              <ul class="navbar-nav flex-row align-items-center ms-auto">
                <div class="border rounded-pill py-1 px-2 me-2">  
                <small><?php $todayis = date("d-m-Y"); echo "\x20\x20\x20" . $todayis; ?></small>
                </div>
			    <!-- Light Dark -->
				  <li class="navbar-nav align-items-center">
					<div class="nav-item dropdown-style-switcher dropdown me-2 me-xl-0">
					  <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
						<i class="ti ti-md"></i>
					  </a>
					  <ul class="dropdown-menu dropdown-menu-end dropdown-styles">
						<li>
						  <a class="dropdown-item" href="javascript:void(0);" data-theme="light">
							<span class="align-middle"><i class="ti ti-sun me-2"></i>Terang</span>
						  </a>
						</li>
						<li>
						  <a class="dropdown-item" href="javascript:void(0);" data-theme="dark">
							<span class="align-middle"><i class="ti ti-moon me-2"></i>Gelap</span>
						  </a>
						</li>
						<li>
						  <a class="dropdown-item" href="javascript:void(0);" data-theme="system">
							<span class="align-middle"><i class="ti ti-device-desktop me-2"></i>Sistem</span>
						  </a>
						</li>
					  </ul>
					</div>
				  </li>
				 <!-- User -->
				<li class="nav-item navbar-dropdown dropdown-user dropdown">
				  <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
					<div class="avatar avatar-online">
					    <?php
                        // Check if $fotoprofil_url is empty or null
                        if (!empty($fotoprofil_url)) {
                            // If $fotoprofil_url contains a valid image URL, display the user's image
                        ?>
					  <img src="<?php echo $web_pt; ?>/user/<?php echo $fotoprofil_url; ?>" alt class="h-40 rounded-circle" />
					  <?php
                        } else {
                            // If $fotoprofil_url is empty or null, display a default image
                            ?>
                            <img src="<?php echo $web_pt; ?>/assets/img/avatars/profile-placeholder.jpg" class="img-thumbnail" style="width: 35px; height: 35px; object-fit: cover; border-radius: 15px;">
                            <?php
                        }
                        ?>
					</div>
				  </a>
				  <ul class="dropdown-menu dropdown-menu-end">
					<li>
					  <a class="dropdown-item" href="/user/dasbor?dash=<?php echo $nidn; ?>">
						<div class="d-flex">
						  <div class="flex-shrink-0 me-3">
							<div class="avatar avatar-online">
							  <?php
                                // Check if $fotoprofil_url is empty or null
                                if (!empty($fotoprofil_url)) {
                                    // If $fotoprofil_url contains a valid image URL, display the user's image
                                ?>
        					  <img src="<?php echo $web_pt; ?>/user/<?php echo $fotoprofil_url; ?>" alt class="h-40 rounded-circle" />
        					  <?php
                                } else {
                                    // If $fotoprofil_url is empty or null, display a default image
                                    ?>
                                    <img src="<?php echo $web_pt; ?>/assets/img/avatars/profile-placeholder.jpg" class="img-thumbnail" style="width: 35px; height: 35px; object-fit: cover; border-radius: 15px;">
                                    <?php
                                }
                                ?>
							</div>
						  </div>
						  <div class="flex-grow-1">
							<span class="fw-medium d-block"><?php echo $nama; ?></span>
							<small class="text-muted">Profile</small>
						  </div>
						</div>
					  </a>
					</li>
					<li>
					  <div class="dropdown-divider"></div>
					</li>
					<li>
					  <a class="dropdown-item" href="/user/edit-profile?epro=<?php echo $nidn; ?>">
						<i class="ti ti-user-check me-2 ti-sm"></i>
						<span class="align-middle">Edit Profil</span>
					  </a>
					</li>
					<li>
					  <a class="dropdown-item" href="/user/edit-institution?eins=<?php echo $nidn; ?>">
						<i class="ti ti-building-community me-2 ti-sm"></i>
						<span class="align-middle">Edit Institusi</span>
					  </a>
					</li>						
					<li>
					  <a class="dropdown-item" href="/user/settings?sett=<?php echo $nidn; ?>">
						<i class="ti ti-settings me-2 ti-sm"></i>
						<span class="align-middle">Pengaturan</span>
					  </a>
					</li>
					<li>
					  <div class="dropdown-divider"></div>
					</li>
					<li>
					  <a class="dropdown-item" href="https://bkd.sistm.app/logout">
						<i class="ti ti-logout me-2 ti-sm"></i>
						<span class="align-middle">Keluar</span>
					  </a>
					</li>
				  </ul>
				</li>
				<!--/ User -->
              </ul>
            </div>
          </nav>

          <!-- / Navbar -->
          
          <!-- Content wrapper -->
          <div class="content-wrapper">
                        