<?php require_once ("header.php"); ?>
<?php require_once ("sidebar.php"); ?>
<?php require_once ("topbar.php"); ?>
<?php require_once ("adm_db.php"); ?>

        <!-- Content -->
        
        <div class="container-xxl flex-grow-1 container-p-y">
		<div class="row px-3">
	        <div class="col p-2 card">
		    <object data="<?php echo $web_pt; ?>/adm/<?php echo $guide_url; ?>" type="application/pdf" width="100%" height="1000px">
					<p>Unable to display PDF file. <a href="<?php echo $web_pt; ?>/adm/<?php echo $guide_url; ?>">atau Download</a>.</p>
			</object>
			</div>
	    </div>
	    </div>
	
        <!-- / Content -->


<?php require_once ("footer.php"); ?>