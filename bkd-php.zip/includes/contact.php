<?php require_once ("header.php"); ?>
<?php require_once ("sidebar.php"); ?>
<?php require_once ("topbar.php"); ?>
<?php require_once ("adm_db.php"); ?>

        <!-- Content -->
        
        <div class="container-xxl flex-grow-1 container-p-y small">
            <!-- Draggable Marker With Popup -->
            <div class="col-12">
                <div class="card mb-4">
                <h5 class="card-header">LOKASI KAMI DI PETA</h5>
                    <div class="card-body w-100 h-25">
                        <span class=""><?php echo $maps_adm; ?></span>
                      <!--<div class="leaflet-map" id="dragMap"></div>-->
                   </div>
                </div>
            </div>
               
               
                <!-- /Draggable Marker With Popup -->
        
			<div class="row">
			 <!-- left col -->        
              <div class="col-xl-6 col-lg-5 col-md-5 order-1 order-md-0">
                  <div class="card mb-4">
                    <div class="card-body">
			        <p class="fs-5 fw-semibold">HUBUNGI KAMI</p>
				    <span><?php echo $context_adm; ?></span>
					<p class="fs-4 mt-5"><i class="menu-icon tf-icons ti ti-home"></i><span style="font-size:16px;"><?php echo $almt_adm; ?></span></p>
					<p class="fs-4"><i class="menu-icon tf-icons ti ti-mail-forward"></i><span style="font-size:16px;"><?php echo $email_adm; ?></span></p>
					<p class="fs-4"><i class="menu-icon tf-icons ti ti-world-www"></i><span style="font-size:16px;"> <?php echo $web_adm; ?></span></p>
					<p class="fs-4"><i class="menu-icon tf-icons ti ti-device-landline-phone"></i><span style="font-size:16px;"> <?php echo $telp_adm; ?></span></p>
				  </div>    
				 </div>    
			  </div>
				
				
			<!-- right col -->    
             <div class="col-xl-6 col-lg-5 col-md-5 order-1 order-md-0">
                <div class="card mb-4">
                 <div class="card-body">
				  <p class="fs-5 fw-semibold">KIRIM PESAN PADA KAMI</p>
    				<form>
    					  <div class="mb-3">
    						<label for="InputName1" class="form-label">Nama</label>
    						<input type="text" class="form-control" id="InputName1" aria-describedby="inputName">
    					  </div>
    					<div class="mb-3">
    					  <label for="exampleFormControlInput1" class="form-label">Email</label>
    					  <input type="email" class="form-control" id="exampleFormControlInput1">
    					</div>
    					<div class="mb-3">
    					  <label for="exampleFormControlTextarea1" class="form-label">Pesan Anda</label>
    					  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
    					</div>
    				  <button type="submit" class="btn btn-primary">Kirim</button>
    				</form>	
				 </div>
				</div>
			 </div>
	   </div>
	   
	
    <!-- / Content -->



<?php require_once ("footer.php"); ?>