    <!-- Layout wrapper 
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">-->
        <!-- Menu -->
        <?php
        //session_start();
        
        // Include your database connection class
        //require_once('Dtbase.php');
        
        // Instantiate the DatabaseConnection class
        //$databaseConnection = new DatabaseConnection();
        //$conn = $databaseConnection->getConnection();
        
        // Initialize $nidn
        $nidn = '';
        
        // Fetch nidn from the database based on user_id
        if ($conn) {
            $user_id = $_SESSION['user_id'];
        
            try {
                $stmt = $conn->prepare("SELECT nidn FROM users_bkd WHERE user_id = :user_id");
                $stmt->bindParam(':user_id', $user_id);
                $stmt->execute();
        
                if ($stmt->rowCount() > 0) {
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    $nidn = $row['nidn'];
                } else {
                    // Handle the case when no records are found
                    echo "<p>No records found for the specified user_id.</p>";
                }
            } catch (PDOException $e) {
                // Handle PDO exceptions
                echo "<p>Error: " . $e->getMessage() . "</p>";
            }
        } else {
            // Handle the case when the database connection fails
            echo "<p>Error: Database connection failed.</p>";
        }
        ?>
        <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
          <div class="app-brand demo">
            <a href="/user/dasbor?dash=<?php echo $nidn; ?>" class="app-brand-link">
              <span class="app-brand-logo demo">
                <?php
                // Check if $fotologo_url is empty or null
                if (!empty($fotologo_url)) {
                    // If $fotologo_url contains a valid image URL, display the user's image
                ?>
                <img src="<?php echo $web_pt; ?>/adm/<?php echo $fotologo_url; ?>" class="img-thumbnail" style="width: 25px; height: 25px; object-fit: cover; border-radius: 5px;">
                <?php
                } else {
                    // If $fotologo_url is empty or null, display a default image
                    ?>
                    <img src="<?php echo $web_pt; ?>/assets/img/avatars/1.png" class="img-thumbnail" style="width: 25px; height: 25px; object-fit: cover; border-radius: 5px;">
                    <?php
                }
                ?>
              </span>
              <span class="app-brand-text demo menu-text fw-bold ">BKD</span>
            </a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
              <i class="ti menu-toggle-icon d-none d-xl-block ti-sm align-middle"></i>
              <i class="ti ti-x d-block d-xl-none ti-sm align-middle"></i>
            </a>
          </div>

          <div class="menu-inner-shadow"></div>

          <ul class="menu-inner py-1">
            <!-- Dashboard -->			
            <li class="menu-item">
              <a href="/user/dasbor?dash=<?php echo $nidn; ?>" class="menu-link">
                <i class="menu-icon tf-icons ti ti-layout-sidebar"></i>
                <div data-i18n="DASBOR AKUN">DASBOR AKUN</div>
              </a>
            </li>
           
            <li class="menu-item open">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-file-description"></i>
                <div data-i18n="RBKD DAN LKD">RBKD DAN LKD</div>
              </a>
              <ul class="menu-sub ms-4">            
                <li class="menu-item">
                  <a href="/user/rbkd-report?bkdr=<?php echo $nidn; ?>" class="menu-link">
                    <div data-i18n="Rencana BKD">Rencana BKD</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="/user/lkd-report?lkdr=<?php echo $nidn; ?>" class="menu-link">
                    <div data-i18n="Laporan Kinerja">Laporan Kinerja</div>
                  </a>
                </li>
              </ul>
            </li>
		    <!-- Front Pages -->			
            <li class="menu-item open">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-user-circle"></i>
                <div data-i18n="AKUN SAYA">AKUN SAYA</div>
              </a>
              <ul class="menu-sub ms-4">
                <li class="menu-item">
                  <a href="/user/edit-profile?epro=<?php echo $nidn; ?>" class="menu-link">
                    <div data-i18n="Edit Profil">Edit Profil</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="/user/edit-institution?eins=<?php echo $nidn; ?>" class="menu-link">
                    <div data-i18n="Edit Institusi">Edit Institusi</div>
                  </a>
                </li>                
                
                <li class="menu-item">
                  <a href="/user/up-image?img=<?php echo $nidn; ?>" class="menu-link">
                    <div data-i18n="Foto & Dokumen">Foto & Dokumen</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="/user/settings?sett=<?php echo $nidn; ?>" class="menu-link">
                    <div data-i18n="Pengaturan">Pengaturan</div>
                  </a>
                </li>
              </ul>
            </li>            
            <div class="w-100 mb-2"><hr></div>
            <li class="menu-item open">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-books"></i>
                <div data-i18n="PANDUAN">PANDUAN</div>
              </a>
              <ul class="menu-sub ms-4">
                <li class="menu-item">
                  <a href="/includes/guide?gd=<?php echo $nidn; ?>" class="menu-link">
                    <div data-i18n="Pedoman">Pedoman</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="/includes/tutorial?ttr=<?php echo $nidn; ?>" class="menu-link">
                    <div data-i18n="Tutorial">Tutorial</div>
                  </a>
                </li>
              </ul>
            </li>
            <li class="menu-item">
              <a href="/includes/contact?ctc=<?php echo $nidn; ?>" class="menu-link">
                <i class="menu-icon tf-icons ti ti-device-landline-phone"></i>
                <div data-i18n="Kontak">Kontak</div>
              </a>
            </li>            
		</ul>
        </aside>
        <!-- / Menu -->
