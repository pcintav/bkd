<?php
session_start();

// Include your database connection class
require_once('../includes/Dtbase.php');

// Instantiate the DatabaseConnection class
$databaseConnection = new DatabaseConnection();
$conn = $databaseConnection->getConnection();

// Fetch user's name from the database based on user_id
if ($conn) {
    $user_id = $_SESSION['user_id'];
    try {
        $stmt = $conn->prepare("SELECT nidn FROM users_bkd WHERE user_id = :user_id");
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $nidn = $row['nidn'];

            // Sanitize and urlencode the user's name
            $nidn = rawurlencode(htmlspecialchars($nidn, ENT_QUOTES, 'UTF-8'));
        } else {
            // Default name if user not found (replace with your logic)
            $nidn = "JohnDoe";
        }
    } catch (PDOException $e) {
        // Handle database query errors
        echo "Database query failed: " . $e->getMessage();
        exit();
    }
} else {
    // Handle database connection failure
    echo "Database connection failed.";
    exit();
}

// Close the database connection
$conn = null;

// Construct URLs with the user's name for different pages
$dasbor = "/user/dasbor?dash=" . $nidn;
$profile = "/user/profile?dash=" . $nidn;
$settings = "/user/settings?dash=" . $nidn;
// Add more URLs as needed
?>
