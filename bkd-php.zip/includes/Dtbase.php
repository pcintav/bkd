<?php
// Securely check for direct access to Dtbase.php
if (stripos($_SERVER['SCRIPT_NAME'], 'Dtbase.php') !== false) {
  header('Location: /index');
  exit();
}
class DatabaseConnection {

    private $host = "localhost";
    private $username = "sistm_bkddb";
    private $password = "Kh4112ul#_";
    private $db_name = "sistm_bkd_lkd";

    public function getConnection() {
        try {
            $conn = new PDO("mysql:host=$this->host;dbname=$this->db_name", $this->username, $this->password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            //echo "Database connection successful";
            return $conn;
        } catch (PDOException $e) {
            echo "Database connection failed: " . $e->getMessage();
            return false;
        }
    }
}