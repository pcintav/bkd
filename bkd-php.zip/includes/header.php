<?php
// Set maximum session inactivity time to 30 minutes (1800 seconds)
ini_set('session.gc_maxlifetime', 1800);

try {
  session_start();
} catch (Exception $e) {
  error_log("Error starting session: " . $e->getMessage()); // Log the error
  echo "An error occurred while starting the session. Please try again later."; // User-friendly message
  exit();
}

// Align cookie lifetime with session lifetime
try {
  setcookie(session_name(), session_id(), time() + 1800, '/', '', true, true); // Secure and HttpOnly flags
} catch (Exception $e) {
  echo "Error setting cookie: " . $e->getMessage();
  echo "An error occurred while setting a cookie. Please check your browser settings and try again.";
}

// Optionally regenerate the session ID
try {
  session_regenerate_id(true);
} catch (Exception $e) {
  error_log("Error regenerating session ID: " . $e->getMessage());
}

// Track user activity and refresh session timeout if necessary
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
  try {
    session_unset();
    session_destroy();
    header("Location: /index"); // Redirect to index page
    exit();
  } catch (Exception $e) {
    error_log("Error cleaning up inactive session: " . $e->getMessage());
    echo "An error occurred while processing your request. Please try again later.";
  }
}

// Check for logged-in status using isLoggedIn
if (!isset($_SESSION['isLoggedIn']) || $_SESSION['isLoggedIn'] !== true) {
  header("Location: /index"); // Redirect to login page
  exit();
}

// Store user data in the session
if (isset($user_id)) {
  $_SESSION['user_id'] = $user_id;
}

if (isset($nidn)) {
  $_SESSION['nidn'] = $nidn;
}

$_SESSION['LAST_ACTIVITY'] = time(); // Update last activity timestamp
?>
<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-navbar-fixed layout-menu-fixed layout-compact"
  dir="ltr"
  data-theme="theme-semi-dark"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-semi-dark">
  <head>
    <meta charset="utf-8">
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">

    <title>BKD |
    <?php 
            
        if(isset($_GET['dash'])){
        echo "DASBOR AKUN";
        } 
        if(isset($_GET['epro'])){
        echo "EDIT PROFIL";
        }
        if(isset($_GET['eins'])){
        echo "EDIT INSTITUSI";
        }
        if(isset($_GET['sett'])){
        echo "PENGATURAN";
        }
        if(isset($_GET['nbkd'])){
        echo "BUAT BARU RENCANA BKD";
        } 
        if(isset($_GET['nlkd'])){
        echo "EDIT LAPORAN KINERJA";
        }
        if(isset($_GET['bkdr'])){
        echo "RENCANA BKD";
        }
        if(isset($_GET['lkdr'])){
        echo "LAPORAN KINERJA";
        }
        if(isset($_GET['gd'])){
        echo "PEDOMAN";
        }
        if(isset($_GET['ttr'])){
        echo "TUTORIAL";
        }
        if(isset($_GET['img'])){
        echo "UPLOAD DOKUMEN";
        }
        if(isset($_GET['ctc'])){
        echo "KONTAK";
        }
        if(isset($_GET['edn'])){
        echo "EDIT ULANG RBKD";
        }
    ?>
    </title>
    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&ampdisplay=swap" rel="stylesheet" />

    <!-- Icons -->
    <link rel="stylesheet" href="../assets/vendor/fonts/tabler-icons.css" />
    
    <!-- Core CSS -->
    <link rel="stylesheet" href="../assets/vendor/css/rtl/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../assets/vendor/css/rtl/theme-semi-dark.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../assets/css/demo.css" />
    <link rel="stylesheet" href="../assets/styles.css" />
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    
    <!-- Helpers -->
    <script src="../assets/vendor/js/helpers.js"></script>
    <script src="../assets/vendor/js/template-customizer.js"></script>    
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="../assets/js/config.js"></script>


    <!-- Vendors CSS -->
    <link rel="stylesheet" href="../assets/vendor/libs/node-waves/node-waves.css" />
    <link rel="stylesheet" href="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
    <link rel="stylesheet" href="../assets/vendor/libs/typeahead-js/typeahead.css" />
    <link rel="stylesheet" href="../assets/vendor/libs/swiper/swiper.css" />
    <link rel="stylesheet" href="../assets/vendor/libs/flatpickr/flatpickr.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <!-- Page CSS -->
    <link rel="stylesheet" href="../assets/vendor/css/pages/cards-advance.css" />

    <!-- Include DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

  </head>

  <body>
         <?php
        // Check if the user is logged in
        if (!isset($_SESSION['user_id'])) {
            // Redirect to the login page or handle the case when the user is not logged in
            header("Location: /index");
            exit();
        }
        
        // Include your database connection class
        require_once('Dtbase.php');
        
        // Instantiate the DatabaseConnection class
        $databaseConnection = new DatabaseConnection();
        $conn = $databaseConnection->getConnection();
        ?>
        <?php
        // Initialize datas from database
        $fotologo_url = $fotoindex_url = '';
        
        // Fetch data from the database for admin
        if ($conn) {
            try {
                $stmt = $conn->prepare("SELECT * FROM adm_bkd");
                $stmt->execute();
        
                if ($stmt->rowCount() > 0) {
                    // Fetch the first row as an associative array
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
                    // Assign values to variables
                    $fotologo_url = $row['fotologo_url'];
                    $fotoindex_url = $row['fotoindex_url'];
                    /*$uname = $row['uname'];
                    $nama_adm = $row['nama_adm'];
                    $email_adm = $row['email_adm'];
                    $thn_akademik = $row['thn_akademik'];
                    $semester = $row['semester'];
                    $tgl_daftar = $row['tgl_daftar'];*/
        
                } else {
                    // Handle the case when no records are found
                    echo "<p>No records found in the adm_bkd table.</p>";
                }
            } catch (PDOException $e) {
                // Handle PDO exceptions
                echo "<p>Error: " . $e->getMessage() . "</p>";
            }
        } else {
            // Handle the case when the database connection fails
            echo "<p>Error: Database connection failed.</p>";
        }
        
        // Fetch values for select options from other tables in the database
        $thn_akademik_options = getTahunOptions($conn, 'thn_akademik', 'tahun');
        
        function getTahunOptions($conn, $tableThn, $columnTahun)
        {
            try {
                $stmt = $conn->prepare("SELECT DISTINCT $columnTahun FROM $tableThn");
                $stmt->execute();
        
                $options = array();
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $options[] = $row[$columnTahun];
                }
        
                return $options;
            } catch (PDOException $e) {
                // Handle PDO exceptions
                echo "<p>Error: " . $e->getMessage() . "</p>";
            }
        }        
        ?>        
        <?php
        
        // Initialize datas from database
        $fotoprofil_url = $fotoktp_url = $nidn = $email = $nama = $glr_depan = $glr_belakang = $tgl_lhr = $tmpt_lhr = $almt_rmh = $no_telp = $no_wa = $pend_s1 = $pend_s2 = $pend_s3 = $keilmuan = $tgl_daftar = $nip = $no_sert = $jbtn_fung = $gol_pang = $jenis_ds = $jur_satu = $jur_dua = $jur_tiga = $jur_empat = $jur_lima = $fakultas = $jurusan = $almt_kntr = $buktipns_url = $buktisert_url = $buktis1_url = $buktis2_url = $buktis3_url = $buktiprof_url = $buktipns_name = $buktisert_name = $buktis1_name = $buktis2_name = $buktis3_name = $buktiprof_name = $tgl_daftar = '';
        
        // Fetch datas from the database based on user_id
        if ($conn) {
            $user_id = $_SESSION['user_id'];
        
            try {
                $stmt = $conn->prepare("SELECT * FROM users_bkd WHERE user_id = :user_id");
                $stmt->bindParam(':user_id', $user_id);
                $stmt->execute();
        
                if ($stmt->rowCount() > 0) {
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    $fotoprofil_url = $row['fotoprofil_url'];
                    $fotoktp_url = $row['fotoktp_url'];
                    $nidn = $row['nidn'];
                    $email = $row['email'];
                    $nama = $row['nama'];
                    $glr_depan = $row['glr_depan'];
                    $glr_belakang = $row['glr_belakang'];
                    $tgl_lhr = date('Y-m-d', strtotime($row['tgl_lhr']));
                    $tmpt_lhr = $row['tmpt_lhr'];
                    $almt_rmh = $row['almt_rmh'];
                    $no_telp = $row['no_telp'];
                    $no_wa = $row['no_wa'];
                    $pend_s1 = $row['pend_s1'];
                    $pend_s2 = $row['pend_s2'];
                    $pend_s3 = $row['pend_s3'];
                    $keilmuan = $row['keilmuan'];
                    $nip = $row['nip'];
                    $no_sert = $row['no_sert'];
                    $jbtn_fung = $row['jbtn_fung'];
                    $gol_pang = $row['gol_pang'];
                    $jenis_ds = $row['jenis_ds'];
                    $jur_satu = $row['jur_satu'];
                    $jur_dua = $row['jur_dua'];
                    $jur_tiga = $row['jur_tiga'];
                    $jur_empat = $row['jur_empat'];
                    $jur_lima = $row['jur_lima'];
                    $fakultas = $row['fakultas'];
                    $jurusan = $row['jurusan'];
                    $almt_kntr = $row['almt_kntr'];
                    $buktipns_url = $row['buktipns_url'];
                    $buktisert_url = $row['buktisert_url'];
                    $buktis1_url = $row['buktis1_url'];
                    $buktis2_url = $row['buktis2_url'];
                    $buktis3_url = $row['buktis3_url'];
                    $buktiprof_url = $row['buktiprof_url'];
                    $buktipns_name = $row['buktipns_name'];
                    $buktisert_name = $row['buktisert_name'];
                    $buktis1_name = $row['buktis1_name'];
                    $buktis2_name = $row['buktis2_name'];
                    $buktis3_name = $row['buktis3_name'];
                    $buktiprof_name = $row['buktiprof_url'];
                    $tgl_daftar = date('Y-m-d', strtotime($row['tgl_daftar']));
                                            
                } else {
                    // Handle the case when no records are found
                    echo "<p>No records found for the specified user_id.</p>";
                }
            } catch (PDOException $e) {
                // Handle PDO exceptions
                echo "<p>Error: " . $e->getMessage() . "</p>";
            }
        } else {
            // Handle the case when the database connection fails
            echo "<p>Error: Database connection failed.</p>";
        }

        // Fetch values for select options from other tables in the database
        $jbtn_fung_options = getSelectOptions($conn, 'jabatan', 'jbtn');
        $gol_pang_options = getSelectOptions($conn, 'golongan', 'golpang');
        $jenis_options = getSelectOptions($conn, 'jenis', 'namajen');        
        $jurusan_satu_options = getSelectOptions($conn, 'jurusan_satu', 'namajur');
        $jurusan_dua_options = getSelectOptions($conn, 'jurusan_dua', 'namajur');
        $jurusan_tiga_options = getSelectOptions($conn, 'jurusan_tiga', 'namajur');
        $jurusan_empat_options = getSelectOptions($conn, 'jurusan_empat', 'namajur');
        $jurusan_lima_options = getSelectOptions($conn, 'jurusan_lima', 'namajur');
        $fakultas_options = getSelectOptions($conn, 'faculty', 'namafak');
        $status_rbkd_options = getSelectOptions($conn, 'status_rbkd', 'strb_op');
        $faculty_options = getSelectOptions($conn, 'faculty', 'fak_id');
        
        function getSelectOptions($conn, $tableName, $columnName)
        {
            try {
                $stmt = $conn->prepare("SELECT DISTINCT $columnName FROM $tableName");
                $stmt->execute();
        
                $options = array();
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $options[] = $row[$columnName];
                }
        
                return $options;
            } catch (PDOException $e) {
                // Handle PDO exceptions
                echo "<p>Error: " . $e->getMessage() . "</p>";
            }
        }
        

        ?>      
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">

