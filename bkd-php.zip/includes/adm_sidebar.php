    <!-- Layout wrapper 
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">-->
        <!-- Menu -->
        <?php
        
        // Initialize $uname
        $uname = '';
        
        // Fetch adm_id from the database based on adm_id
        if ($conn) {
            $adm_id = $_SESSION['adm_id'];
        
            try {
                $stmt = $conn->prepare("SELECT uname FROM adm_bkd WHERE adm_id = :adm_id");
                $stmt->bindParam(':adm_id', $adm_id);
                $stmt->execute();
        
                if ($stmt->rowCount() > 0) {
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    $uname = $row['uname'];
                } else {
                    // Handle the case when no records are found
                    echo "<p>No records found for the specified user_id.</p>";
                }
            } catch (PDOException $e) {
                // Handle PDO exceptions
                echo "<p>Error: " . $e->getMessage() . "</p>";
            }
        } else {
            // Handle the case when the database connection fails
            echo "<p>Error: Database connection failed.</p>";
        }
        ?>
        <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
          <div class="app-brand demo">
            <a href="/adm/dasbor?dash=<?php echo $uname; ?>" class="app-brand-link">
              <span class="app-brand-logo demo">
                <?php
                // Check if $fotologo_url is empty or null
                if (!empty($fotologo_url)) {
                    // If $fotologo_url contains a valid image URL, display the user's image
                ?>
                <img src="/adm/<?php echo $fotologo_url; ?>" class="img-thumbnail" style="width: 25px; height: 25px; object-fit: cover; border-radius: 5px;">
                <?php
                } else {
                    // If $fotologo_url is empty or null, display a default image
                    ?>
                    <img src="/assets/img/avatars/1.png" class="img-thumbnail" style="width: 25px; height: 25px; object-fit: cover; border-radius: 5px;">
                    <?php
                }
                ?>
              </span>
              <span class="app-brand-text demo menu-text fs-5 fw-bold">ADMIN LPM</span>
            </a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
              <i class="ti menu-toggle-icon d-none d-xl-block ti-sm align-middle"></i>
              <i class="ti ti-x d-block d-xl-none ti-sm align-middle"></i>
            </a>
          </div>

          <div class="menu-inner-shadow"></div>

          <ul class="menu-inner py-1">
            <!-- Dashboard -->			
            <li class="menu-item">
              <a href="/adm/dasbor?dash=<?php echo $uname; ?>" class="menu-link">
                <i class="menu-icon tf-icons ti ti-layout-sidebar"></i>
                <div data-i18n="DASBOR ADMIN">DASBOR ADMIN</div>
              </a>
            </li>
           
		    <!-- Front Pages -->
		    <li class="menu-item">
              <a href="/adm/list-users?ubkd=<?php echo $uname; ?>" class="menu-link">
                <i class="menu-icon tf-icons ti ti-users"></i>
                <div data-i18n="PENGGUNA">PENGGUNA</div>
              </a>
            </li>
            <li class="menu-item open">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-file-description"></i>
                <div data-i18n="RBKD DAN LKD">RBKD DAN LKD</div>
              </a>
              <ul class="menu-sub ms-4">            
                <li class="menu-item">
                  <a href="/adm/list-rbkd?bkdr=<?php echo $uname; ?>" class="menu-link">
                    <div data-i18n="List RBKD Dosen">List RBKD Dosen</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="/adm/list-lkd?lkdr=<?php echo $uname; ?>" class="menu-link">
                    <div data-i18n="List LKD Dosen">List LKD Dosen</div>
                  </a>
                </li>
              </ul>
            </li>            
            <li class="menu-item open">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-books"></i>
                <div data-i18n="PENGATURAN">PENGATURAN</div>
              </a>
              <ul class="menu-sub ms-4">
                <li class="menu-item">
                  <a href="/adm/sett-bkd?sbkd=<?php echo $uname; ?>" class="menu-link">
                    <div data-i18n="Pengaturan BKD">Pengaturan BKD</div>
                  </a>
                </li>  
                <li class="menu-item">
                  <a href="/adm/list-asesor?asdt=<?php echo $uname; ?>" class="menu-link">
                    <div data-i18n="List Asesor">List Asesor</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="/adm/list-fakultas?fakdt=<?php echo $uname; ?>" class="menu-link">
                    <div data-i18n="List Fakultas">List Fakultas</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="/adm/list-jurusan?jrdt=<?php echo $uname; ?>" class="menu-link">
                    <div data-i18n="List Jurusan">List jurusan</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="/adm/list-tahun?thdt=<?php echo $uname; ?>" class="menu-link">
                    <div data-i18n="List Tahun Akademik">List tahun Akademik</div>
                  </a>
                </li>
              </ul>
            </li>
            <li class="menu-item">
              <a href="/includes/contact?ctc=<?php echo $uname; ?>" class="menu-link">
                <i class="menu-icon tf-icons ti ti-device-landline-phone"></i>
                <div data-i18n="Kontak">Kontak</div>
              </a>
            </li>		    
            <div class="w-100 mb-2"><hr></div>
            <li class="menu-item open">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-user-circle"></i>
                <div data-i18n="AKUN ADMIN">AKUN ADMIN</div>
              </a>
              <ul class="menu-sub ms-4">
                <li class="menu-item">
                  <a href="/adm/edit-webprofile?epro=<?php echo $uname; ?>" class="menu-link">
                    <div data-i18n="Edit Info Unit">Edit Info Unit</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="/adm/edit-webkonten?ekon=<?php echo $uname; ?>" class="menu-link">
                    <div data-i18n="Edit Web Konten">Edit Web Konten</div>
                  </a>
                </li>                
                
                <li class="menu-item">
                  <a href="/adm/up-admimg?img=<?php echo $uname; ?>" class="menu-link">
                    <div data-i18n="Foto dan Dokumen">Foto dan Dokumen</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="/adm/set-adm?sett=<?php echo $uname; ?>" class="menu-link">
                    <div data-i18n="Pengaturan">Pengaturan Akun</div>
                  </a>
                </li>
              </ul>
            </li>            
            
		</ul>
        </aside>
        <!-- / Menu -->
