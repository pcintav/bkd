<?php
        /* Check if the user is logged in
        if (!isset($_SESSION['user_id'])) {
            // Redirect to the login page or handle the case when the user is not logged in
            header("Location: /index");
            exit();
        }*/
        
        // Include your database connection class
        require_once('Dtbase.php');
        
        // Instantiate the DatabaseConnection class
        $databaseConnection = new DatabaseConnection();
        $conn = $databaseConnection->getConnection();
        ?>
        <?php
        // Initialize datas from database
        $fotologo_url = $fotoindex_url = $uname = $nama_adm = $email_adm = $nama_institusi = $akreditasi_pt = $almt_adm = $telp_adm = $wa_adm = $guide_adm = $tutor_adm = $maps_adm = $context_adm = $footext_adm = $notif_adm = $web_adm = $fb_adm = $insta_adm = $yt_adm = $web_pt = $guide_url = $logopanjang_url = $dokumen1_url = $guide_name = $logopanjang_name = $dokumen1_name = $tgl_dftr = '';
        
        // Fetch data from the database for admin
        if ($conn) {
            try {
                $stmt = $conn->prepare("SELECT * FROM adm_bkd");
                $stmt->execute();
        
                if ($stmt->rowCount() > 0) {
                    // Fetch the first row as an associative array
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
                    // Assign values to variables
                    $fotologo_url = $row['fotologo_url'];
                    $fotoindex_url = $row['fotoindex_url'];
                    $uname = $row['uname'];
                    $nama_adm = $row['nama_adm'];
                    $email_adm = $row['email_adm'];
                    $nama_institusi = $row['nama_institusi'];
                    $akreditasi_pt = $row['akreditasi_pt'];
                    $almt_adm = $row['almt_adm'];
                    $telp_adm = $row['telp_adm'];
                    $wa_adm = $row['wa_adm'];
                    $tutor_adm = $row['tutor_adm'];
                    $maps_adm = $row['maps_adm'];
                    $context_adm = $row['context_adm'];
                    $footext_adm = $row['footext_adm'];
                    $notif_adm = $row['notif_adm'];
                    $web_adm = $row['web_adm'];
                    $fb_adm = $row['fb_adm'];
                    $insta_adm = $row['insta_adm'];
                    $yt_adm = $row['yt_adm'];
                    $guide_url = $row['guide_url'];
                    $logopanjang_url = $row['logopanjang_url'];
                    $dokumen1_url = $row['dokumen1_url'];
                    $guide_name = $row['guide_name'];
                    $logopanjang_name = $row['logopanjang_name'];
                    $dokumen1_name = $row['dokumen1_name'];
                    $tgl_dftr = $row['tgl_dftr'];
        
                } else {
                    // Handle the case when no records are found
                    echo "<p>No records found in the adm_bkd table.</p>";
                }
            } catch (PDOException $e) {
                // Handle PDO exceptions
                echo "<p>Error: " . $e->getMessage() . "</p>";
            }
        } else {
            // Handle the case when the database connection fails
            echo "<p>Error: Database connection failed.</p>";
        }
        
        ?>