<?php require_once ("header.php"); ?>
<?php require_once ("sidebar.php"); ?>
<?php require_once ("topbar.php"); ?>
<?php require_once ("adm_db.php"); ?>
        <!-- Content -->
        
    <div class="container-xxl flex-grow-1 container-p-y small">
			
		<div class="row">
			<!-- main col -->
				<div class="col pb-5">
				<div class="card p-3 border-0">
                <div class="card-body row p-0 pb-3">
					<p class="mb-2 fs-4">Tutorial Penggunaan</p>
					    <p><?php echo $tutor_adm; ?></p>
				</div>
				</div>
				</div>
        </div>	
	</div>
	
        <!-- / Content -->


<?php require_once ("footer.php"); ?>