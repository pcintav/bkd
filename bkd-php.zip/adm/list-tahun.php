<?php require_once ("../includes/adm_header.php"); ?>
<?php require_once ("../includes/adm_sidebar.php"); ?>
<?php require_once ("../includes/adm_topbar.php"); ?>


    <!-- Content -->
                  
    <?php
    // Fetch data from the database
    $stmt = $conn->query("SELECT thnakd_id, tahun FROM thn_akademik");
    $updates = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    ?>

    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col">
                
                <div class="card">
                 <div class="card-header">
                    <div class="row">
                        <div class="col">
                            <span class="badge bg-primary"><i class="ti ti-star me-2"></i>LIST TAHUN AKADEMIK</span>
                        </div>
                    </div> 
                 </div>         
                    <div class="card-body">
                        
                        
                        <form id="updateForm">
                            <?php
                            // Assuming $updates array is accessible here with faculty data
                            if (!empty($updates)) {
                                foreach ($updates as $update) {
                            ?>
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="tahun_<?php echo $update['thnakd_id']; ?>">Tahun Akademik:</label>
                                    <input type="text" class="form-control form-control-sm" id="tahun_<?php echo $update['thnakd_id']; ?>" name="tahun_<?php echo $update['thnakd_id']; ?>" value="<?php echo $update['tahun']; ?>">
                                </div>
                                <div class="col-md-3 mt-3">
                                    <button type="button" class="btn btn-sm btn-primary update-btn" data-thnakd-id="<?php echo $update['thnakd_id']; ?>">Perbarui</button>
                                </div>
                            </div>
                            <br>
                            <?php
                                }
                            } else {
                                echo "<p>No tahun akademik data available.</p>";
                            }
                            ?>
                        </form>
                        
                        <!-- Ensure jQuery is included -->
                        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
                        
                        <script>
                        $(document).ready(function() {
                            // Use event delegation to handle dynamically added buttons
                            $(document).on("click", ".update-btn", function() {
                                var thnakd_id = $(this).data("thnakd-id");
                                var tahun = $("#tahun_" + thnakd_id).val();
                        
                                $.ajax({
                                    type: "POST",
                                    url: "upd_tahun.php",
                                    data: {
                                        thnakd_id: thnakd_id,
                                        tahun: tahun
                                        
                                    },
                                    success: function(response) {
                                        alert(response);
                                    },
                                    error: function(xhr, status, error) {
                                        alert("Error: " + xhr.status);
                                    }
                                });
                            });
                        });
                        </script>
                                                        
                        
                    </div>
                </div>

            </div>
        </div>
    </div>
    

    <!-- / Content -->

<?php require_once ("../includes/adm_footer.php"); ?>