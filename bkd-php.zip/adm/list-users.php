<?php require_once ("../includes/adm_header.php"); ?>
<?php require_once ("../includes/adm_sidebar.php"); ?>
<?php require_once ("../includes/adm_topbar.php"); ?>

    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col">
                
                <div class="card">
                    <div class="row px-4 mt-4 mb-0">
                        <div class="col">
                            <span class="badge bg-primary me-2"><i class="ti ti-star me-1"></i>LIST DOSEN DAN STATUS</span>
                        </div>
                    </div> 
                          
                    <div class="card-body">
                        <?php if(isset($_SESSION['xmessage'])) : ?>
                        <h5 class="alert alert-danger"><?= $_SESSION['xmessage']; ?></h5>
                        <?php 
                            unset($_SESSION['xmessage']);
                            endif; 
                        ?>
                        <?php if(isset($_SESSION['message'])) : ?>
                        <h5 class="alert alert-success"><?= $_SESSION['message']; ?></h5>
                        <?php 
                            unset($_SESSION['message']);
                            endif; 
                        ?>
                        <div class="table-responsive">
                        <table class="display" id="bkdTable" style="font-size:14px;">
                            <thead class="table-light">
                               <tr class="text-center align-middle">
                                    <th class="thnbkdwd">No.</th>
                                    <th class="thnbkd">Nama</th>
                                    <th class="thnbkd">nidn</th>
                                    <th class="thnbkd">Fakultas</th>
                                    <th class="thnbkd">Jurusan</th>
                                    <th class="thnbkd">Status</th>
                                    <!--<th class="thnbkd">test</th>-->
                                    <th class="thnbkd"><i class="ti ti-settings"></i></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM users_bkd";
                                $statement = $conn->prepare($query);
                                
                                $statement->execute();
                                
                                $statement->setFetchMode(PDO::FETCH_OBJ);
                                $result = $statement->fetchAll();
                                if($result) {
                                    foreach($result as $row) {
                                ?>
                                    <tr>
                                        <td><span class="fs-tiny fw-bold text-uppercase"><?= $row->user_id; ?></span></td>
                                        <td><span class="fs-tiny fw-bold text-uppercase"><?= $row->nama; ?></span></td>
                                        <td><span class="fs-tiny text-uppercase"><?= $row->nidn; ?></span></td>
                                        <td><span class="fs-tiny text-uppercase"><?= $row->fakultas; ?></span></td>
                                        <td><span class="fs-tiny text-uppercase"><?= $row->jurusan; ?></span></td>
                                        <td><span class="badge bg-primary text-uppercase"></span></td>
                                        <!--<td>
                                            <form action="upd_user.php" method="POST">
                                                <a href="edit-user.php?edn=<?//= $row->user_id; ?>" style="font-size:12px;" class="btn btn-sm p-0 text-primary"><i class="ti ti-ballpen"></i></a>
                                            </form>
                                        </td>-->
                                        <td>
                                            <form action="del_user.php" method="POST">
                                            <a href="edit-user.php?edn=<?= $row->user_id; ?>" style="font-size:12px;" class="btn btn-sm p-0 text-primary me-2"><i class="ti ti-ballpen"></i></a><button type="submit" class="btn btn-sm p-0 text-danger" name="del_data" value="<?=$row->user_id ;?>" id="dlt" style="font-size:12px;" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-custom-class="custom-tooltip" data-bs-title="Hati-hati user dihapus, tidak dapat dipulihkan."><i class="ti ti-trash"></i></button> 
                                            </form>
                                        </td>
                                    </tr>
                                <?php
                                    }
                                } else {
                                ?>
                                    <tr>
                                        <td colspan="7"><span class="fs-5 text-danger">BELUM ADA DATA DOSEN YANG DAPAT DITAMPILKAN.</span></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                </tbody>
                        </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    
    <!-- / Content -->

    <!-- Include jQuery -->    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Include DataTables JavaScript -->
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
 
    <script>
    var $j = jQuery.noConflict(); // Gunakan $j sebagai pengganti $
    $j(document).ready(function() {
        $j('#bkdTable').DataTable({
            lengthMenu: [ [25, 50, 100, -1], [25, 50, 100, "Semua"] ], // Customize the dropdown options            
            language: {
                url: "../assets/json/Indonesian.json"
            }
        });
    });
    </script>
    


<?php require_once ("../includes/adm_footer.php"); ?>