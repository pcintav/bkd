<?php
session_start();

// Include your database connection class
include('../includes/Dtbase.php');

// Instantiate the DatabaseConnection class
$databaseConnection = new DatabaseConnection();
$conn = $databaseConnection->getConnection();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the current logged-in user ID from the session
    $adm_id = $_SESSION['adm_id'];

    // Sanitize and validate form data
    $uname = filter_input(INPUT_POST, 'uname', FILTER_SANITIZE_STRING);
    $nama_adm = filter_input(INPUT_POST, 'nama_adm', FILTER_SANITIZE_STRING);
    $almt_adm = filter_input(INPUT_POST, 'almt_adm', FILTER_SANITIZE_STRING);
    $nama_institusi = filter_input(INPUT_POST, 'nama_institusi', FILTER_SANITIZE_STRING);
    $akreditasi_pt = filter_input(INPUT_POST, 'akreditasi_pt', FILTER_SANITIZE_STRING);
    $telp_adm = filter_input(INPUT_POST, 'telp_adm', FILTER_SANITIZE_NUMBER_INT);
    $wa_adm = filter_input(INPUT_POST, 'wa_adm', FILTER_SANITIZE_NUMBER_INT);
    $web_adm = filter_input(INPUT_POST, 'web_adm', FILTER_SANITIZE_STRING);
    $fb_adm = filter_input(INPUT_POST, 'fb_adm', FILTER_SANITIZE_STRING);
    $insta_adm = filter_input(INPUT_POST, 'insta_adm', FILTER_SANITIZE_STRING);
    $yt_adm = filter_input(INPUT_POST, 'yt_adm', FILTER_SANITIZE_STRING);
    $web_pt = filter_input(INPUT_POST, 'web_pt', FILTER_SANITIZE_STRING);
    //$pend_s3 = filter_input(INPUT_POST, 'pend_s3', FILTER_SANITIZE_STRING);
    //$keilmuan = filter_input(INPUT_POST, 'keilmuan', FILTER_SANITIZE_STRING);

    $validation_errors = [];

    // Validate input fields
    if (!preg_match('/^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{8,}$/', $uname)) {
        $validation_errors[] = "Invalid value for uname. Must contain and only letters and numbers are allowed.";
    }
    
    if (!preg_match("/^[a-zA-Z ]+$/", $nama_adm)) {
        $validation_errors[] = "Invalid value for nama_adm. Only letters and spaces are allowed.";
    }
    
    if (!preg_match('/^[\p{L}0-9\s\/.,\-]+$/u', $almt_adm)) {
        $validation_errors[] = "Invalid value for almt_adm. Only letters, numbers, spaces, slashes, commas, periods, and hyphens are allowed.";
    }
    
    if (!preg_match("/^[a-zA-Z ]+$/", $nama_institusi)) {
        $validation_errors[] = "Invalid value for nama_institusi. Only letters and spaces are allowed.";
    }
    
    if (!preg_match("/^[a-zA-Z ]+$/", $akreditasi_pt)) {
        $validation_errors[] = "Invalid value for nama_adm. Only letters and spaces are allowed.";
    }
    
    if (!preg_match("/^\d+$/", $telp_adm)) {
        $validation_errors[] = "Invalid value for telp_adm. Must be a number.";
    }

    if (!preg_match("/^\d+$/", $wa_adm)) {
        $validation_errors[] = "Invalid value for wa_adm. Must be a number.";
    }

    if (!preg_match("/^[\w\s\/,.:?=&\\\\-]*+$/", $web_adm)) {
        $validation_errors[] = "Invalid value for web_adm. Only letters, numbers, spaces, slashes, commas, periods, colons, question marks, equal signs, ampersands, backslashes, or hyphens are allowed.";
    }

    if (!preg_match("/^[\w\s\/,.:?=&\\\\-]*+$/", $fb_adm)) {
        $validation_errors[] = "Invalid value for fb_adm. Only letters, numbers, spaces, slashes, commas, periods, colons, question marks, equal signs, ampersands, backslashes, or hyphens are allowed.";
    }

    if (!preg_match("/^[\w\s\/,.:?=&\\\\-]*+$/", $insta_adm)) {
        $validation_errors[] = "Invalid value for insta_adm. Only letters, numbers, spaces, slashes, commas, periods, colons, question marks, equal signs, ampersands, backslashes, or hyphens are allowed.";
    }

    if (!preg_match("/^[\w\s\/,.:?=&\\\\-]*+$/", $yt_adm)) {
        $validation_errors[] = "Invalid value for yt_adm. Only letters, numbers, spaces, slashes, commas, periods, colons, question marks, equal signs, ampersands, backslashes, or hyphens are allowed.";
    }

    if (!preg_match("/^[\w\s\/,.:?=&\\\\-]*+$/", $web_pt)) {
        $validation_errors[] = "Invalid value for web_pt. Only letters, numbers, spaces, slashes, commas, periods, colons, question marks, equal signs, ampersands, backslashes, or hyphens are allowed.";
    }

    /*if (!preg_match("/^[a-zA-Z0-9 ]+$/", $pend_s2)) {
        $validation_errors[] = "Invalid value for pend_s2. Only letters, numbers, and spaces are allowed.";
    }

    if (!preg_match("/^[a-zA-Z0-9 ]*+$/", $pend_s3)) {
        $validation_errors[] = "Invalid value for pend_s3. Only letters, numbers, and spaces are allowed.";
    }

    if (!preg_match("/^[a-zA-Z ]+$/", $keilmuan)) {
        $validation_errors[] = "Invalid value for keilmuan. Only letters and spaces are allowed.";
    }*/

    // Check for any validation errors
    if (!empty($validation_errors)) {
        $_SESSION['xmessage'] = implode("<br>", $validation_errors);
        header("Location: /adm/edit-webprofile?epro=$uname");
        exit();
    }

    // Prepare and execute the SQL update statement
    $stmt = $conn->prepare("UPDATE adm_bkd SET 
                            uname = :uname,
                            nama_adm = :nama_adm,
                            almt_adm = :almt_adm,
                            nama_institusi = :nama_institusi,
                            akreditasi_pt = :akreditasi_pt,
                            telp_adm = :telp_adm,
                            wa_adm = :wa_adm,
                            web_adm = :web_adm,
                            fb_adm = :fb_adm,
                            insta_adm = :insta_adm,
                            yt_adm = :yt_adm,
                            web_pt = :web_pt
                            WHERE adm_id = :adm_id");

    $stmt->bindParam(':adm_id', $adm_id);
    $stmt->bindParam(':uname', $uname);
    $stmt->bindParam(':nama_adm', $nama_adm);
    $stmt->bindParam(':almt_adm', $almt_adm);
    $stmt->bindParam(':nama_institusi', $nama_institusi);
    $stmt->bindParam(':akreditasi_pt', $akreditasi_pt);
    $stmt->bindParam(':telp_adm', $telp_adm);
    $stmt->bindParam(':wa_adm', $wa_adm);
    $stmt->bindParam(':web_adm', $web_adm);
    $stmt->bindParam(':fb_adm', $fb_adm);
    $stmt->bindParam(':insta_adm', $insta_adm);
    $stmt->bindParam(':yt_adm', $yt_adm);
    $stmt->bindParam(':web_pt', $web_pt);

    if ($stmt->execute()) {
        // Update successful
        $_SESSION['message'] = "Profil sukses diperbarui.";
    } else {
        // Update failed
        $_SESSION['xmessage'] = "Profil gagal diperbarui.";
    }

    // Redirect to the profile page or any other appropriate page
    header("Location: /adm/edit-webprofile?epro=$uname");
    exit();
}

// If the form is not submitted, retrieve the user data for pre-filling the form
$user_id = $_SESSION['adm_id'];
$stmt = $conn->prepare("SELECT * FROM adm_bkd WHERE adm_id = :adm_id");
$stmt->bindParam(':adm_id', $adm_id);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // Other code for displaying the form with pre-filled data
    // HTML and Bootstrap code for the update form goes here
}
?>
