<?php require_once ("../includes/adm_header.php"); ?>
<?php require_once ("../includes/adm_sidebar.php"); ?>
<?php require_once ("../includes/adm_topbar.php"); ?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>     
     <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y small">
			
		<div class="row">
			<!-- main col -->
				<div class="col pb-5">
				<div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class=" fw-bold mb-0">EDIT FITUR DAN KONTEN </h5>
                    </div>
                    <div class="card-body">
                    <?php if(isset($_SESSION['message'])) : ?>
                        <h5 class="alert alert-success"><?= $_SESSION['message']; ?></h5>
                    <?php 
                        unset($_SESSION['message']);
                        endif; 
                    ?>
                    <?php if(isset($_SESSION['xmessage'])) : ?>
                        <h5 class="alert alert-danger"><?= $_SESSION['xmessage']; ?></h5>
                    <?php 
                        unset($_SESSION['xmessage']);
                        endif; 
                    ?>
                      <form action="upd_webkonten.php" method="POST">
                        <div class="row"></div>
                        <div class="mt-1 mb-3">
                          <label class="form-label" for="Tutorial">TUTORIAL PENGGUNAAN</label>
                            <textarea name="tutor_adm" class="form-control" id="Tutorial" placeholder="Masukkan artikel tutorial penggunaan BKD" aria-label="Tutorial BKD" aria-describedby="Tutorial1" value =""><?php echo $tutor_adm; ?></textarea>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="Maps">MAPS LOKASI KANTOR</label>
                              <div class="input-group input-group-merge">
                                    <span id="Maps1" class="input-group-text"><i class="ti ti-map-pin"></i></span>
                                    <input type="text" name="maps_adm" id="Maps" class="form-control form-control-lg" placeholder="Sematkan kode maps di sini" aria-label="Kode maps" aria-describedby="Maps1" value=""/>
                                </div>
                          <p class="fs-tiny mt-2"><?php echo $maps_adm; ?></p>
                        </div>
                        <div class="mt-4 mb-3">
                          <label class="form-label" for="teksKontak">TEKS KONTAK</label>
                          <div class="input-group input-group-merge">
                            <span id="teksKontak1" class="input-group-text"><i class="ti ti-files"></i></span>
                            <input type="text" name="context_adm" class="form-control" id="teksKontak" placeholder="Tulis keterangan untuk halaman kontak" aria-label="Alamat web unit" aria-describedby="teksKontak1" value ="<?php echo $context_adm; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="teksFooter">TEKS FOOTER</label>
                          <div class="input-group input-group-merge">
                            <span id="teksFooter1" class="input-group-text"><i class="ti ti-files"></i></span>
                            <input type="text" name="footext_adm" id="teksFooter" class="form-control" placeholder="Tulis teks footer web" aria-label="Alamat Facebook" aria-describedby="teksFooter1" value="<?php echo $footext_adm; ?>"/>
                          </div>
                        </div>
                        <button type="submit" class="btn btn-primary" id="button0a1b">SIMPAN</button>
                        <small class="text-danger float-end">JANGAN LUPA DISIMPAN</small>
                      </form>
                    </div>
                  </div>
				</div>
        </div>	
	</div>                   
 <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<?php
   $config = array();
   $config["apiKey"] = "s30tcw2ifbtad90un1rsoed2lj7jec8m85q4hlmt553re67r";
?>   
<script src="https://cloud.tinymce.com/6/tinymce.min.js?apiKey=<?php echo $config["apiKey"]; ?>"></script>
<script src="../assets/init.js"></script>
<script type="text/javascript">
  function getContent() {
    const getTinyMCEContents = tinymce.activeEditor.getContent();
    console.log(getTinyMCEContents);
  }

  var getRequest = document.getElementById('button0a1b')
  getRequest.addEventListener('click', getContent, false);
</script>

<!-- JavaScript code to populate maps in the input field -->
<script>
    // Get the input field
    var inputField = document.getElementById('Maps');

    // Assuming $maps_adm contains the HTML iframe code fetched from the database
    var maps_adm = '<?php echo addslashes($maps_adm); ?>';

    // Set the value of the input field to the entire iframe code
    inputField.value = maps_adm;
</script>


<?php require_once ("../includes/adm_footer.php"); ?>