<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
?>
<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['adm_id'])) {
    header("Location: /adm/index");
    exit();
}

require_once("../includes/Dtbase.php");

$db = new DatabaseConnection();
$conn = $db->getConnection();

// Get user information from the session
$adm_id = $_SESSION['adm_id'];
$nama_adm = $_SESSION['nama_adm'];
$uname = $_SESSION['uname'];

// Function to handle image deletion
function deleteImage($imageField, $uploadPath, $nameColumn)
{
    global $conn, $adm_id;

    // Validate database connection
    if (!$conn) {
        $_SESSION['xfmessage'] = "Database connection error.";
        return;
    }

    // Get image information from the database
    $stmtGetInfo = $conn->prepare("SELECT {$imageField}, {$nameColumn} FROM adm_bkd WHERE adm_id = ?");
    $stmtGetInfo->execute([$adm_id]);
    $imageInfo = $stmtGetInfo->fetch(PDO::FETCH_ASSOC);

    if (!$imageInfo || empty($imageInfo[$imageField])) {
        $_SESSION['xfmessage'] = "Image not found for deletion.";
        return;
    }

    // Delete image file from server
    $filePath = $imageInfo[$imageField];
    if (file_exists($filePath)) {
        unlink($filePath);
    }

    // Update database to remove image information
    $stmtUpdate = $conn->prepare("UPDATE adm_bkd SET {$imageField} = NULL, {$nameColumn} = NULL, revisi = CURRENT_TIMESTAMP WHERE adm_id = ?");
    $stmtUpdate->execute([$adm_id]);

    if ($stmtUpdate->rowCount() > 0) {
        $_SESSION['message'] = "Image deleted successfully.";
    } else {
        $_SESSION['xfmessage'] = "Failed to delete image from the database.";
    }
}

// Define image fields to delete
$imageFieldsToDelete = ['fotologo_url'];

foreach ($imageFieldsToDelete as $imageField) {
    // Define upload path for the image field
    $uploadPath = "uploads/" . date("Y/m/", time()) . $nama_adm . "/";

    // Call the deleteImage function for each image field
    deleteImage($imageField, $uploadPath, 'namafoto_logo'); // Assuming 'namafoto_logo' is the name column for both fields
    //deleteImage($imageField, $uploadPath, 'namafoto_index'); // Assuming 'namafoto_index' is the name column for both fields
}

header("Location: /adm/up-admimg?img=$uname");
exit();
?>




