<?php require_once ("../includes/adm_header.php"); ?>
<?php require_once ("../includes/adm_sidebar.php"); ?>
<?php require_once ("../includes/adm_topbar.php"); ?>
<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
?>

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y small">
        <div class="row">
          <div class="col">     
             <!-- Hour chart  -->
              <div class="card my-4 p-3 border-0">
                <div class="card-body row p-0 pb-0">
                  <div class="col-12 col-md-8 card-separator">
                    <?php if(isset($_SESSION['message'])) : ?>
                        <h5 class="alert alert-success"><?= $_SESSION['message']; ?></h5>
                    <?php 
                        unset($_SESSION['message']);
                        endif; 
                    ?>  
                    <h4>Selamat Datang, <?php
                        //session_start(); // Start the session
                        if (isset($_SESSION['isLoggedIn']) && $_SESSION['isLoggedIn'] == true) {
                            // User is logged in, display their name
                            echo " " . htmlspecialchars($_SESSION['nama_adm']) . "!";
                        } 
                        ?> 👋🏻</h4>
                    <div class="col-12 col-lg-7">
                      <p class="fs-6">Web-app Beban Kinerja Dosen memudahkan untuk mengelola laporan kinerja dosen dari institusi Anda!</p>
                    </div>
                    <div class="d-flex justify-content-between flex-wrap gap-3 me-5 mt-5">
                      <div class="d-flex align-items-center gap-2 me-4 me-sm-0">
                        <span class="bg-label-primary p-2 rounded">
                          <i class="ti ti-device-laptop ti-xl"></i>
                        </span>
                        <div class="content-right">
                          <p class="mb-0">RKBD Selesai</p>
                          <h4 class="text-primary mb-0">5 Entri</h4>
                        </div>
                      </div>
                      <div class="d-flex align-items-center gap-3">
                        <span class="bg-label-info p-2 rounded">
                          <i class="ti ti-bulb ti-xl"></i>
                        </span>
                        <div class="content-right">
                          <p class="mb-0">LKD Selesai</p>
                          <h4 class="text-info mb-0">4 Laporan</h4>
                        </div>
                      </div>
                      <div class="d-flex align-items-center gap-3">
                        <span class="bg-label-warning p-2 rounded">
                          <i class="ti ti-discount-check ti-xl"></i>
                        </span>
                        <div class="content-right">
                          <p class="mb-0">Kesimpulan Selesai</p>
                          <h4 class="text-warning mb-0">5 Kesimpulan</h4>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12 col-md-4 ps-md-2 ps-lg-3 pt-2 pt-md-0">
                    <h5 class="card-title mb-0">Statistik</h5>
                    <small class="text-muted">Laporan BKD dan LKD</small>
                      <div class="">
                        <canvas id="lineChart" class="chartjs" data-height="200"></canvas>
                      </div>
                  </div>
               </div>
              <!-- Hour chart End  -->
              </div>
         </div>
        
         <div class="row ps-3">    
          <div class="col-xl-5 col-lg-4 col-md-4 order-1 order-md-0">
           <!-- User Card -->
              <div class="card mb-4">
                <div class="card-body">
                  <div class="user-avatar-section">
                    <div class="d-flex align-items-center flex-column">
                        <div class="mb-3 pt-1 mt-4" style="width: 150px; height: 150px; overflow: hidden; position: relative;  border-radius: 15px;">
                            <?php
                            // Check if $fotologo_url is empty or null
                            if (!empty($fotologo_url)) {
                                // If $fotologo_url contains a valid image URL, display the user's image
                            ?>
                            <img src="/adm/<?php echo $fotologo_url; ?>" class="img-thumbnail" style="width: 150px; height: 150px; object-fit: cover; border-radius: 15px;">
                            <?php
                            } else {
                                // If $fotologo_url is empty or null, display a default image
                                ?>
                                <img src="/assets/img/avatars/1.png" class="img-thumbnail" style="width: 150px; height: 150px; object-fit: cover; border-radius: 15px;">
                                <?php
                            }
                            ?>
                        </div>
                      <div class="user-info text-center">
                        <h5 class="mb-2"><?php
                        //session_start();
                        if (isset($_SESSION['isLoggedIn']) && $_SESSION['isLoggedIn'] == true) {
                            // User is logged in, display their name
                            echo " " . htmlspecialchars($_SESSION['nama_adm']) . "";
                        } 
                        ?></h5>
                        <span class="badge bg-label-secondary mt-1 fs-5">Admin</span>
                      </div>
                    </div>
                  </div>
                  <div class="d-flex justify-content-around flex-wrap mt-1 pt-1 pb-4 border-bottom">
                    <div class="d-flex align-items-start me-4 mt-3 gap-2">
                      <span class="badge bg-label-primary p-2 rounded"><i class="ti ti-briefcase ti-sm"></i></span>
                      <div>
                        <p class="mb-0 fw-bold"><?php echo $nama_institusi; ?></p>
                        <small>Nama Institusi</small>
                      </div>
                    </div>
                    <div class="d-flex align-items-start mt-3 gap-1">
                      <span class="badge bg-label-primary p-2 rounded"><i class="ti ti-briefcase ti-sm"></i></span>
                      <div>
                        <p class="mb-0 fw-bold"><?php echo $akreditasi_pt; ?></p>
                        <small>Akreditasi PT</small>
                      </div>
                    </div>
                  </div>
                  <div class="info-container">
                      <p class="mt-4 small text-uppercase text-muted">INFO PENDUKUNG</p>
                      <div class="info-container">
                            <ul class="list-unstyled mb-4 mt-3">
                                <li class="d-flex align-items-center mb-2">
                                  <i class="ti ti-map-pin text-heading"></i><span class="fw-medium mx-2 text-heading">Alamat Kantor:</span> <span><?php echo $almt_adm; ?></span>
                                </li>
                            </ul>
                          <small class="card-text text-uppercase text-muted">Kontak</small>
                          <ul class="list-unstyled mb-4 mt-3">
                            <li class="d-flex align-items-center mb-2">
                              <i class="ti ti-phone-call"></i><span class="fw-medium mx-2 text-heading">No. Telephone:</span> <span>0<?php echo $telp_adm; ?></span>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <i class="ti ti-brand-whatsapp"></i><span class="fw-medium mx-2 text-heading">No. Whatsapp:</span> <span><a href="https://wa.me/62<?php echo $wa_adm; ?>">KLIK DISINI</a></span>
                            </li>
                            <li class="d-flex align-items-center mb-3">
                              <i class="ti ti-mail"></i><span class="fw-medium mx-2 text-heading">Email:</span> <span><?php echo $email_adm; ?></span>
                            </li>
                          </ul>
                          <small class="card-text text-uppercase text-muted">WEBSITE</small>
                          <ul class="list-unstyled mb-4 mt-3">
                            <li class="d-flex align-items-center mb-2">
                              <i class="ti ti-globe text-danger me-2"></i>
                              <div class="d-flex flex-wrap">
                                <span class="fw-medium me-2 text-heading"> Website Unit:</span><span><?php echo $web_adm; ?></span>
                              </div>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <i class="ti ti-globe text-danger me-2"></i>
                              <div class="d-flex flex-wrap">
                                <span class="fw-medium me-2 text-heading">Facebook:</span><span><?php echo $fb_adm; ?></span>
                              </div>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <i class="ti ti-globe text-danger me-2"></i>
                              <div class="d-flex flex-wrap">
                                <span class="fw-medium me-2 text-heading">Instagram:</span><span><?php echo $insta_adm; ?></span>
                              </div>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <i class="ti ti-globe text-danger me-2"></i>
                              <div class="d-flex flex-wrap">
                                <span class="fw-medium me-2 text-heading">Youtube:</span><span><?php echo $yt_adm; ?></span>
                              </div>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <i class="ti ti-globe text-danger me-2"></i>
                              <div class="d-flex flex-wrap">
                                <span class="fw-medium me-2 text-heading"> Website Institusi :</span><span><?php echo $web_pt; ?></span>
                              </div>
                            </li>
                          </ul>
                      </div>
                </div>
              </div>
              <!-- /User Card -->
           </div>
          </div>
          
         <div class="col-xl-7 col-lg-8 col-md-8 order-1 order-md-0 ps-3">
            <div class="row">    
            <!-- Announcements -->                    
                <div class="card">
                  <h5 class="card-header">Pengumuman</h5>
                  <div class="table-responsive text-nowrap">
                    <table class="table table-borderless">
                      <thead>
                        <tr>
                          <th>Date</th>
                          <th>Title</th>
                          <th>Content</th>
                          <th><i class="ti ti-settings"></i></th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td> <span class="fw-medium">Angular Project</span></td>
                          <td>Albert Cook</td>
                          <td><span class="badge bg-label-primary me-1">Active</span></td>
                          <td>
                            <div class="dropdown">
                              <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td> <span class="fw-medium">React Project</span></td>
                          <td>Barry Hunter</td>
                          <td><span class="badge bg-label-success me-1">Completed</span></td>
                          <td>
                            <div class="dropdown">
                              <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td> <span class="fw-medium">VueJs Project</span></td>
                          <td>Trevor Baker</td>
                          <td><span class="badge bg-label-info me-1">Scheduled</span></td>
                          <td>
                            <div class="dropdown">
                              <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td> <span class="fw-medium">Bootstrap Project</span></td>
                          <td>Jerry Milton</td>
                          <td><span class="badge bg-label-warning me-1">Pending</span></td>
                          <td>
                            <div class="dropdown">
                              <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                              </div>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                <!--/ Announcements -->                     
            </div>
            

            <div class="row pt-3">
              <!-- RBKD Entries -->
              <div class="card mb-4">
                <h5 class="card-header">RBKD Entries</h5>
                      <div class="table-responsive text-nowrap">
                        <table class="table">
                          <thead class="table-light">
                            <tr>
                              <th>Project</th>
                              <th>Client</th>
                              <th>Users</th>
                              <th><i class="ti ti-settings"></i></th>
                            </tr>
                          </thead>
                          <tbody class="table-border-bottom-0">
                            <tr>
                              <td> <span class="fw-medium">Angular Project</span></td>
                              <td>Albert Cook</td>
                              <td><span class="badge bg-label-primary me-1">Active</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td> <span class="fw-medium">React Project</span></td>
                              <td>Barry Hunter</td>
                              <td><span class="badge bg-label-success me-1">Completed</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td> <span class="fw-medium">VueJs Project</span></td>
                              <td>Trevor Baker</td>
                              <td><span class="badge bg-label-info me-1">Scheduled</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td> <span class="fw-medium">Bootstrap Project</span></td>
                              <td>Jerry Milton</td>
                              <td><span class="badge bg-label-warning me-1">Pending</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                  
                  
                  <hr>
                    <!-- LKD Entries -->                      
                    <h5 class="card-header">LKD Entries</h5>
                      <div class="table-responsive text-nowrap">
                        <table class="table">
                          <thead class="table-light">
                            <tr class="border rounded">
                              <th>Project</th>
                              <th>Client</th>
                              <th>Users</th>
                              <th><i class="ti ti-settings"></i></th>
                            </tr>
                          </thead>
                          <tbody class="table-border-bottom-0">
                            <tr>
                              <td> <span class="fw-medium">Angular Project</span></td>
                              <td>Albert Cook</td>
                              <td><span class="badge bg-label-primary me-1">Active</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td> <span class="fw-medium">React Project</span></td>
                              <td>Barry Hunter</td>
                              <td><span class="badge bg-label-success me-1">Completed</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td> <span class="fw-medium">VueJs Project</span></td>
                              <td>Trevor Baker</td>
                              <td><span class="badge bg-label-info me-1">Scheduled</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td> <span class="fw-medium">Bootstrap Project</span></td>
                              <td>Jerry Milton</td>
                              <td><span class="badge bg-label-warning me-1">Pending</span></td>
                              <td>
                                <div class="dropdown">
                                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="ti ti-dots-vertical"></i></button>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                    <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                </div>  
            </div>  
              <!--/ Entries -->
            </div>                
         </div>
        </div>
    </div>
    <!-- / Content -->


<?php require_once ("../includes/adm_footer.php"); ?>
