<?php
session_start();

// Include your database connection class
include('../includes/Dtbase.php');

// Instantiate the DatabaseConnection class
$databaseConnection = new DatabaseConnection();
$conn = $databaseConnection->getConnection();

// Retrieve data sent via POST request
$fak_id = $_POST['fak_id'];
$namafak = filter_input(INPUT_POST, 'namafak', FILTER_SANITIZE_STRING);
$nama_dekan = filter_input(INPUT_POST, 'nama_dekan', FILTER_SANITIZE_STRING);

// Validate form data
$validation_errors = [];

if (!preg_match("/^[a-zA-Z ]*+$/", $namafak)) {
    $validation_errors[] = "Invalid value for namafak. Only letters and spaces are allowed.";
}

if (!preg_match('/^[\p{L}0-9\s\/.,\-]*+$/u', $nama_dekan)) {
    $validation_errors[] = "Invalid value for nama_dekan. Only letters, numbers, spaces, slashes, commas, periods, and hyphens are allowed.";
}

// Check for any validation errors
if (!empty($validation_errors)) {
    $response = implode("<br>", $validation_errors);
    echo $response;
    exit();
}

// Prepare SQL statement
$sql = "UPDATE faculty SET namafak = :namafak, nama_dekan = :nama_dekan WHERE fak_id = :fak_id";

// Prepare and execute the statement
try {
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':namafak', $namafak);
    $stmt->bindParam(':nama_dekan', $nama_dekan);
    $stmt->bindParam(':fak_id', $fak_id);
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
        echo "Row updated successfully for fak_id: " . $fak_id;
    } else {
        echo "No rows updated for fak_id: " . $fak_id;
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
