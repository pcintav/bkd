<?php require_once ("../includes/adm_header.php"); ?>
<?php require_once ("../includes/adm_sidebar.php"); ?>
<?php require_once ("../includes/adm_topbar.php"); ?>


        <!-- Content -->

        <div class="container-xxl flex-grow-1 container-p-y">
          <div class="row">    
           <div class="col-xl-6 col-lg-5 col-md-5 order-1 order-md-0">
            <div class="card mb-4">  
             <div class="card-body">
             <h4 class="mb-1 pt-2">Ubah Password 🔒</h4>
              <p class="mb-4">untuk <span class="fw-medium"><?php echo $nama_adm; ?></span></p>
                  <form id="formAuthentication" action="auth-login-basic.html" method="GET">
                    <div class="mb-3 form-password-toggle">
                      <label class="form-label" for="password">Password Baru</label>
                      <div class="input-group input-group-merge">
                        <input type="password" id="password" class="form-control" name="password" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" aria-describedby="password" />
                        <span class="input-group-text cursor-pointer"><i class="ti ti-eye-off"></i></span>
                      </div>
                    </div>
                    <div class="mb-3 form-password-toggle">
                      <label class="form-label" for="confirm-password">Konfirmasi  Password</label>
                      <div class="input-group input-group-merge">
                        <input type="password" id="confirm-password" class="form-control" name="confirm-password" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" aria-describedby="password" />
                        <span class="input-group-text cursor-pointer"><i class="ti ti-eye-off"></i></span>
                      </div>
                    </div>
                    <button class="btn btn-primary d-grid w-100 mb-3">Perbarui Password</button>
                  </form>     
             </div>                     
            </div>
           </div>
           <div class="col-xl-6 col-lg-5 col-md-5 order-2 order-md-0">
            <div class="card mb-4">  
             <div class="card-body">
             <h4 class="mb-1 pt-2">Ubah Email 🔒</h4>
              <p class="mb-4">untuk <span class="fw-medium"><?php echo $email_adm; ?></span></p>
                  <form id="formAuthentication" action="" method="GET">
                    <div class="mb-3 form-password-toggle">
                      <label class="form-label" for="Email">Email</label>
                      <div class="input-group input-group-merge">
                        <input type="email" id="Email" class="form-control" name="password" placeholder="Tulis email baru di sini" aria-describedby="email" />
                        <span class="input-group-text cursor-pointer"><i class="ti ti-mail"></i></span>
                      </div>
                    </div>
                    <button class="btn btn-primary d-grid w-100 mb-3">Perbarui Email</button>
                  </form>             
             </div>          
            </div>          
           </div>
          </div>
        </div>
        <!-- / Content -->



<?php require_once ("../includes/adm_footer.php"); ?>