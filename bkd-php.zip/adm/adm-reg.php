<?php session_start(); ?>
<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-wide customizer-hide"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>Daftar Admin BKD LKD</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&ampdisplay=swap" rel="stylesheet" />

    <!-- Icons -->
    <link rel="stylesheet" href="../assets/vendor/fonts/fontawesome.css" />
    <link rel="stylesheet" href="../assets/vendor/fonts/tabler-icons.css" />
    <link rel="stylesheet" href="../assets/vendor/fonts/flag-icons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="../assets/vendor/css/rtl/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../assets/vendor/css/rtl/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../assets/css/demo.css" />

    <!-- Vendors CSS -->

    <!-- Vendor -->

    <!-- Page CSS -->
    <!-- Page -->
    <link rel="stylesheet" href="../assets/vendor/css/pages/page-auth.css" />

    <!-- Helpers -->
    <script src="../assets/vendor/js/helpers.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script> 
    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Template customizer: To hide customizer set displayCustomizer value false in config.js.  -->
    <script src="../assets/vendor/js/template-customizer.js"></script>
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="../assets/js/config.js"></script>
  </head>

  <body>
    
    <!-- Content -->
        
    <div class="container-xxl flex-grow-1 container-p-y small">
        <div class="row">
            <div class="col">     
                <div class="card my-4 p-3 border-0">
                    <div class="card-body row p-0 pb-0">
                    <h1 class="text-danger">Form Daftar Admin BKD!</h1>
                    <h5 class="text-primary mt-0 px-3">Isi Formulir Dengan Lengkap</h5>
                    <?php if(isset($_SESSION['xmessage'])) : ?>
                        <h5 class="alert alert-danger"><?= $_SESSION['xmessage']; ?></h5>
                    <?php 
                        unset($_SESSION['xmessage']);
                        endif; 
                    ?>
                    <?php if(isset($_SESSION['message'])) : ?>
                        <h5 class="alert alert-success"><?= $_SESSION['message']; ?></h5>
                    <?php 
                        unset($_SESSION['message']);
                        endif; 
                    ?>
                     <form class="needs-validation" action="<?php print '/adm/adm_act'; ?>" method="POST">
                        <p>
                           <label for="Username">Username:</label>
                           <input type="text" class="form-control" name="uname" id="Username">
                        </p>
                        <p>
                           <label for="Nama">Nama Lengkap:</label>
                           <input type="text" class="form-control" name="nama" id="Nama">
                        </p>
                        <p>
                           <label for="Email">Email:</label>
                           <input type="email" class="form-control" name="email" id="Email">
                        </p>
                        <p>
                           <label for="Password">Password:</label>
                           <input type="password" class="form-control" name="passwd" id="Password">
                        </p>
                        <p>
                        <div class="g-recaptcha" data-sitekey="6Lfpp1UpAAAAACOSeZW76ucDDqAgasDC9LQOfUyx"></div>
                        </p>
                        <button type="submit" name="daftar" class="btn btn-primary" id="btnSubmit">Daftar</button>
                     </form>

                    </div>
                </div>
            </div>  
        </div>    
    </div>
    <!-- Content -->


<script></script>
    <!-- / Content -->

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->

    <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/hammer/hammer.js"></script>
    

    <!-- endbuild -->

    <!-- Vendors JS -->
    <!-- <script src="../assets/vendor/libs/@form-validation/umd/bundle/popular.min.js"></script>
    <script src="../assets/vendor/libs/@form-validation/umd/plugin-bootstrap5/index.min.js"></script>
    <script src="../assets/vendor/libs/@form-validation/umd/plugin-auto-focus/index.min.js"></script> -->

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="../assets/js/pages-auth.js"></script>
  </body>
</html>