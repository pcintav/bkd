<?php
session_start();

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

// Redirect to login if not logged in
if (!isset($_SESSION['adm_id'])) {
    header("Location: /adm/index");
    exit();
}

require_once("../includes/Dtbase.php");

$db = new DatabaseConnection();
$conn = $db->getConnection();

// Get user information from the session
$adm_id = $_SESSION['adm_id'];
$nama_adm = $_SESSION['nama_adm'];
$uname = $_SESSION['uname'];

// Function to handle file upload
function handleFileUpload($fileField, $allowedTypes, $maxSize, $uploadPath, $urlColumn, $nameColumn)
{
    global $conn, $adm_id;

    // Validate database connection
    if (!$conn) {
        $_SESSION['xfmessage'] = "Database connection error.";
        return false;
    }

    // Validate if the file is selected
    if (!isset($_FILES[$fileField]['name']) || empty($_FILES[$fileField]['name'])) {
        return true; // No file selected, continue processing other fields
    }

    $fileType = $_FILES[$fileField]['type'];

    // Validate file type
    if (!in_array($fileType, $allowedTypes)) {
        $_SESSION['xfmessage'] = "File harus berupa PDF atau JPG untuk " . $fileField;
        return false;
    }

    // Validate file size
    $fileSize = $_FILES[$fileField]['size'];
    if ($fileSize > $maxSize) {
        $_SESSION['xfmessage'] = "File lebih dari 4MB untuk " . $fileField;
        return false;
    }

    // Check if the file with the same name already exists in the database
    $stmtCheckName = $conn->prepare("SELECT {$nameColumn} FROM adm_bkd WHERE {$nameColumn} = ?");
    $stmtCheckName->execute([$_FILES[$fileField]['name']]);
    $existingName = $stmtCheckName->fetchColumn();

    if ($existingName) {
        $_SESSION['xfmessage'] = "File dengan nama yang sama sudah ada untuk " . $fileField;
        return false;
    }

    // Create upload directory if not exists
    if (!file_exists($uploadPath)) {
        mkdir($uploadPath, 0777, true);
    }

    // Move uploaded file to destination folder
    $uploadedFile = $uploadPath . basename($_FILES[$fileField]['name']);

    if (move_uploaded_file($_FILES[$fileField]['tmp_name'], $uploadedFile)) {
        // Update database with file information
        $stmtUpdate = $conn->prepare("UPDATE adm_bkd SET {$urlColumn} = ?, {$nameColumn} = ?, revisi = CURRENT_TIMESTAMP WHERE adm_id = ?");
        $stmtUpdate->execute([$uploadedFile, $_FILES[$fileField]['name'], $adm_id]);

        if ($stmtUpdate->rowCount() > 0) {
            $_SESSION['message'] = "Sukses Diupload untuk " . $fileField;
        } else {
            $_SESSION['xfmessage'] = "Gagal menyimpan informasi file di database untuk " . $fileField;
        }
    } else {
        $_SESSION['xfmessage'] = "Gagal Diupload untuk " . $fileField;
    }

    return true;
}

// Define upload path and columns for each file field
$uploadPaths = [
    'guide_url' => "uploads/" . date("Y/m/", time()) . $nama_adm . "/",
    'logopanjang_url' => "uploads/" . date("Y/m/", time()) . $nama_adm . "/",
    'dokumen1_url' => "uploads/" . date("Y/m/", time()) . $nama_adm . "/",
];

$columns = [
    'guide_url' => 'guide_name',
    'logopanjang_url' => 'logopanjang_name',
    'dokumen1_url' => 'dokumen1_name',
];

// Handle file upload for each file field
foreach ($uploadPaths as $urlColumn => $uploadPath) {
    handleFileUpload($urlColumn, ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg'], 4096 * 4096, $uploadPath, $urlColumn, $columns[$urlColumn]);
}

// Redirect back to the HTML form page
$_SESSION['message'] = "Files uploaded successfully.";
header("Location: /adm/up-admimg?img=$uname");
exit();
?>
