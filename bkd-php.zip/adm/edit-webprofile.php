<?php require_once ("../includes/adm_header.php"); ?>
<?php require_once ("../includes/adm_sidebar.php"); ?>
<?php require_once ("../includes/adm_topbar.php"); ?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>     
     <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y small">
			
		<div class="row">
			<!-- main col -->
				<div class="col pb-5">
				<div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Edit Informasi Unit dan Institusi</h5>
                    </div>
                    <div class="card-body">
                    <?php if(isset($_SESSION['message'])) : ?>
                        <h5 class="alert alert-success"><?= $_SESSION['message']; ?></h5>
                    <?php 
                        unset($_SESSION['message']);
                        endif; 
                    ?>
                    <?php if(isset($_SESSION['xmessage'])) : ?>
                        <h5 class="alert alert-danger"><?= $_SESSION['xmessage']; ?></h5>
                    <?php 
                        unset($_SESSION['xmessage']);
                        endif; 
                    ?>
                      <form action="upd_webprofile.php" method="POST">
                        <div class="row"></div>
                        <div class="mt-4 mb-3">
                          <label class="form-label" for="Username">Username</label>
                          <div class="input-group input-group-merge">
                            <span id="Username1" class="input-group-text"><i class="ti ti-user"></i></span>
                            <input type="text" name="uname" class="form-control" id="Username" placeholder="Tulis username kombinasi angka dan huruf saja" aria-label="Nama pengguna" aria-describedby="Username1" value ="<?php echo $uname; ?>"/>
                          </div>
                        </div>
                        <div class="mt-4 mb-3">
                          <label class="form-label" for="Nama">Nama Unit</label>
                          <div class="input-group input-group-merge">
                            <span id="Nama1" class="input-group-text"><i class="ti ti-user"></i></span>
                            <input type="text" name="nama_adm" class="form-control" id="Nama" placeholder="Tulis nama unit" aria-label="Nama unit" aria-describedby="Nama1" value ="<?php echo $nama_adm; ?>"/>
                          </div>
                        </div>
                        <div class="mt-4 mb-3">
                          <label class="form-label" for="NamaInstitusi">Nama Institusi</label>
                          <div class="input-group input-group-merge">
                            <span id="NamaInstitusi1" class="input-group-text"><i class="ti ti-user"></i></span>
                            <input type="text" name="nama_institusi" class="form-control" id="NamaInstitusi" placeholder="Tulis nama institusi" aria-label="Nama Institusi" aria-describedby="NamaInstitusi1" value ="<?php echo $nama_institusi; ?>"/>
                          </div>
                        </div>
                        <div class="mt-4 mb-3">
                          <label class="form-label" for="AkreditasiPt">Akreditasi PT</label>
                          <div class="input-group input-group-merge">
                            <span id="AkreditasiPt1" class="input-group-text"><i class="ti ti-user"></i></span>
                            <input type="text" name="akreditasi_pt" class="form-control" id="AkreditasiPt" placeholder="Tulis akreditasi BAN-PT" aria-label="Akreditasi PT" aria-describedby="AkreditasiPt1" value ="<?php echo $akreditasi_pt; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="Alamat">Alamat Unit</label>
                          <div class="input-group input-group-merge">
                            <span id="Alamat1" class="input-group-text"><i class="ti ti-map-pin"></i></span>
                            <input type="text" name="almt_adm" id="Alamat" class="form-control" placeholder="Tulis alamat lengkap kantor" aria-label="Alamat Lengkap" aria-describedby="Alamat1" value="<?php echo $almt_adm; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="noTelp">No. Telephone</label>
                          <div class="input-group input-group-merge">
                            <span id="noTelp1" class="input-group-text"><i class="ti ti-phone"></i></span>
                            <input type="number" name="telp_adm" id="noTelp" class="form-control phone-mask" placeholder="082122223333" aria-label="082122223333" aria-describedby="noTelp1" value="<?php echo $telp_adm; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="noWa">No. Whatsapp</label>
                          <div class="input-group input-group-merge">
                            <span id="noWa1" class="input-group-text"><i class="ti ti-brand-whatsapp"></i></span>
                            <input type="number" name="wa_adm" id="noWa" class="form-control phone-mask" placeholder="082133334444" aria-label="082133334444" aria-describedby="noWa1" value="<?php echo $wa_adm; ?>"/>
                          </div>
                        </div>
                        <hr class="my-4 mx-n4" />
                        <div class="mt-4 mb-3">
                          <label class="form-label" for="webUnit">Website Unit</label>
                          <div class="input-group input-group-merge">
                            <span id="webUnit1" class="input-group-text"><i class="ti ti-globe"></i></span>
                            <input type="text" name="web_adm" class="form-control" id="webUnit" placeholder="Tulis alamat web unit" aria-label="Alamat web unit" aria-describedby="webUnit1" value ="<?php echo $web_adm; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="Facebook">Facebook</label>
                          <div class="input-group input-group-merge">
                            <span id="Facebook1" class="input-group-text"><i class="ti ti-brand-facebook"></i></span>
                            <input type="text" name="fb_adm" id="Facebook" class="form-control" placeholder="Tulis alamat Facebook" aria-label="Alamat Facebook" aria-describedby="Facebook1" value="<?php echo $fb_adm; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="Instagram">Instagram</label>
                          <div class="input-group input-group-merge">
                            <span id="Instagram1" class="input-group-text"><i class="ti ti-brand-instagram"></i></span>
                            <input type="text" name="insta_adm" id="Instagram" class="form-control" placeholder="Tulis alamat Instagram" aria-label="Alamat Instagram" aria-describedby="Instagram1" value="<?php echo $insta_adm; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="Youtube">Youtube</label>
                          <div class="input-group input-group-merge">
                            <span id="Youtube1" class="input-group-text"><i class="ti ti-brand-youtube"></i></span>
                            <input type="text" name="yt_adm" id="Youtube" class="form-control" placeholder="Tulis alamat Youtube" aria-label="Alamat Youtube" aria-describedby="Youtube1" value="<?php echo $yt_adm; ?>"/>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="webPt">Website Institusi</label>
                          <div class="input-group input-group-merge">
                            <span id="webPt1" class="input-group-text"><i class="ti ti-globe"></i></span>
                            <input type="text" name="web_pt" id="webPt" class="form-control" placeholder="Tulis alamat web institusi" aria-label="Alamat web PT" aria-describedby="webPt1" value="<?php echo $web_pt; ?>"/>
                          </div>
                        </div>
                        <hr class="my-4 mx-n4" />
                        
                        <div class="mb-3">
                          <label class="form-label" for="">TANGGAL DAFTAR: <?php echo $tgl_dftr; ?></label>
                        </div>  
                        <button type="submit" class="btn btn-primary">SIMPAN</button>
                        <small class="text-danger float-end">JANGAN LUPA DISIMPAN</small>
                      </form>
                    </div>
                  </div>
				</div>
        </div>	
	</div>                   


<?php require_once ("../includes/adm_footer.php"); ?>