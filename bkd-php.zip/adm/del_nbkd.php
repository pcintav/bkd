<?php
session_start();
include('../includes/Dtbase.php'); // Include your database connection file

// Get the admin session
$uname = $_SESSION['uname'] ?? '';
$adm_id = $_SESSION['adm_id'] ?? '';

// Check if the user is authorized (e.g., admin)
if (!isset($_SESSION['adm_id'])) {
    // Redirect unauthorized users to a login page or display an error message
    $_SESSION['xmessage'] = "Unauthorized access.";
    header("Location: /adm/index");
    exit();
}

// Instantiate the DatabaseConnection class
$databaseConnection = new DatabaseConnection();
$conn = $databaseConnection->getConnection();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['del_nbkd'])) {
    $rep_id = $_POST['del_nbkd'];

    try {
        // Prepare the DELETE query
        $query = "DELETE FROM bkd_reports WHERE rep_id = :rep_id";

        $statement = $conn->prepare($query);

        if (!$statement) {
            $_SESSION['xmessage'] = "Persiapan eksekusi gagal.";
            header("Location: /adm/list-rbkd?bkdr=$uname");
            exit();
        }

        // Bind parameters and execute the statement
        $statement->bindParam(':rep_id', $rep_id, PDO::PARAM_INT);
        $query_execute = $statement->execute();

        if ($query_execute) {
            $_SESSION['message'] = "Data berhasil dihapus.";
        } else {
            $_SESSION['xmessage'] = "Data gagal dihapus.";
        }
    } catch (PDOException $e) {
        // Log the detailed error message
        error_log("PDOException: " . $e->getMessage());

        // Display a user-friendly error message on the page
        $_SESSION['xmessage'] = "Terjadi error yang tidak diharapkan.";
        header("Location: /adm/list-rbkd?bkdr=$uname");
        exit();
    }
}

// Redirect to the specified URL
header("Location: /adm/list-rbkd?bkdr=$uname");
exit();
?>
