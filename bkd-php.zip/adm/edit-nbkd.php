<?php require_once ("../includes/adm_header.php"); ?>
<?php require_once ("../includes/adm_sidebar.php"); ?>
<?php require_once ("../includes/adm_topbar.php"); ?>
<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
?>

    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y small">
     <div class="row">    
      <div class="col">
         <?php
                // Initialize datas from database
                $anpdbkd1 = $appdbkd1 = $skspdbkd1 = $smtpdbkd1 = $docpdbkd1a = $docpdbkd1b = $docpdbkd1c = $anpdbkd2 = $appdbkd2 = $skspdbkd2 = $smtpdbkd2 = $docpdbkd2a = $docpdbkd2b = $docpdbkd2c = $anpdbkd3 = $appdbkd3 = $skspdbkd3 = $smtpdbkd3 = $docpdbkd3a = $docpdbkd3b = $docpdbkd3c = $anpdbkd4 = $appdbkd4 = $skspdbkd4 = $smtpdbkd4 = $docpdbkd4a = $docpdbkd4b = $docpdbkd4c = $anpdbkd5 = $appdbkd5 = $skspdbkd5 = $smtpdbkd5 = $docpdbkd5a = $docpdbkd5b = $docpdbkd5c = $anpdbkd6 = $appdbkd6 = $skspdbkd6 = $smtpdbkd6 = $docpdbkd6a = $docpdbkd6b = $docpdbkd6c = $anpdbkd7 = $appdbkd7 = $skspdbkd7 = $smtpdbkd7 = $docpdbkd7a = $docpdbkd7b = $docpdbkd7c = $anpdbkd8 = $appdbkd8 = $skspdbkd8 = $smtpdbkd8 = $docpdbkd8a = $docpdbkd8b = $docpdbkd8c = $anplbkd1 = $applbkd1 = $sksplbkd1 = $smtplbkd1 = $docplbkd1a = $docplbkd1b = $docplbkd1c = $anplbkd2 = $applbkd2 = $sksplbkd2 = $smtplbkd2 = $docplbkd2a = $docplbkd2b = $docplbkd2c = $anplbkd3 = $applbkd3 = $sksplbkd3 = $smtplbkd3 = $docplbkd3a = $docplbkd3b = $docplbkd3c = $anplbkd4 = $applbkd4 = $sksplbkd4 = $smtplbkd4 = $docplbkd4a = $docplbkd4b = $docplbkd4c = $anpgbkd1 = $appgbkd1 = $skspgbkd1 = $smtpgbkd1 = $docpgbkd1a = $docpgbkd1b = $docpgbkd1c = $anpgbkd2 = $appgbkd2 = $skspgbkd2 = $smtpgbkd2 = $docpgbkd2a = $docpgbkd2b = $docpgbkd2c = $anpgbkd3 = $appgbkd3 = $skspgbkd3 = $smtpgbkd3 = $docpgbkd3a = $docpgbkd3b = $docpgbkd3c = $anpgbkd4 = $appgbkd4 = $skspgbkd4 = $smtpgbkd4 = $docpgbkd4a = $docpgbkd4b = $docpgbkd4c = $anpjbkd1 = $appjbkd1 = $skspjbkd1 = $smtpjbkd1 = $docpjbkd1a = $docpjbkd1b = $docpjbkd1c = $anpjbkd2 = $appjbkd2 = $skspjbkd2 = $smtpjbkd2 = $docpjbkd2a = $docpjbkd2b = $docpjbkd2c = $anpjbkd3 = $appjbkd3 = $skspjbkd3 = $smtpjbkd3 = $docpjbkd3a = $docpjbkd3b = $docpjbkd3c = $anpjbkd4 = $appjbkd4 = $skspjbkd4 = $smtpjbkd4 = $docpjbkd4a = $docpjbkd4b = $docpjbkd4c = '';
                
                // Fetch datas from the database based on rep_id
                if ($conn) {
                // Check if the 'edn' parameter is set in the URL
                if(isset($_GET['edn'])) {
                    // Retrieve the 'edn' parameter value (rep_id) from the URL
                    $rep_id = $_GET['edn'];
            
                    try {
                        // Prepare SQL query to select data based on rep_id
                        $stmt = $conn->prepare("SELECT * FROM bkd_reports WHERE rep_id = :rep_id LIMIT 1");
                        $stmt->bindParam(':rep_id', $rep_id);
                        $stmt->execute();
            
                        // Check if at least one row is found
                        if ($stmt->rowCount() > 0) {
                            // Fetch the first row and store it in $row for further processing
                            $row = $stmt->fetch(PDO::FETCH_ASSOC);
                            $nama = $row['nama'];
                            $nidn = $row['nidn'];
                            $tahun = $row['tahun'];
                            $semester = $row['semester'];
                            
                            $anpdbkd1 = $row['anpdbkd1'];
                            $appdbkd1 = $row['appdbkd1'];
                            $skspdbkd1 = $row['skspdbkd1'];
                            $smtpdbkd1 = $row['smtpdbkd1'];
                            $docpdbkd1a = $row['docpdbkd1a'];
                            $docpdbkd1b = $row['docpdbkd1b'];
                            $docpdbkd1c = $row['docpdbkd1c'];
                            
                            $anpdbkd2 = $row['anpdbkd2'];
                            $appdbkd2 = $row['appdbkd2'];
                            $skspdbkd2 = $row['skspdbkd2'];
                            $smtpdbkd2 = $row['smtpdbkd2'];
                            $docpdbkd2a = $row['docpdbkd2a'];
                            $docpdbkd2b = $row['docpdbkd2b'];
                            $docpdbkd2c = $row['docpdbkd2c'];
                            
                            $anpdbkd3 = $row['anpdbkd3'];
                            $appdbkd3 = $row['appdbkd3'];
                            $skspdbkd3 = $row['skspdbkd3'];
                            $smtpdbkd3 = $row['smtpdbkd3'];
                            $docpdbkd3a = $row['docpdbkd3a'];
                            $docpdbkd3b = $row['docpdbkd3b'];
                            $docpdbkd3c = $row['docpdbkd3c'];
                            
                            $anpdbkd4 = $row['anpdbkd4'];
                            $appdbkd4 = $row['appdbkd4'];
                            $skspdbkd4 = $row['skspdbkd4'];
                            $smtpdbkd4 = $row['smtpdbkd4'];
                            $docpdbkd4a = $row['docpdbkd4a'];
                            $docpdbkd4b = $row['docpdbkd4b'];
                            $docpdbkd4c = $row['docpdbkd4c'];
                            
                            $anpdbkd5 = $row['anpdbkd5'];
                            $appdbkd5 = $row['appdbkd5'];
                            $skspdbkd5 = $row['skspdbkd5'];
                            $smtpdbkd5 = $row['smtpdbkd5'];
                            $docpdbkd5a = $row['docpdbkd5a'];
                            $docpdbkd5b = $row['docpdbkd5b'];
                            $docpdbkd5c = $row['docpdbkd5c'];
                            
                            $anpdbkd6 = $row['anpdbkd6'];
                            $appdbkd6 = $row['appdbkd6'];
                            $skspdbkd6 = $row['skspdbkd6'];
                            $smtpdbkd6 = $row['smtpdbkd6'];
                            $docpdbkd6a = $row['docpdbkd6a'];
                            $docpdbkd6b = $row['docpdbkd6b'];
                            $docpdbkd6c = $row['docpdbkd6c'];
                            
                            $anpdbkd7 = $row['anpdbkd7'];
                            $appdbkd7 = $row['appdbkd7'];
                            $skspdbkd7 = $row['skspdbkd7'];
                            $smtpdbkd7 = $row['smtpdbkd7'];
                            $docpdbkd7a = $row['docpdbkd7a'];
                            $docpdbkd7b = $row['docpdbkd7a'];
                            $docpdbkd7c = $row['docpdbkd7c'];
                            
                            $anpdbkd8 = $row['anpdbkd8'];
                            $appdbkd8 = $row['appdbkd8'];
                            $skspdbkd8 = $row['skspdbkd8'];
                            $smtpdbkd8 = $row['smtpdbkd8'];
                            $docpdbkd8a = $row['docpdbkd8a'];
                            $docpdbkd8b = $row['docpdbkd8b'];
                            $docpdbkd8c = $row['docpdbkd8c'];
                            
                            $anplbkd1 = $row['anplbkd1'];
                            $applbkd1 = $row['applbkd1'];
                            $sksplbkd1 = $row['sksplbkd1'];
                            $smtplbkd1 = $row['smtplbkd1'];
                            $docplbkd1a = $row['docplbkd1a'];
                            $docplbkd1b = $row['docplbkd1b'];
                            $docplbkd1c = $row['docplbkd1c'];
                            
                            $anplbkd2 = $row['anplbkd2'];
                            $applbkd2 = $row['applbkd2'];
                            $sksplbkd2 = $row['sksplbkd2'];
                            $smtplbkd2 = $row['smtplbkd2'];
                            $docplbkd2a = $row['docplbkd2a'];
                            $docplbkd2b = $row['docplbkd2b'];
                            $docplbkd2c = $row['docplbkd2c'];
                            
                            $anplbkd3 = $row['anplbkd3'];
                            $applbkd3 = $row['applbkd3'];
                            $sksplbkd3 = $row['sksplbkd3'];
                            $smtplbkd3 = $row['smtplbkd3'];
                            $docplbkd3a = $row['docplbkd3a'];
                            $docplbkd3b = $row['docplbkd3b'];
                            $docplbkd3c = $row['docplbkd3c'];
                            
                            $anplbkd4 = $row['anplbkd4'];
                            $applbkd4 = $row['applbkd4'];
                            $sksplbkd4 = $row['sksplbkd4'];
                            $smtplbkd4 = $row['smtplbkd4'];
                            $docplbkd4a = $row['docplbkd4a'];
                            $docplbkd4b = $row['docplbkd4b'];
                            $docplbkd4c = $row['docplbkd4c'];
                            
                            $anpgbkd1 = $row['anpgbkd1'];
                            $appgbkd1 = $row['appgbkd1'];
                            $skspgbkd1 = $row['skspgbkd1'];
                            $smtpgbkd1 = $row['smtpgbkd1'];
                            $docpgbkd1a = $row['docpgbkd1a'];
                            $docpgbkd1b = $row['docpgbkd1b'];
                            $docpgbkd1c = $row['docpgbkd1c'];
                            
                            $anpgbkd2 = $row['anpgbkd2'];
                            $appgbkd2 = $row['appgbkd2'];
                            $skspgbkd2 = $row['skspgbkd2'];
                            $smtpgbkd2 = $row['smtpgbkd2'];
                            $docpgbkd2a = $row['docpgbkd2a'];
                            $docpgbkd2b = $row['docpgbkd2b'];
                            $docpgbkd2c = $row['docpgbkd2c'];
                            
                            $anpgbkd3 = $row['anpgbkd3'];
                            $appgbkd3 = $row['appgbkd3'];
                            $skspgbkd3 = $row['skspgbkd3'];
                            $smtpgbkd3 = $row['smtpgbkd3'];
                            $docpgbkd3a = $row['docpgbkd3a'];
                            $docpgbkd3b = $row['docpgbkd3b'];
                            $docpgbkd3c = $row['docpgbkd3c'];
                            
                            $anpgbkd4 = $row['anpgbkd4'];
                            $appgbkd4 = $row['appgbkd4'];
                            $skspgbkd4 = $row['skspgbkd4'];
                            $smtpgbkd4 = $row['smtpgbkd4'];
                            $docpgbkd4a = $row['docpgbkd4a'];
                            $docpgbkd4b = $row['docpgbkd4b'];
                            $docpgbkd4c = $row['docpgbkd4c'];
                            
                            $anpjbkd1 = $row['anpjbkd1'];
                            $appjbkd1 = $row['appjbkd1'];
                            $skspjbkd1 = $row['skspjbkd1'];
                            $smtpjbkd1 = $row['smtpjbkd1'];
                            $docpjbkd1a = $row['docpjbkd1a'];
                            $docpjbkd1b = $row['docpjbkd1b'];
                            $docpjbkd1c = $row['docpjbkd1c'];
                            
                            $anpjbkd2 = $row['anpjbkd2'];
                            $appjbkd2 = $row['appjbkd2'];
                            $skspjbkd2 = $row['skspjbkd2'];
                            $smtpjbkd2 = $row['smtpjbkd2'];
                            $docpjbkd2a = $row['docpjbkd2a'];
                            $docpjbkd2b = $row['docpjbkd2b'];
                            $docpjbkd2c = $row['docpjbkd2c'];
                            
                            $anpjbkd3 = $row['anpjbkd3'];
                            $appjbkd3 = $row['appjbkd3'];
                            $skspjbkd3 = $row['skspjbkd3'];
                            $smtpjbkd3 = $row['smtpjbkd3'];
                            $docpjbkd3a = $row['docpjbkd3a'];
                            $docpjbkd3b = $row['docpjbkd3b'];
                            $docpjbkd3c = $row['docpjbkd3c'];
                            
                            $anpjbkd4 = $row['anpjbkd4'];
                            $appjbkd4 = $row['appjbkd4'];
                            $skspjbkd4 = $row['skspjbkd4'];
                            $smtpjbkd4 = $row['smtpjbkd4'];
                            $docpjbkd4a = $row['docpjbkd4a'];
                            $docpjbkd4b = $row['docpjbkd4b'];
                            $docpjbkd4c = $row['docpjbkd4c'];
                            //$tgl_daftar = date('Y-m-d', strtotime($row['tgl_daftar']));
                                                    
                        } else {
                            // Handle the case when no records are found
                            echo "<p>No records found for the specified user_id.</p>";
                        }
                    } catch (PDOException $e) {
                        // Handle PDO exceptions
                        echo "<p>Error: " . $e->getMessage() . "</p>";
                    }
                } else {
                    // Handle the case when the database connection fails
                    echo "<p>Error: Database connection failed.</p>";
                }
                    
                }
                ?>
                
                <?php
                // Include your database connection class
                //require_once('./../includes/Dtbase.php');
                
                // Instantiate the DatabaseConnection class
                //$databaseConnection = new DatabaseConnection();
                //$conn = $databaseConnection->getConnection();
                
                // Query to fetch data from thn_akademik table
                $query = "SELECT tahun FROM thn_akademik";
                
                try {
                    // Prepare and execute the query
                    $statement = $conn->prepare($query);
                    $statement->execute();
                
                    // Fetch all tahun records
                    $tahun_records = $statement->fetchAll(PDO::FETCH_ASSOC);
                } catch (PDOException $e) {
                    die("Error fetching tahun records: " . $e->getMessage());
                }
                ?> 
         <div class="card mb-3">
          <div class="card-body">
              <span class="text-primary fs-6 muted">Hai <?php echo " " . htmlspecialchars($_SESSION['nama_adm']) . "!"; ?></span><br>
              <span class="mb-2 text-danger">Anda sedang merubah RBKD <?php echo $nama; ?> <?php echo $nidn; ?></span><br><span>Pastikan menyimpan perubahan sekecil apapun, dengan menekan tombol SIMPAN.</span>
                <?php if(isset($_SESSION['xmessage'])) : ?>
                <h6 class="alert alert-danger"><?= $_SESSION['xmessage']; ?></h6>
                <?php 
                    unset($_SESSION['xmessage']);
                    endif; 
                ?>
                <?php if(isset($_SESSION['message'])) : ?>
                <h6 class="alert alert-success"><?= $_SESSION['message']; ?></h6>
                <?php 
                    unset($_SESSION['message']);
                    endif; 
                ?>
                                
            <form class="needs-validation" action="upd_nbkd.php" method="POST">
                <input type="hidden" name="rep_id" value="<?php echo $rep_id; ?>">
                <table class="table table-sm table-responsive table-bordered mt-2" style="font-size:12px;">
                    <thead>
                        <tr class="border border-0">
                            <td colspan="6" class="border border-0"><span class="badge bg-primary h6"><i class="ti ti-pencil me-2"></i>KEGIATAN PENDIDIKAN</span><span class="badge bg-primary ms-1 h6"><i class="ti ti-calendar me-2"></i>TA: <?php echo $tahun; ?></span> <span class="badge bg-primary ms-1 h6"><i class="ti ti-calendar me-2"></i><?php echo $semester; ?></span>
                            
                            <a href="#" class="text-danger pt-2 h5 float-end"><i class="ti ti-help-hexagon-filled me-2"></i></a></td>
                        </tr>
                        <tr class="text-center align-middle border border-2">
                            <th class="thnbkdwd">No.</th>
                            <th class="thnbkd">Nama Kegiatan</th>
                            <th class="thnbkd">Bukti Penugasan</th>
                            <th class="thnbkdwd">SKS</th>
                            <th class="thnbkdwd">Jml Smtr</th>
                            <th class="thnbkdwd">File</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <tr>
                            <td class="text-center">01</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd1" id="anpdBKD1" value ="<?php echo $anpdbkd1; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd1" id="appdBKD1" value ="<?php echo $appdbkd1; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd1" id="skspdBKD1" min="0" max="12" step=".5" value ="<?php echo $skspdbkd1; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd1" id="smtpdBKD1" min="0" max="12" step=".5" value ="<?php echo $smtpdbkd1; ?>"></td>                                
                            <td> <!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd1"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd1" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 1</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD1a">File 1</label>
                                                <input type="text" id="docpdBKD1a" name="docpdbkd1a" class="form-control form-control-sm" value ="<?php echo $docpdbkd1a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD1b">File 2</label>
                                                <input type="text" id="docpdBKD1b" name="docpdbkd1b" class="form-control form-control-sm" value ="<?php echo $docpdbkd1b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD1c">File 3</label>
                                                <input type="text" id="docpdBKD1c" name="docpdbkd1c" class="form-control form-control-sm" value ="<?php echo $docpdbkd1c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                            </td>
                        </tr>  
                        <tr class="tr1" id="tr2">
                            <td class="text-center">02</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd2" id="anpdBKD2" value ="<?php echo $anpdbkd2; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd2" appdbkd2="appdBKD2" value ="<?php echo $appdbkd2; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd2" id="skspdBKD2" min="0" max="12" step=".5" value ="<?php echo $skspdbkd2; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd2" id="smtpdBKD2" min="0" max="12" step=".5" value ="<?php echo $smtpdbkd2; ?>"></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd2"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd2" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 2</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD2a">File 1</label>
                                                <input type="text" id="docpdBKD2a" name="docpdbkd2a" class="form-control form-control-sm" value ="<?php echo $docpdbkd2a; ?>"/>
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD2b">File 2</label>
                                                <input type="text" id="docpdBKD2b" name="docpdbkd2b" class="form-control form-control-sm" value ="<?php echo $docpdbkd2b; ?>"/>
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD2c">File 3</label>
                                                <input type="text" id="docpdBKD2c" name="docpdbkd2c" class="form-control form-control-sm" value ="<?php echo $docpdbkd2c; ?>"/>
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">03</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd3" id="anpdBKD3" value ="<?php echo $anpdbkd3; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd3" id="appdBKD3" value ="<?php echo $appdbkd3; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd3" id="skspdBKD3" min="0" max="12" step=".5" value ="<?php echo $skspdbkd3; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd3" id="smtpdBKD3" min="0" max="12" step=".5" value ="<?php echo $smtpdbkd3; ?>"></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd3"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd3" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 3</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD3a">File 1</label>
                                                <input type="text" id="docpdBKD3a" name="docpdbkd3a" class="form-control form-control-sm" value ="<?php echo $docpdbkd3a; ?>"/>
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD3b">File 2</label>
                                                <input type="text" id="docpdBKD3b" name="docpdbkd3b" class="form-control form-control-sm" value ="<?php echo $docpdbkd3b; ?>"/>
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD3c">File 3</label>
                                                <input type="text" id="docpdBKD3c" name="docpdbkd3c" class="form-control form-control-sm" value ="<?php echo $docpdbkd3c; ?>"/>
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">04</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd4" id="anpdBKD4" value ="<?php echo $anpdbkd4; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd4" id="appdBKD4" value ="<?php echo $appdbkd4; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd4" id="skspdBKD4" min="0" max="12" step=".5" value ="<?php echo $skspdbkd4; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd4" id="smtpdBKD4" min="0" max="12" step=".5" value ="<?php echo $smtpdbkd4; ?>"></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd4"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd4" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 4</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD4a">File 1</label>
                                                <input type="text" id="docpdBKD4a" name="docpdbkd4a" class="form-control form-control-sm" value ="<?php echo $docpdbkd4a; ?>"/>
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD4b">File 2</label>
                                                <input type="text" id="docpdBKD4b" name="docpdbkd4b" class="form-control form-control-sm" value ="<?php echo $docpdbkd4b; ?>"/>
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD4c">File 3</label>
                                                <input type="text" id="docpdBKD4c" name="docpdbkd4c" class="form-control form-control-sm" value ="<?php echo $docpdbkd4c; ?>"/>
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">05</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd5" id="anpdBKD5" value ="<?php echo $anpdbkd5; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd5" id="appdBKD5" value ="<?php echo $appdbkd5; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd5" id="skspdBKD5" min="0" max="12" step=".5" value ="<?php echo $skspdbkd5; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd5" id="smtpdBKD5" min="0" max="12" step=".5" value ="<?php echo $smtpdbkd5; ?>"></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd5"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd5" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 5</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD5a">File 1</label>
                                                <input type="text" id="docpdBKD5a" name="docpdbkd5a" class="form-control form-control-sm" value ="<?php echo $docpdbkd5a; ?>"/>
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD5b">File 2</label>
                                                <input type="text" id="docpdBKD5b" name="docpdbkd5b" class="form-control form-control-sm" value ="<?php echo $docpdbkd5b; ?>"/>
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD5c">File 3</label>
                                                <input type="text" id="docpdBKD5c" name="docpdbkd5c" class="form-control form-control-sm" value ="<?php echo $docpdbkd5c; ?>"/>
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">06</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd6" id="anpdBKD6" value ="<?php echo $anpdbkd6; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd6" id="appdBKD6" value ="<?php echo $appdbkd6; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd6" id="skspdBKD6" min="0" max="12" step=".5" value ="<?php echo $skspdbkd6; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd6" id="smtpdBKD6" min="0" max="12" step=".5" value ="<?php echo $smtpdbkd6; ?>"></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd6"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd6" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 6</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD6a">File 1</label>
                                                <input type="text" id="docpdBKD6a" name="docpdbkd6a" class="form-control form-control-sm" value ="<?php echo $docpdbkd6a; ?>"/>
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD6b">File 2</label>
                                                <input type="text" id="docpdBKD6b" name="docpdbkd6b" class="form-control form-control-sm" value ="<?php echo $docpdbkd6b; ?>"/>
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD6c">File 3</label>
                                                <input type="text" id="docpdBKD6c" name="docpdbkd6c" class="form-control form-control-sm" value ="<?php echo $docpdbkd6c; ?>"/>
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">07</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd7" id="anpdBKD7" value ="<?php echo $anpdbkd7; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd7" id="appdBKD7" value ="<?php echo $appdbkd7; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd7" id="skspdBKD7" min="0" max="12" step=".5" value ="<?php echo $skspdbkd7; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd7" id="smtpdBKD7" min="0" max="12" step=".5" value ="<?php echo $smtpdbkd7; ?>"></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd7"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd7" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 7</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD7a">File 1</label>
                                                <input type="text" id="docpdBKD7a" name="docpdbkd7a" class="form-control form-control-sm" value ="<?php echo $docpdbkd7a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD6b">File 2</label>
                                                <input type="text" id="docpdBKD7b" name="docpdbkd7b" class="form-control form-control-sm" value ="<?php echo $docpdbkd7b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD7c">File 3</label>
                                                <input type="text" id="docpdBKD7c" name="docpdbkd7c" class="form-control form-control-sm" value ="<?php echo $docpdbkd7c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">08</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpdbkd8" id="anpdBKD8" value ="<?php echo $anpdbkd8; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appdbkd8" id="appdBKD8" value ="<?php echo $appdbkd8; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspdbkd8" id="skspdBKD8" min="0" max="12" step=".5" value ="<?php echo $skspdbkd8; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpdbkd8" id="smtpdBKD8" min="0" max="12" step=".5" value ="<?php echo $smtpdbkd8; ?>"></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpdbkd8"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpdbkd8" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pendidikan RBKD 8</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD8a">File 1</label>
                                                <input type="text" id="docpdBKD8a" name="docpdbkd8a" class="form-control form-control-sm" value ="<?php echo $docpdbkd8a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD8b">File 2</label>
                                                <input type="text" id="docpdBKD8b" name="docpdbkd8b" class="form-control form-control-sm" value ="<?php echo $docpdbkd8b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpdBKD8c">File 3</label>
                                                <input type="text" id="docpdBKD8c" name="docpdbkd8c" class="form-control form-control-sm" value ="<?php echo $docpdbkd8c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr class="border border-0">
                            <td colspan="6" class="border border-0"><p class="badge bg-primary mt-4 mb-1"><i class="ti ti-pencil me-2"></i>KEGIATAN PENELITIAN</p></td>
                        </tr>                            
                        <tr class="text-center border border-2">
                            <th class="thnbkdwd py-2">No.</th>
                            <th class="thnbkd">Nama Kegiatan</th>
                            <th class="thnbkd">Bukti Penugasan</th>
                            <th class="thnbkdwd">SKS</th>
                            <th class="thnbkdwd">Jml Smtr</th>
                            <th class="thnbkdwd">File</th>
                        </tr>
                        <tr>
                            <td class="text-center">01</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anplbkd1" id="anplBKD1" value ="<?php echo $anplbkd1; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="applbkd1" id="applBKD1" value ="<?php echo $applbkd1; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="sksplbkd1" id="sksplBKD1" min="0" max="12" step=".5" value ="<?php echo $sksplbkd1; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtplbkd1" id="smtplBKD1" min="0" max="12" step=".5" value ="<?php echo $smtplbkd1; ?>"></td>                                
                            <td> <!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docplbkd1"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docplbkd1" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penelitian RBKD 1</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD1a">File 1</label>
                                                <input type="text" id="docplBKD1a" name="docplbkd1a" class="form-control form-control-sm" value ="<?php echo $docplbkd1a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD1b">File 2</label>
                                                <input type="text" id="docplBKD1b" name="docplbkd1b" class="form-control form-control-sm" value ="<?php echo $docplbkd1b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD1c">File 3</label>
                                                <input type="text" id="docplBKD1c" name="docplbkd1c" class="form-control form-control-sm" value ="<?php echo $docplbkd1c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">02</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anplbkd2" id="anplBKD2" value ="<?php echo $anplbkd2; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="applbkd2" id="applBKD2" value ="<?php echo $applbkd2; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="sksplbkd2" id="sksplBKD2" min="0" max="12" step=".5" value ="<?php echo $sksplbkd2; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtplbkd2" id="smtplBKD2" min="0" max="12" step=".5" value ="<?php echo $smtplbkd2; ?>"></td>                                
                            <td> <!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docplbkd2"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docplbkd2" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penelitian RBKD 2</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD2a">File 1</label>
                                                <input type="text" id="docplBKD2a" name="docplbkd2a" class="form-control form-control-sm" value ="<?php echo $docplbkd2a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD2b">File 2</label>
                                                <input type="text" id="docplBKD2b" name="docplbkd2b" class="form-control form-control-sm" value ="<?php echo $docplbkd2b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD2c">File 3</label>
                                                <input type="text" id="docplBKD2c" name="docplbkd2c" class="form-control form-control-sm" value ="<?php echo $docplbkd2c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">03</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anplbkd3" id="anplBKD3" value ="<?php echo $anplbkd3; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="applbkd3" id="applBKD3" value ="<?php echo $applbkd3; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="sksplbkd3" id="sksplBKD3" min="0" max="12" step=".5" value ="<?php echo $sksplbkd3; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtplbkd3" id="smtplBKD3" min="0" max="12" step=".5" value ="<?php echo $smtplbkd3; ?>"></td>                                
                            <td> <!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docplbkd3"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docplbkd3" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penelitian RBKD 3</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD3a">File 1</label>
                                                <input type="text" id="docplBKD3a" name="docplbkd3a" class="form-control form-control-sm" value ="<?php echo $docplbkd3a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD3b">File 2</label>
                                                <input type="text" id="docplBKD3b" name="docplbkd3b" class="form-control form-control-sm" value ="<?php echo $docplbkd3b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD3c">File 3</label>
                                                <input type="text" id="docplBKD3c" name="docplbkd3c" class="form-control form-control-sm" value ="<?php echo $docplbkd3c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">04</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anplbkd4" id="anplBKD4" value ="<?php echo $anplbkd4; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="applbkd4" id="applBKD4" value ="<?php echo $applbkd4; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="sksplbkd4" id="sksplBKD4" min="0" max="12" step=".5" value ="<?php echo $sksplbkd4; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtplbkd4" id="smtplBKD4" min="0" max="12" step=".5" value ="<?php echo $smtplbkd4; ?>"></td>                                
                            <td> <!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docplbkd4"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docplbkd4" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penelitian RBKD 4</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD4a">File 1</label>
                                                <input type="text" id="docplBKD4a" name="docplbkd4a" class="form-control form-control-sm" value ="<?php echo $docplbkd4a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD4b">File 2</label>
                                                <input type="text" id="docplBKD4b" name="docplbkd4b" class="form-control form-control-sm" value ="<?php echo $docplbkd4b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docplBKD4c">File 3</label>
                                                <input type="text" id="docplBKD4c" name="docplbkd4c" class="form-control form-control-sm" value ="<?php echo $docplbkd4c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr class="border border-0">
                            <td colspan="6" class="border border-0"><p class="badge bg-primary mt-4 mb-1"><i class="ti ti-pencil me-2"></i>KEGIATAN PENGABDIAN</p></td>
                        </tr>                            
                        <tr class="text-center border border-2">
                            <th class="thnbkdwd py-2">No.</th>
                            <th class="thnbkd">Nama Kegiatan</th>
                            <th class="thnbkd">Bukti Penugasan</th>
                            <th class="thnbkdwd">SKS</th>
                            <th class="thnbkdwd">Jml Smtr</th>
                            <th class="thnbkdwd">File</th>
                        </tr>
                        <tr>
                            <td class="text-center">01</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpgbkd1" id="anpgBKD1" value ="<?php echo $anpgbkd1; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appgbkd1" id="appgBKD1" value ="<?php echo $appgbkd1; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspgbkd1" id="skspgBKD1" min="0" max="12" step=".5" value ="<?php echo $skspgbkd1; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpgbkd1" id="smtpgBKD1" min="0" max="12" step=".5" value ="<?php echo $smtpgbkd1; ?>"></td>                                
                            <td> <!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpgbkd1"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpgbkd1" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pengabdian RBKD 1</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD1a">File 1</label>
                                                <input type="text" id="docpgBKD1a" name="docpgbkd1a" class="form-control form-control-sm" value ="<?php echo $docpgbkd1a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD1b">File 2</label>
                                                <input type="text" id="docpgBKD1b" name="docpgbkd1b" class="form-control form-control-sm" value ="<?php echo $docpgbkd1b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD1c">File 3</label>
                                                <input type="text" id="docpgBKD1c" name="docpgbkd1c" class="form-control form-control-sm" value ="<?php echo $docpgbkd1c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">02</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpgbkd2" id="anpgBKD2" value ="<?php echo $anpgbkd2; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appgbkd2" id="appgBKD2" value ="<?php echo $appgbkd2; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspgbkd2" id="skspgBKD2" min="0" max="12" step=".5" value ="<?php echo $skspgbkd2; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpgbkd2" id="smtpgBKD2" min="0" max="12" step=".5" value ="<?php echo $smtpgbkd2; ?>"></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpgbkd2"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpgbkd2" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pengabdian RBKD 2</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD2a">File 1</label>
                                                <input type="text" id="docpgBKD2a" name="docpgbkd2a" class="form-control form-control-sm" value ="<?php echo $docpgbkd2a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD2b">File 2</label>
                                                <input type="text" id="docpgBKD2b" name="docpgbkd2b" class="form-control form-control-sm" value ="<?php echo $docpgbkd2b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD2c">File 3</label>
                                                <input type="text" id="docpgBKD2c" name="docpgbkd2c" class="form-control form-control-sm" value ="<?php echo $docpgbkd2c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">03</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpgbkd3" id="anpgBKD3" value ="<?php echo $anpgbkd3; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appgbkd3" id="appgBKD3" value ="<?php echo $appgbkd3; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspgbkd3" id="skspgBKD3" min="0" max="12" step=".5" value ="<?php echo $skspgbkd3; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpgbkd3" id="smtpgBKD3" min="0" max="12" step=".5" value ="<?php echo $smtpgbkd3; ?>"></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpgbkd3"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpgbkd3" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pengabdian RBKD 3</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD3a">File 1</label>
                                                <input type="text" id="docpgBKD3a" name="docpgbkd3a" class="form-control form-control-sm" value ="<?php echo $docpgbkd3a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD3b">File 2</label>
                                                <input type="text" id="docpgBKD3b" name="docpgbkd3b" class="form-control form-control-sm" value ="<?php echo $docpgbkd3b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD3c">File 3</label>
                                                <input type="text" id="docpgBKD3c" name="docpgbkd3c" class="form-control form-control-sm" value ="<?php echo $docpgbkd3c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document --></td>
                        </tr>
                        <tr>
                            <td class="text-center">04</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpgbkd4" id="anpgBKD4" value ="<?php echo $anpgbkd4; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appgbkd4" id="appgBKD4" value ="<?php echo $appgbkd4; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspgbkd4" id="skspgBKD4" min="0" max="12" step=".5" value ="<?php echo $skspgbkd4; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpgbkd4" id="smtpgBKD4" min="0" max="12" step=".5" value ="<?php echo $smtpgbkd4; ?>"></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpgbkd4"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpgbkd4" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Pengabdian RBKD 4</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD4a">File 1</label>
                                                <input type="text" id="docpgBKD4a" name="docpgbkd4a" class="form-control form-control-sm" value ="<?php echo $docpgbkd4a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD4b">File 2</label>
                                                <input type="text" id="docpgBKD4b" name="docpgbkd4b" class="form-control form-control-sm" value ="<?php echo $docpgbkd4b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpgBKD4c">File 3</label>
                                                <input type="text" id="docpgBKD4c" name="docpgbkd4c" class="form-control form-control-sm" value ="<?php echo $docpgbkd4c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr class="border border-0">
                            <td colspan="6" class="border border-0"><p class="badge bg-primary mt-4 mb-1"><i class="ti ti-pencil me-2"></i>KEGIATAN PENUNJANG</p></td>
                        </tr>                            
                        <tr class="text-center border border-2">
                            <th class="thnbkdwd py-2">No.</th>
                            <th class="thnbkd">Nama Kegiatan</th>
                            <th class="thnbkd">Bukti Penugasan</th>
                            <th class="thnbkdwd">SKS</th>
                            <th class="thnbkdwd">Jml Smtr</th>
                            <th class="thnbkdwd">File</th>
                        </tr>
                        <tr>
                            <td class="text-center">01</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpjbkd1" id="anpjBKD1" value ="<?php echo $anpjbkd1; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appjbkd1" id="appjBKD1" value ="<?php echo $appjbkd1; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspjbkd1" id="skspjBKD1" min="0" max="12" step=".5" value ="<?php echo $skspjbkd1; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpjbkd1" id="smtpjBKD1" min="0" max="12" step=".5" value ="<?php echo $smtpjbkd1; ?>"></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpjbkd1"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpjbkd1" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penunjang RBKD 1</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD1a">File 1</label>
                                                <input type="text" id="docpjBKD1a" name="docpjbkd1a" class="form-control form-control-sm" value ="<?php echo $docpjbkd1a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD1b">File 2</label>
                                                <input type="text" id="docpjBKD1b" name="docpjbkd1b" class="form-control form-control-sm" value ="<?php echo $docpjbkd1b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD1c">File 3</label>
                                                <input type="text" id="docpjBKD1c" name="docpjbkd1c" class="form-control form-control-sm" value ="<?php echo $docpjbkd1c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">02</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpjbkd2" id="anpjBKD2" value ="<?php echo $anpjbkd2; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appjbkd2" id="appjBKD2" value ="<?php echo $appjbkd2; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspjbkd2" id="skspjBKD2" min="0" max="12" step=".5" value ="<?php echo $skspjbkd2; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpjbkd2" id="smtpjBKD2" min="0" max="12" step=".5" value ="<?php echo $smtpjbkd2; ?>"></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpjbkd2"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpjbkd2" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penunjang RBKD 2</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD2a">File 1</label>
                                                <input type="text" id="docpjBKD2a" name="docpjbkd2a" class="form-control form-control-sm" value ="<?php echo $docpjbkd2a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD2b">File 2</label>
                                                <input type="text" id="docpjBKD2b" name="docpjbkd2b" class="form-control form-control-sm" value ="<?php echo $docpjbkd2b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD2c">File 3</label>
                                                <input type="text" id="docpjBKD2c" name="docpjbkd2c" class="form-control form-control-sm" value ="<?php echo $docpjbkd2c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">03</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpjbkd3" id="anpjBKD3" value ="<?php echo $anpjbkd3; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appjbkd3" id="appjBKD3" value ="<?php echo $appjbkd3; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspjbkd3" id="skspjBKD3" min="0" max="12" step=".5" value ="<?php echo $skspjbkd3; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpjbkd3" id="smtpjBKD3" min="0" max="12" step=".5" value ="<?php echo $smtpjbkd3; ?>"></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpjbkd3"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpjbkd3" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penunjang RBKD 3</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD3a">File 1</label>
                                                <input type="text" id="docpjBKD3a" name="docpjbkd3a" class="form-control form-control-sm" value ="<?php echo $docpjbkd3a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD3b">File 2</label>
                                                <input type="text" id="docpjBKD3b" name="docpjbkd3b" class="form-control form-control-sm" value ="<?php echo $docpjbkd3b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD3c">File 3</label>
                                                <input type="text" id="docpjBKD3c" name="docpjbkd3c" class="form-control form-control-sm" value ="<?php echo $docpjbkd3c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>
                        <tr>
                            <td class="text-center">04</td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="anpjbkd4" id="anpjBKD4" value ="<?php echo $anpjbkd4; ?>"></td>
                            <td><input type="text" class="form-control form-control-sm border border-0" name="appjbkd4" id="appjBKD4" value ="<?php echo $appjbkd4; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="skspjbkd4" id="skspjBKD4" min="0" max="12" step=".5" value ="<?php echo $skspjbkd4; ?>"></td>
                            <td><input type="number" class="form-control form-control-sm border border-0" name="smtpjbkd4" id="smtpjBKD4" min="0" max="12" step=".5" value ="<?php echo $smtpjbkd4; ?>"></td>                                
                            <td><!--  Button Insert Document -->
                                         <a href="" class="ms-2 text-primary" data-bs-toggle="modal" data-bs-target="#Docpjbkd4"><i class="ti ti-file-plus"></i></a>
                                  <!--/  Button insert Document -->
                                  
                                  <!-- Insert Document -->
                                    <div class="modal fade" id="Docpjbkd4" tabindex="-1" aria-hidden="true">
                                      <div class="modal-dialog modal-lg modal-simple modal-edit-user">
                                        <div class="modal-content p-2 p-md-4">
                                          <div class="modal-body">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            <div class="text-center mb-4">
                                              <h4 class="mb-2">Dokumen Kegiatan Penunjang RBKD 4</h4>
                                            </div>
                                             <div class="text-start">
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD4a">File 1</label>
                                                <input type="text" id="docpjBKD4a" name="docpjbkd4a" class="form-control form-control-sm" value ="<?php echo $docpjbkd4a; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD4b">File 2</label>
                                                <input type="text" id="docpjBKD4b" name="docpjbkd4b" class="form-control form-control-sm" value ="<?php echo $docpjbkd4b; ?>" />
                                              </div>
                                              <div class="col-12 mt-2">
                                                <label class="form-label" for="docpjBKD4c">File 3</label>
                                                <input type="text" id="docpjBKD4c" name="docpjbkd4c" class="form-control form-control-sm" value ="<?php echo $docpjbkd4c; ?>" />
                                              </div>
                                              <div class="col-12 text-center mt-2">
                                                <button type="button" class="btn btn-sm btn-primary me-sm-3 me-1" data-bs-dismiss="modal" aria-label="Close">LAMPIRKAN</button>
                                                <button type="reset" class="btn btn-sm btn-label-secondary" data-bs-dismiss="modal" aria-label="Close">HAPUS</button>
                                              </div>
                                             </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  <!--/ Insert Document -->
                                  </td>
                        </tr>                            
                    </tbody>
                </table>
                <button type="submit" class="btn btn-danger float-end mt-3" name="upd_nbkd" id="Submit">SIMPAN PERUBAHAN RBKD</button>
            </form>
           </div>
          </div>
         
         </div>
     </div>           
    </div>
    <!-- / Content -->

<script>
         // adjust width on initial load
         window.onload = adjustWidth;
         
         // Select the input field
         var inputField = document.querySelector("#myInput");
         
         // Add an event listener to the input field
         inputField.addEventListener("input", adjustWidth);
         
         // Function to adjust the width of the input field
         function adjustWidth() {
            var value = inputField.value;
            var width = value.length * 30 + 100; // 8px per character
            inputField.style.width = width + "px";
         }
      
</script>

<?php require_once ("../includes/footer.php"); ?>