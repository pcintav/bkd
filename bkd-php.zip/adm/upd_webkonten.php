<?php
session_start();

// Include your database connection class
include('../includes/Dtbase.php');

// Instantiate the DatabaseConnection class
$databaseConnection = new DatabaseConnection();
$conn = $databaseConnection->getConnection();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the current logged-in user ID from the session
    $adm_id = $_SESSION['adm_id'];
    $uname = $_SESSION['uname'];

    // Sanitize and validate form data
    $tutor_adm = filter_input(INPUT_POST, 'tutor_adm', FILTER_SANITIZE_STRING);
    $maps_adm = filter_input(INPUT_POST, 'maps_adm', FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^<iframe.*src=\"https:\/\/www\.google\.com\/maps\/embed\?pb=.*<\/iframe>$/")));
    $context_adm = filter_input(INPUT_POST, 'context_adm', FILTER_SANITIZE_STRING);
    $footext_adm = filter_input(INPUT_POST, 'footext_adm', FILTER_SANITIZE_STRING);
    
    $validation_errors = [];

    // Validate input fields
    if (!preg_match("/^[\w\s\/,.:?=&<>()\\\\;-]*+$/", $tutor_adm)) {
    $validation_errors[] = "Invalid value for tutor_adm. Only letters, numbers, spaces, slashes, commas, periods, colons, question marks, equal signs, ampersands, angle brackets, parentheses, backslashes, semicolons, double quotes, or hyphens are allowed.";
    }

    if ($maps_adm === false || $maps_adm === null) {
        // Invalid input, handle error
        $validation_errors[] = "Invalid value for maps_adm. Only Google Maps embed code is allowed.";
    } else {
        // Input is valid, further processing can be done
        // Sanitize the input to remove potentially harmful attributes
        $sanitized_maps_adm = preg_replace('/<iframe.*?src="(https:\/\/www\.google\.com\/maps\/embed\?pb=[^"]*)".*?>.*?<\/iframe>/', '<iframe src="$1" width="100%" height="300px" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>', $maps_adm);
        // Further processing with $sanitized_maps_adm
    }
    
    if (!preg_match('/^[\p{L}0-9\s\/.,\-]*+$/u', $context_adm)) {
        $validation_errors[] = "Invalid value for context_adm. Only letters, numbers, spaces, slashes, commas, periods, and hyphens are allowed.";
    }
    
    if (!preg_match("/^[\w\s\/,.:?=&\\\\-]*+$/", $footext_adm)) {
        $validation_errors[] = "Invalid value for footext_adm. Only letters, numbers, spaces, slashes, commas, periods, colons, question marks, equal signs, ampersands, backslashes, or hyphens are allowed.";
    }
    
        // Check for any validation errors
    if (!empty($validation_errors)) {
        $_SESSION['xmessage'] = implode("<br>", $validation_errors);
        header("Location: /adm/edit-webkonten?eins=$uname");
        exit();
    }

    // Prepare and execute the SQL update statement
    $stmt = $conn->prepare("UPDATE adm_bkd SET tutor_adm = :tutor_adm, maps_adm = :maps_adm, context_adm = :context_adm, footext_adm = :footext_adm WHERE adm_id = :adm_id");

    $stmt->bindParam(':adm_id', $adm_id);
    $stmt->bindParam(':tutor_adm', $tutor_adm);
    $stmt->bindParam(':maps_adm', $maps_adm);
    $stmt->bindParam(':context_adm', $context_adm);
    $stmt->bindParam(':footext_adm', $footext_adm);
    
    if ($stmt->execute()) {
        // Update successful
        $_SESSION['message'] = "Fitur web sukses diperbarui.";
    } else {
        // Update failed
        $_SESSION['xmessage'] = "Fitur web gagal diperbarui.";
    }

    // Redirect to the profile page or any other appropriate page
    header("Location: /adm/edit-webkonten?eins=$uname");
    exit();
}

// If the form is not submitted, retrieve the user data for pre-filling the form
$user_id = $_SESSION['adm_id'];
$stmt = $conn->prepare("SELECT * FROM adm_bkd WHERE adm_id = :adm_id");
$stmt->bindParam(':adm_id', $adm_id);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // Other code for displaying the form with pre-filled data
    // HTML and Bootstrap code for the update form goes here
}
?>
