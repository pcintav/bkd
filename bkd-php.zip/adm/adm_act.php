<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
?>
<?php  
session_start();
require_once ("../includes/Dtbase.php"); 

$dbConnection = new DatabaseConnection();
$conn = $dbConnection->getConnection();

if(isset($_POST['daftar']))

{ 
      
    // Menyimpan respons Google Recaptcha di variable $recaptcha  
    $recaptcha = $_POST['g-recaptcha-response']; 
  
    // Masukkan kunci rahasia di sini, yang kami dapatkan dari konsol Google 
    $secret_key = '6Lfpp1UpAAAAAGnB0hTZdj2vz7EQCHtmeNS2gl2n'; 
  
    // Mengirim permintaan ke URL, Google akan merespons dengan skenario sukses atau kesalahan
    $url = 'https://www.google.com/recaptcha/api/siteverify?secret='
          . $secret_key . '&response=' . $recaptcha; 
  
    // Membuat permintaan untuk memverifikasi captcha
    $response = file_get_contents($url); 
  
    // Respon yang dikembalikan oleh Google dalam format JSON, jadi kita harus mengurai json tersebut
    $response = json_decode($response); 
  
    // Memeriksa, apakah responsnya benar atau tidak
    if ($response->success == false) { 
        $_SESSION['xmessage'] = "Recaptcha belum diinput";
        header('Location: /adm/adm-reg');
        exit(0);
    } 

    else
    {
        if (isset($_POST['daftar'])) {
            // Sanitize and validate input fields
            $nama_adm = filter_var($_POST['nama'], FILTER_SANITIZE_STRING);
        
            // Validate name (alphabet and spaces only)
            if (!preg_match('/^[a-zA-Z ]+$/', $nama_adm)) {
                $_SESSION['xmessage'] = "Name can only contain letters and spaces.";
                header('Location: /adm/adm-reg');
                exit(0);
            }
            
            // Sanitize username (remove any unwanted characters)        
            $uname = filter_var($_POST['uname'], FILTER_SANITIZE_STRING);

            // Validate username (only alphanumeric characters allowed and at least 8 characters long)
            if (!preg_match('/^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{8,}$/', $uname)) {
                $_SESSION['xmessage'] = "Username must contain at least 8 characters with a combination of letters and numbers.";
                header('Location: /adm/adm-reg');
                exit(0);
            }
        
            $email_adm = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
            $pass_adm = $_POST['passwd'];
        
            // Validate password strength (your existing logic)
            if (strlen($pass_adm) < 8 || !preg_match('/[a-z]/', $pass_adm) || !preg_match('/[A-Z]/', $pass_adm) || !preg_match('/[0-9]/', $pass_adm)) {
                $_SESSION['xmessage'] = "Password must be at least 8 characters long and contain a mix of letters, numbers, and symbols.";
                header('Location: /adm/adm-reg');
                exit(0);
            }
        
            // Check for empty fields (your existing logic)
            if (empty($nama_adm) || empty($uname) || empty($email_adm) || empty($pass_adm)) {
                $_SESSION['xmessage'] = "Please fill in all fields.";
                header('Location: /adm/adm-reg');
                exit(0);
            }
            
            // Check for unique username and email
            $query = "SELECT COUNT(*) FROM adm_bkd WHERE uname = :uname OR email_adm = :email_adm";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':uname', $uname);
            $stmt->bindParam(':email_adm', $email_adm);
            $stmt->execute();
        
            if ($stmt->fetchColumn() > 0) {
                $_SESSION['xmessage'] = "Username or email already exists. Please choose a different one.";
                header('Location: /adm/adm-reg');
                exit(0);
            }
        
            // Hash password securely (your existing logic)
            $hash = password_hash($pass_adm, PASSWORD_BCRYPT, array("cost" => 12));

            // Prepare and execute query with parameterized statements (your existing logic)
            $query = "INSERT INTO adm_bkd (uname, nama_adm, email_adm, pass_adm, tgl_dftr) VALUES (:uname, :nama_adm, :email_adm, :pass_adm, NOW())";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':uname', $uname);
            $stmt->bindParam(':nama_adm', $nama_adm);
            $stmt->bindParam(':email_adm', $email_adm);
            $stmt->bindParam(':pass_adm', $hash);
        
            if ($stmt->execute()) {
                $_SESSION['message'] = "Sukses mendaftar BKD";
                header('Location: /adm/adm-reg');
                exit(0);
            } else {
                $_SESSION['xmessage'] = "Gagal mendaftar BKD";
                header('Location: /adm/adm-reg');
                exit(0);
            }
        }

    }

}
