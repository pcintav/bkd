<?php require_once ("../includes/adm_header.php"); ?>
<?php require_once ("../includes/adm_sidebar.php"); ?>
<?php require_once ("../includes/adm_topbar.php"); ?>
<?php
// Fetch preview image URLs from the database
$adm_id = isset($_SESSION['adm_id']) ? $_SESSION['adm_id'] : null;

// Default image URLs
$foto_logo_url = 'https://bkd.sistm.app/assets/img/elements/6.jpg';
$foto_index_url = 'https://bkd.sistm.app/assets/img/backgrounds/2.jpg';

if ($adm_id) {
    $stmt = $conn->prepare("SELECT fotologo_url, fotoindex_url FROM adm_bkd WHERE adm_id = :adm_id");
    $stmt->bindParam(':adm_id', $adm_id);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if the result is not empty before assigning values
    if ($result) {
        $foto_logo_url = $result['fotologo_url'] ?: $foto_logo_url;
        $foto_index_url = $result['fotoindex_url'] ?: $foto_index_url;
    }
}
?>
<div class="container-xxl flex-grow-1 container-p-y small">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <div class="row p-3 gap-0">
                    <?php
                    if (isset($_SESSION['message'])) {
                        echo '<h5 class="alert alert-success">' . htmlspecialchars($_SESSION['message']) . '</h5>';
                        unset($_SESSION['message']);
                    }
                    ?>
                    <?php
                    if (isset($_SESSION['xfmessage'])) {
                        echo '<h5 class="alert alert-danger">' . htmlspecialchars($_SESSION['xfmessage']) . '</h5>';
                        unset($_SESSION['xfmessage']);
                    }
                    ?>
                        <!-- Fotologo -->
                        <div class="col-6 px-0">
                            <h5 class="text-primary" id="">FOTO LOGO</h5>
                            <div class="form-group d-flex align-items-center">
                                <div class="me-0" style="width: 150px; height: 150px; overflow: hidden; position: relative;  border-radius: 10px;">
                                    <label for="fotologo_url" style="cursor: pointer;">
                                        <img id="previewImageFotologo_url" src="<?php echo $foto_logo_url; ?>" alt="Preview" class="img-thumbnail" style="width: 150px; height: 150px; object-fit: cover;" onclick="selectImage('fotologo_url')">
                                    </label>
                                    <input type="file" id="fotologo_url" name="fotologo_url" accept="image/*" hidden onchange="previewSelectedImage('fotologo_url')">
                                </div>
                            </div>
                                    <form action="del_flogo.php" method="post" class="mt-2">
                                        <button type="button" class="btn btn-primary btn-sm px-1" title="Unggah Gambar Logo" onclick="uploadImage('fotologo_url')"><i class="ti ti-upload"></i></button>
                                        <!-- Modal -->
                                        <button type="button" class="btn btn-primary btn-sm px-1" data-bs-toggle="modal" data-bs-target="#ModalFlogo"><i class="ti ti-zoom-in"></i></button>
                                          <div class="modal fade" id="ModalFlogo" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                              <div class="modal-content">
                                                <div class="modal-header mb-1">
                                                  <h5 class="modal-title" id="exampleModalLabel1">Foto Logo</h5>
                                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body text-center">
                                                  <img id="" src="https://bkd.sistm.app/adm/<?php echo $fotologo_url; ?>" alt="Belum ada foto logo" class="" style="width: 300px; height: 100%; object-fit: cover;">
                                                </div>
                                                <div class="modal-footer">
                                                  <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Tutup</button>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                          <!-- Modal -->
                                        <button type="submit" name="delete_fotologo" class="btn btn-danger btn-sm px-1" onclick="return confirm('Anda yakin mau menghapus foto logo ini?');"><i class="ti ti-trash"></i></button>
                                    </form>                            
                        </div>
                        <!-- Fotoindex -->
                        <div class="col-6 px-0">
                            <h5 class="text-primary" id="">FOTO INDEX</h5>
                            <div class="form-group d-flex align-items-center">
                                <div class="me-0" style="width: 250px; height: 150px; overflow: hidden; position: relative;  border-radius: 15px;">
                                    <label for="fotoindex_url" style="cursor: pointer;">
                                        <img id="previewImageFotoindex_url" src="<?php echo $foto_index_url; ?>" alt="Preview" class="img-thumbnail" style="width: 250px; height: 150px; object-fit: cover;" onclick="selectImage('fotoindex_url')">
                                    </label>
                                    <input type="file" id="fotoindex_url" name="fotoindex_url" accept="image/*" hidden onchange="previewSelectedImage('fotoindex_url')">
                                </div>
                            </div>
                                    <form action="del_findex.php" method="post" class="mt-2">
                                        <button type="button" class="btn btn-primary btn-sm px-1" title="Unggah Gambar Index" onclick="uploadImage('fotoindex_url')"><i class="ti ti-upload"></i></button>
                                        <!-- Modal -->
                                        <button type="button" class="btn btn-primary btn-sm px-1" data-bs-toggle="modal" data-bs-target="#ModalFindex"><i class="ti ti-zoom-in"></i></button>
                                          <div class="modal fade" id="ModalFindex" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                              <div class="modal-content">
                                                <div class="modal-header mb-1">
                                                  <h5 class="modal-title" id="exampleModalLabel2">Foto Index</h5>
                                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body text-center">
                                                  <img id="" src="https://bkd.sistm.app/adm/<?php echo $fotoindex_url; ?>" alt="Belum ada foto index" class="" style="width: 400px; height: 100%; object-fit: cover;">
                                                </div>
                                                <div class="modal-footer">
                                                  <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Tutup</button>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                          <!-- Modal -->
                                        <button type="submit" name="delete_fotoindex" class="btn btn-danger btn-sm px-1" onclick="return confirm('Anda yakin mau menghapus foto Index ini?');"><i class="ti ti-trash"></i></button>
                                    </form>                            
                        </div>
                        <hr class="my-4 mx-0" />
                            <div class="row">
                                <h5 class="fs-5 fw-bold text-primary" id="">FILE DAN FOTO PENDUKUNG</h5>
                                <?php
                                // PHP function to get icon class based on file extension
                                function get_icon_class($extension) {
                                  $icon_class = '';
                                  switch(strtolower($extension)) {
                                    case 'pdf':
                                      $icon_class = 'bi bi-filetype-pdf';
                                      break;
                                    case 'jpg':
                                    case 'jpeg':
                                    case 'png':
                                      $icon_class = 'bi bi-filetype-jpg';
                                      break;
                                    default:
                                      $icon_class = 'bi bi-file-earmark-x';
                                  }
                                  return $icon_class;
                                }
                                ?>  
                                <div class="container">
                                  <div class="row row-cols-2 row-cols-md-3 row-cols-lg-3 g-1">
                                    <!-- Column for guide_name -->
                                    <div class="col">
                                      <div class="card">
                                        <?php
                                        // Check if guide_url is empty or null
                                        if (!empty($guide_url)) {
                                            // If guide_url contains a valid image URL, display the document
                                        ?>
                					    <div class="card-body text-center p-2">
                                          <h6 class="card-title fs-tiny fw-bold mb-0">FILE PEDOMAN</h6>
                                          <?php 
                                            $file_extension = pathinfo($guide_name, PATHINFO_EXTENSION);
                                            $icon_class = get_icon_class($file_extension);
                                          ?>
                                          <a href="<?php echo $guide_url; ?>" target="_blank"><span class="icondok text-success <?php echo $icon_class; ?>"></span></a>
                                          <p class="fs-tiny lh-1"><?php echo $guide_name; ?></p>
                                        </div>
                					    <?php
                                        } else {
                                            // If guide_url is empty or null, display a default image
                                            ?>
                                            <div class="card-body text-center p-2">
                                              <h6 class="card-title fs-tiny fw-bold mb-0">FILE PEDOMAN</h6>
                                              <span class="icondok text-danger"><i class="bi bi-file-earmark-x"></i></span>
                                              <p class="fs-tiny text-danger lh-1">BELUM UNGGAH FILE</p>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                      </div>
                                    </div>
                                
                                    <!-- Column for logopanjang_name -->
                                    <div class="col">
                                      <div class="card">
                                        <?php
                                        // Check if logopanjang_url is empty or null
                                        if (!empty($logopanjang_url)) {
                                            // If logopanjang_url contains a valid image URL, display the document
                                        ?>
                					    <div class="card-body text-center p-2">
                                          <h6 class="card-title fs-tiny fw-bold mb-0">LOGO PERSEGI PANJANG</h6>
                                          <?php 
                                            $file_extension = pathinfo($logopanjang_name, PATHINFO_EXTENSION);
                                            $icon_class = get_icon_class($file_extension);
                                          ?>
                                          <a href="<?php echo $logopanjang_url; ?>" target="_blank"><span class="icondok text-success <?php echo $icon_class; ?>"></span></a>
                                          <p class="fs-tiny lh-1"><?php echo $logopanjang_name; ?></p>
                                        </div>
                					    <?php
                                        } else {
                                            // If logopanjang_url is empty or null, display a default image
                                            ?>
                                            <div class="card-body text-center p-2">
                                              <h6 class="card-title fs-tiny fw-bold mb-0">LOGO PERSEGI PANJANG</h6>
                                              <span class="icondok text-danger"><i class="bi bi-file-earmark-x"></i></span>
                                              <p class="fs-tiny text-danger lh-1">BELUM UNGGAH FILE</p>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                      </div>
                                    </div>
                                
                                    <!-- Column for dokumen1_name -->
                                    <div class="col">
                                      <div class="card">
                                        <?php
                                        // Check if dokumen1_url is empty or null
                                        if (!empty($dokumen1_url)) {
                                            // If $dokumen1_url contains a valid image URL, display the document
                                        ?>
                					    <div class="card-body text-center p-2">
                                          <h6 class="card-title fs-tiny fw-bold mb-0">FILE TAMBAHAN</h6>
                                          <?php 
                                            $file_extension = pathinfo($dokumen1_name, PATHINFO_EXTENSION);
                                            $icon_class = get_icon_class($file_extension);
                                          ?>
                                          <a href="<?php echo $dokumen1_url; ?>" target="_blank"><span class="icondok text-success <?php echo $icon_class; ?>"></span></a>
                                          <p class="fs-tiny lh-1"><?php echo $dokumen1_name; ?></p>
                                        </div>
                					    <?php
                                        } else {
                                            // If dokumen1_url is empty or null, display a default image
                                            ?>
                                            <div class="card-body text-center p-2">
                                              <h6 class="card-title fs-tiny fw-bold mb-0">FILE TAMBAHAN</h6>
                                              <span class="icondok text-danger"><i class="bi bi-file-earmark-x"></i></span>
                                              <p class="fs-tiny text-danger lh-1">BELUM UNGGAH FILE</p>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                      </div>
                                    </div>
                                
                                  </div>
                                </div>
                                
                                <div class="container mt-1">
                                        <!-- Six delete buttons, each for a specific file -->
                                        <form action="del_admdok.php" method="post">
                                            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-lg-3 row-cols-xl-3 g-4">
                                                <!-- Delete button for guide_url -->
                                                <div class="col"><button type="submit" class="btn btn-sm btn-danger fs-tiny w-100" name="delete" value="guide_url">HAPUS FILE GUIDE</button></div>
                                                <!-- Delete button for logopanjang_url -->
                                                <div class="col"><button type="submit" class="btn btn-sm btn-danger fs-tiny w-100" name="delete" value="logopanjang_url">HAPUS LOGO PANJANG</button></div>
                                                <!-- Delete button for dokumen1_url -->
                                                <div class="col"><button type="submit" class="btn btn-sm btn-danger fs-tiny w-100" name="delete" value="dokumen1_url">HAPUS FILE TAMBAHAN</button></div>
                                                
                                            </div>
                                        </form>
                                    </div>
                                
                                <div class="col mt-5">
                                    <p class="fs-5 fw-bold text-primary">FORM UNGGAH FILE</p>
                                    <form action="upd_admdok.php" method="POST" enctype="multipart/form-data">
                                        <div class="mb-3">
                                            <label for="fileGuide" class="form-label text-info fw-bold">UNGGAH FILE PEDOMAN</label>
                                            <div class="input-group">
                                                <input type="file" name="guide_url" class="form-control" id="fileGuide" accept=".pdf, .jpg">
                                                <button type="submit" class="btn btn-sm btn-primary">Upload</button>
                                            </div>
                                        </div>
                                    
                                        <div class="mb-3">
                                            <label for="logoPanj" class="form-label text-info fw-bold">UNGGAH LOGO PANJANG</label>
                                            <div class="input-group">
                                                <input type="file" name="logopanjang_url" class="form-control" id="logoPanj" accept=".png, .jpg">
                                                <button type="submit" class="btn btn-sm btn-primary">Upload</button>
                                            </div>
                                        </div>
                                    
                                        <div class="mb-3">
                                            <label for="dok1" class="form-label text-info fw-bold">UNGGAH FILE TAMBAHAN</label>
                                            <div class="input-group">
                                                <input type="file" name="dokumen1_url" class="form-control" id="dok1" accept=".pdf, .jpg">
                                                <button type="submit" class="btn btn-sm btn-primary">Upload</button>
                                            </div>
                                        </div>

                                        <button type="submit" class="btn btn-sm btn-primary">UNGGAH SEKALIGUS</button>
                                    </form>
                                </div>
                            </div>                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function uploadImage(inputId) {
        var input = document.getElementById(inputId);
        var file = input.files[0];

        // Check if a file is selected
        if (!file) {
            alert('Silakan pilih gambar sebelum diunggah.');
            return; // Exit the function if no file is selected
        }

        var formData = new FormData();
        formData.append(inputId, file);

        var xhr = new XMLHttpRequest();
        xhr.open("POST", "upd_admimg.php", true);

        xhr.onload = function () {
            if (xhr.status === 200) {
                var response = xhr.responseText.trim();
                // Check if the response includes 'Sukses'
                if (response.includes('Sukses')) {
                    // Redirect to upload.php on success
                    window.location.href = '/adm/up-admimg?img=<?php echo $uname; ?>';
                } else {
                    // Redirect to upload.php on failure
                    window.location.href = '/adm/up-admimg?img=<?php echo $uname; ?>';
                }
            } else {
                // Redirect to upload.php on failure
                window.location.href = '/adm/up-admimg?img=<?php echo $uname; ?>';
            }
        };

        // Handle network errors
        xhr.onerror = function () {
            // Redirect to upload.php on network error
            window.location.href = '/adm/up-admimg?img=<?php echo $uname; ?>';
        };

        xhr.send(formData);
    }
</script>

<script>
    function selectImage(imageId) {
        document.getElementById(imageId).click();
    }

    function previewSelectedImage(imageId) {
        var input = document.getElementById(imageId);
        var previewImage = document.getElementById('previewImage' + imageId.charAt(0).toUpperCase() + imageId.slice(1));

        var file = input.files[0];

        if (file) {
            var reader = new FileReader();

            reader.onload = function (e) {
                // Update the preview image directly
                previewImage.src = e.target.result;
            };

            reader.readAsDataURL(file);
        }
    }

    function deleteImage(imageId) {
        var previewImage = document.getElementById('previewImage' + imageId.charAt(0).toUpperCase() + imageId.slice(1));
        var input = document.getElementById(imageId);

        // Reset the preview to the default image
        previewImage.src = 'https://bkd.sistm.app/assets/img/backgrounds/1.jpg';

        // Clear the file input
        input.value = null;
    }

    function updateImagePreview(imageId, imageUrl) {
        // Update the image preview with the new URL
        var previewImage = document.getElementById('previewImage' + imageId.charAt(0).toUpperCase() + imageId.slice(1));

        // Check if the previewImage element exists
        if (previewImage) {
            previewImage.src = imageUrl;
        } else {
            console.error('Preview image element not found for ' + imageId);
        }
    }
</script>

<?php require_once ("../includes/adm_footer.php"); ?>

