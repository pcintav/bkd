<?php
header("Location: /adm/log-adm", true, 301);
exit() or die();
?>