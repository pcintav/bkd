<?php
session_start();

// Securely check for direct access to log_act.php
if (stripos($_SERVER['SCRIPT_NAME'], 'log_act.php') !== false) {
    header('Location: /adm/index');
}

require_once '../includes/Dtbase.php';

// Secure session settings
session_regenerate_id(true);
//ini_set('session.cookie_httponly', 1);

// Database connection with error handling
try {
    $dbConnection = new DatabaseConnection();
    $conn = $dbConnection->getConnection();
} catch (Exception $e) {
    error_log("Database connection error: " . $e->getMessage());
    $_SESSION['xmessage'] = "Terjadi kesalahan sistem. Mohon coba kembali.";
    header('Location: /adm/index');
    exit();
}

// Check if user is temporarily blocked
if (isset($_SESSION['block_time']) && time() < $_SESSION['block_time']) {
    $remainingTime = $_SESSION['block_time'] - time();
    $_SESSION['xmessage'] = "Anda telah gagal percobaan login sebanyak 3 kali. Silakan tunggu " . gmdate("i:s", $remainingTime) . " menit.";
    header('Location: /adm/index');
    exit();
}

if (isset($_POST['login'])) {
    // Increment or reset login attempts counter
    if (!isset($_SESSION['login_attempts']) || !isset($_SESSION['last_attempt_time']) || time() - $_SESSION['last_attempt_time'] > 300) {
        // Reset attempts after 5 minutes of inactivity
        $_SESSION['login_attempts'] = 1;
    } else {
        $_SESSION['login_attempts']++;
    }

    // Update last attempt time
    $_SESSION['last_attempt_time'] = time();

    // Strict input validation
    $uname = filter_var(trim($_POST['uname']), FILTER_SANITIZE_STRING);

    if (!preg_match('/^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{8,}$/', $uname)) {
        // Check if this is the third failed attempt
        if ($_SESSION['login_attempts'] >= 3) {
            $_SESSION['block_time'] = time() + 600; // Block the user for 10 minutes
            $_SESSION['xmessage'] = "Anda telah gagal percobaan login sebanyak 3 kali. Silakan tunggu 10 menit.";
            header('Location: /adm/index');
            exit();
        } else {
            $remainingAttempts = 3 - $_SESSION['login_attempts'];
            $_SESSION['xmessage'] = "Jumlah username minimal 8 karakter kombinasi huruf dan angka. Sisa percobaan login: $remainingAttempts";
            header('Location: /adm/index');
            exit();
        }
    }

    $passwordAttempt = trim($_POST['passwd']);

    if (empty($uname) || empty($passwordAttempt)) {
        $_SESSION['xmessage'] = "Isi semua kolom Username dan password. Sisa percobaan login: $remainingAttempts";
        header('Location: /adm/index');
        exit();
    }

    try {
        $sql = "SELECT adm_id, uname, pass_adm, nama_adm FROM adm_bkd WHERE uname = :uname";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':uname', $uname, PDO::PARAM_INT);
        $stmt->execute();
    } catch (PDOException $e) {
        error_log("Query error: " . $e->getMessage());
        $_SESSION['xmessage'] = "Terjadi kesalahan sistem. Mohon coba kembali.";
        header('Location: /adm/index');
        exit();
    }

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if this is the third failed attempt
    if ($_SESSION['login_attempts'] >= 3) {
        $_SESSION['block_time'] = time() + 600; // Block the user for 10 minutes
        $_SESSION['xmessage'] = "Anda telah gagal percobaan login sebanyak 3 kali. Silakan tunggu 10 menit.";
        header('Location: /adm/index');
        exit();
    }

    if ($user && password_verify($passwordAttempt, $user['pass_adm'])) {
        // Reset login attempts on successful login
        unset($_SESSION['login_attempts']);
        unset($_SESSION['last_attempt_time']);

        // Store essential user information in the session
        $_SESSION['isLoggedIn'] = true;
        $_SESSION['adm_id'] = $user['adm_id'];
        $_SESSION['uname'] = $uname;
        $_SESSION['nama_adm'] = $user['nama_adm'];
        $_SESSION['message'] = "Sukses Masuk Aplikasi BKD";
        header("Location: https://bkd.sistm.app/adm/dasbor?dash=$uname");
        exit(0);
    }

    // If execution reaches here, it means the login failed
    $remainingAttempts = 3 - $_SESSION['login_attempts'];
    $_SESSION['xmessage'] = "Username atau password salah. Sisa percobaan login: $remainingAttempts";
    header('Location: /adm/index');
    exit();
}
?>