<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['adm_id'])) {
    header("Location: /adm/index");
    exit();
}

require_once("../includes/Dtbase.php");

$db = new DatabaseConnection();
$conn = $db->getConnection();

// Get user information from the session
$adm_id = $_SESSION['adm_id'];
$nama_adm = $_SESSION['nama_adm'];
$uname = $_SESSION['uname'];

// Define columns array (mapping between upload paths and corresponding database columns)
$columns = [
    'guide_url' => 'guide_name',
    'logopanjang_url' => 'logopanjang_name',
    'dokumen1_url' => 'dokumen1_name',
];

// Function to delete file and corresponding data from database
function deleteFileAndData($urlColumn, $nameColumn, $adm_id, $conn)
{
    // Fetch file path and name from database
    $stmtSelect = $conn->prepare("SELECT {$urlColumn}, {$nameColumn} FROM adm_bkd WHERE adm_id = ?");
    $stmtSelect->execute([$adm_id]);
    $fileData = $stmtSelect->fetch(PDO::FETCH_ASSOC);

    // Delete file from server
    if (!empty($fileData[$urlColumn]) && file_exists($fileData[$urlColumn])) {
        unlink($fileData[$urlColumn]);
    }

    // Update database to remove file information
    $stmtUpdate = $conn->prepare("UPDATE adm_bkd SET {$urlColumn} = NULL, {$nameColumn} = NULL, revisi = CURRENT_TIMESTAMP WHERE adm_id = ?");
    $stmtUpdate->execute([$adm_id]);
}

// Check if delete button is clicked for a specific file
if (isset($_POST['delete'])) {
    $columnToDelete = $_POST['delete'];

    // Check if the requested column exists and delete the corresponding file and data
    if (array_key_exists($columnToDelete, $columns)) {
        deleteFileAndData($columnToDelete, $columns[$columnToDelete], $adm_id, $conn);
    }

    // Redirect back to the HTML form page
    $_SESSION['message'] = "File and data deleted successfully.";
    header("Location: /adm/up-admimg?img=$uname");
    exit();
}
?>
