<?php
session_start();

// Include your database connection class
include('../includes/Dtbase.php');

// Instantiate the DatabaseConnection class
$databaseConnection = new DatabaseConnection();
$conn = $databaseConnection->getConnection();

// Retrieve data sent via POST request
$thnakd_id = $_POST['thnakd_id'];
$tahun = filter_input(INPUT_POST, 'tahun', FILTER_SANITIZE_STRING);

// Validate form data
$validation_errors = [];

if (!preg_match("/^[0-9\/]+$/", $tahun)) {
    $validation_errors[] = "Invalid value for tahun. Only numbers and / are allowed.";
}

// Check for any validation errors
if (!empty($validation_errors)) {
    $response = implode("<br>", $validation_errors);
    echo $response;
    exit();
}

// Prepare SQL statement
$sql = "UPDATE thn_akademik SET tahun = :tahun WHERE thnakd_id = :thnakd_id";

// Prepare and execute the statement
try {
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':tahun', $tahun);
    $stmt->bindParam(':thnakd_id', $thnakd_id);
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
        echo "Row updated successfully for thnakd_id: " . $thnakd_id;
    } else {
        echo "No rows updated for thnakd_id: " . $thnakd_id;
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
