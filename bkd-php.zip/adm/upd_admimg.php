<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['adm_id'])) {
    header("Location: /adm/index");
    exit();
}

require_once("../includes/Dtbase.php");

$db = new DatabaseConnection();
$conn = $db->getConnection();

// Get user information from the session
$adm_id = $_SESSION['adm_id'];
$nama_adm = $_SESSION['nama_adm'];

// Function to handle image upload
function handleImageUpload($imageField, $allowedTypes, $maxSize, $uploadPath, $nameColumn)
{
    global $conn, $adm_id;

    // Validate database connection
    if (!$conn) {
        $_SESSION['xfmessage'] = "Database connection error.";
        return false;
    }

    // Validate if the file is selected
    if (!isset($_FILES[$imageField]['name']) || empty($_FILES[$imageField]['name'])) {
        return true; // No file selected, continue processing other fields
    }

    $fileType = $_FILES[$imageField]['type'];

    // Validate file type
    if (!in_array($fileType, $allowedTypes)) {
        $_SESSION['xfmessage'] = "Gambar bukan PNG/JPG/JPEG untuk " . $imageField;
        return false;
    }

    // Validate file size
    $fileSize = $_FILES[$imageField]['size'];
    if ($fileSize > $maxSize) {
        $_SESSION['xfmessage'] = "Gambar lebih 1MB untuk " . $imageField;
        return false;
    }

    // Check if the image with the same name already exists in the database
    $stmtCheckName = $conn->prepare("SELECT {$nameColumn} FROM adm_bkd WHERE {$nameColumn} = ?");
    $stmtCheckName->execute([$_FILES[$imageField]['name']]);
    $existingName = $stmtCheckName->fetchColumn();

    if ($existingName) {
        $_SESSION['xfmessage'] = "Gambar dengan nama yang sama sudah ada untuk " . $imageField;
        return false;
    }

    // Create upload directory if not exists
    if (!file_exists($uploadPath)) {
        mkdir($uploadPath, 0777, true);
    }

    // Move uploaded file to destination folder
    $uploadedFile = $uploadPath . basename($_FILES[$imageField]['name']);

    if (move_uploaded_file($_FILES[$imageField]['tmp_name'], $uploadedFile)) {
        // Update database with image information
        $stmtUpdate = $conn->prepare("UPDATE adm_bkd SET {$imageField} = ?, {$nameColumn} = ?, revisi = CURRENT_TIMESTAMP WHERE adm_id = ?");
        $stmtUpdate->execute([$uploadedFile, $_FILES[$imageField]['name'], $adm_id]);

        if ($stmtUpdate->rowCount() > 0) {
            //$_SESSION['message'] = "Sukses Diupload untuk " . $imageField;
            $_SESSION['message'] = "Sukses Diupload untuk " . $imageField;

        } else {
            $_SESSION['xfmessage'] = "Gagal menyimpan informasi gambar di database untuk " . $imageField;
        }
    } else {
        //$_SESSION['message'] = "Gagal Diupload untuk " . $imageField;
        $_SESSION['xfmessage'] = "Gagal Diupload untuk " . $imageField;

    }

    return true;
}

// Define upload path for the first image field
$uploadPathLogo = "uploads/" . date("Y/m/", time()) . $nama_adm . "/";

// Handle image upload for the first image field
handleImageUpload('fotologo_url', ['image/png', 'image/jpg', 'image/jpeg'], 1024 * 1024, $uploadPathLogo, 'namafoto_logo');

// Define upload path for the second image field
$uploadPathIndex = "uploads/" . date("Y/m/", time()) . $nama_adm . "/";

// Handle image upload for the second image field
handleImageUpload('fotoindex_url', ['image/png', 'image/jpg', 'image/jpeg'], 1024 * 1024, $uploadPathIndex, 'namafoto_index');
if (isset($_SESSION['xfmessage'])) {
    echo $_SESSION['xfmessage'];
}

//header("Location: /user/up-image?img=$nidn");
exit();

?>



