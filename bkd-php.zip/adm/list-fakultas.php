<?php require_once ("../includes/adm_header.php"); ?>
<?php require_once ("../includes/adm_sidebar.php"); ?>
<?php require_once ("../includes/adm_topbar.php"); ?>

    <!-- Content -->
                    
    <?php
    // Fetch data from the database
    $stmt = $conn->query("SELECT fak_id, namafak, nama_dekan FROM faculty");
    $updates = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    ?>

    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col">
                
                <div class="card">
                 <div class="card-header">
                    <div class="row">
                        <div class="col">
                            <span class="badge bg-primary"><i class="ti ti-star me-2"></i>NAMA FAKULTAS DAN NAMA DEKAN</span>
                        </div>
                    </div> 
                 </div>         
                    <div class="card-body">
                        
                        <?php
                        // Assuming $updates array is accessible here with faculty data
                        if (!empty($updates)) {
                            foreach ($updates as $update) {
                                ?>
                                <div class="row">
                                    <?php if ($update['fak_id'] != 1) { ?>
                                        <div class="col-md-3">
                                            <label for="namafak_<?php echo $update['fak_id']; ?>">Nama Fakultas :</label>
                                            <input type="text" class="form-control form-control-sm" id="namafak_<?php echo $update['fak_id']; ?>" name="namafak_<?php echo $update['fak_id']; ?>" value="<?php echo $update['namafak']; ?>">
                                        </div>
                                        <div class="col-md-3">
                                            <label for="nama_dekan_<?php echo $update['fak_id']; ?>">Nama Dekan:</label>
                                            <input type="text" class="form-control form-control-sm" id="nama_dekan_<?php echo $update['fak_id']; ?>" name="nama_dekan_<?php echo $update['fak_id']; ?>" value="<?php echo $update['nama_dekan']; ?>">
                                        </div>
                                        <div class="col-md-3 mt-3">
                                            <button type="button" class="btn btn-sm btn-primary update-btn" data-fak-id="<?php echo $update['fak_id']; ?>">Perbarui</button>
                                        </div>
                                    <?php } else { ?>
                                        <!-- If fak_id is 1, disable or hide the input field -->
                                        <div class="col-md-3">
                                            <input type="hidden" name="namafak_<?php echo $update['fak_id']; ?>" value="">
                                        </div>
                                        <div class="col-md-3">
                                            <input type="hidden" name="nama_dekan_<?php echo $update['fak_id']; ?>" value="">
                                        </div>
                                        <div class="col-md-3 mt-3">
                                            <!-- No button for fak_id = 1 -->
                                        </div>
                                    <?php } ?>
                                </div>
                                <br>
                                <?php
                            }
                        } else {
                            echo "<p>No faculty data available.</p>";
                        }
                        ?>

                        
                        <!-- Ensure jQuery is included -->
                        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
                        
                        <script>
                        $(document).ready(function() {
                            // Use event delegation to handle dynamically added buttons
                            $(document).on("click", ".update-btn", function() {
                                var fak_id = $(this).data("fak-id");
                                var namafak = $("#namafak_" + fak_id).val();
                                var nama_dekan = $("#nama_dekan_" + fak_id).val();
                        
                                $.ajax({
                                    type: "POST",
                                    url: "upd_faculty.php",
                                    data: {
                                        fak_id: fak_id,
                                        namafak: namafak,
                                        nama_dekan: nama_dekan
                                    },
                                    success: function(response) {
                                        alert(response);
                                    },
                                    error: function(xhr, status, error) {
                                        alert("Error: " + xhr.status);
                                    }
                                });
                            });
                        });
                        </script>
                                 			
                    </div>
                </div>

            </div>
        </div>
    </div>
    

    <!-- / Content -->

<?php require_once ("../includes/adm_footer.php"); ?>