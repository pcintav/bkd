<?php require_once ("../includes/adm_header.php"); ?>
<?php require_once ("../includes/adm_sidebar.php"); ?>
<?php require_once ("../includes/adm_topbar.php"); ?>


    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col">
                
                <div class="card">
                 <div class="card-header">
                    <div class="row">
                        <div class="col">
                            <span class="badge bg-primary"><i class="ti ti-star me-2"></i>PENGATURAN BKD</span>
                        </div>
                    </div> 
                 </div>         
                    <div class="card-body">
                        KONTEN         			
                    </div>
                </div>

            </div>
        </div>
    </div>
    

    <!-- / Content -->

<?php require_once ("../includes/adm_footer.php"); ?>