<?php require_once ("../includes/adm_header.php"); ?>
<?php require_once ("../includes/adm_sidebar.php"); ?>
<?php require_once ("../includes/adm_topbar.php"); ?>


    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col">
                
                <div class="card">
                 <div class="card-header">
                    <div class="row">
                        <div class="col">
                            <span class="badge bg-primary"><i class="ti ti-star me-2"></i>LIST ENTRI LKD</span>
                        </div>
                    </div> 
                 </div>         
                    <div class="card-body">
                        <table class="table table-responsive table-bordered" style="font-size:12px;">
                            <thead>
                               <tr class="text-center align-middle border border-2">
                                    <th class="thnbkdwd"><p class="pt-1">No.</p></th>
                                    <th class="thnbkd">Nama</th>
                                    <th class="thnbkd">Fakultas</th>
                                    <th class="thnbkdwd">Tahun</th>
                                    <th class="thnbkdwd">Smtr</th>
                                    <th class="thnbkdwd">Lihat</th>
                                    <th class="thnbkdwd">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <tr>
                                    <td class="text-center">01</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td class="text-center">02</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>                                
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td class="text-center">03</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>                                
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td class="text-center">04</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>                                
                                    <td></td>
                                    <td></td>
                                </tr>                            
                            </tbody>
                        </table>         			
                    </div>
                </div>

            </div>
        </div>
    </div>
    

    <!-- / Content -->

<?php require_once ("../includes/adm_footer.php"); ?>